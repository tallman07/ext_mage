<?php
/**
 * Innoexts
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the InnoExts Commercial License
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://innoexts.com/commercial-license-agreement
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@innoexts.com so we can send you a copy immediately.
 * 
 * @category    Innoexts
 * @package     Innoexts_ZonePricing
 * @copyright   Copyright (c) 2014 Innoexts (http://www.innoexts.com)
 * @license     http://innoexts.com/commercial-license-agreement  InnoExts Commercial License
 */

/**
 * Product price observer
 * 
 * @category   Innoexts
 * @package    Innoexts_ZonePricing
 * @author     Innoexts Team <developers@innoexts.com>
 */
class Innoexts_ZonePricing_Model_Catalog_Product_Price_Observer 
{
    /**
     * Get zone pricing helper
     * 
     * @return Innoexts_ZonePricing_Helper_Data
     */
    protected function getZonePricingHelper()
    {
        return Mage::helper('zonepricing');
    }
    /**
     * Get product price helper
     * 
     * @return Innoexts_ZonePricing_Helper_Catalog_Product_Price
     */
    protected function getProductPriceHelper()
    {
        return $this->getZonePricingHelper()
            ->getProductPriceHelper();
    }
    /**
     * Get product price indexer helper
     * 
     * @return Innoexts_Zone_Helper_Catalog_Product_Price_Indexer
     */
    protected function getProductPriceIndexerHelper()
    {
        return $this->getZonePricingHelper()
            ->getProductPriceIndexerHelper();
    }
    /**
     * Prepare product index
     * 
     * @param Varien_Event_Observer $observer
     * 
     * @return self
     */
    public function prepareProductPriceIndex(Varien_Event_Observer $observer)
    {
        $event                   = $observer->getEvent();
        $this->getProductPriceIndexerHelper()
            ->updateZonePriceIndex(
                (clone $event->getSelect()), 
                $event->getIndexTable(), 
                $event->getEntityId(), 
                $event->getUpdateFields()
            );
        return $this;
    }
    /**
     * Prepare final price
     * 
     * @param Varien_Event_Observer $observer
     * 
     * @return self
     */
    public function prepareFinalPrice($observer)
    {
        $this->getProductPriceHelper()
            ->setZonePrice(
                $observer->getEvent()
                    ->getProduct(), 
                $this->getZonePricingHelper()
                    ->getCustomerLocatorHelper()
                    ->getCustomerAddress()
            );
        return $this;
    }
    /**
     * Prepare collection final price
     * 
     * @param Varien_Event_Observer $observer
     * 
     * @return self
     */
    public function prepareCollectionFinalPrice($observer)
    {
        $this->getProductPriceHelper()
            ->setCollectionZonePrice(
                $observer->getEvent()
                    ->getCollection(), 
                $this->getZonePricingHelper()
                    ->getCustomerLocatorHelper()
                    ->getCustomerAddress()
            );
        return $this;
    }
}
