<?php
/**
 * Innoexts
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the InnoExts Commercial License
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://innoexts.com/commercial-license-agreement
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@innoexts.com so we can send you a copy immediately.
 * 
 * @category    Innoexts
 * @package     Innoexts_ZonePricing
 * @copyright   Copyright (c) 2014 Innoexts (http://www.innoexts.com)
 * @license     http://innoexts.com/commercial-license-agreement  InnoExts Commercial License
 */

$installer                                      = $this;

$connection                                     = $installer->getConnection();

$helper                                         = Mage::helper('zonepricing');
$versionHelper                                  = $helper->getVersionHelper();
$databaseHelper                                 = $helper->getCoreHelper()->getDatabaseHelper();

$installer->startSetup();

$productTable                                   = $installer->getTable('catalog/product');

$productZonePriceTable                          = $installer->getTable('catalog/product_zone_price');

/**
 * Product Zone Price
 */
$installer->run("
CREATE TABLE `{$productZonePriceTable}` (
    `zone_price_id` int(10) unsigned not null auto_increment, 
    `product_id` int(10) unsigned not null, 
    `country_id` varchar(4) not null default '0', 
    `region_id` int(10) not null default '0', 
    `zip` varchar(21) null default null, 
    `is_zip_range` tinyint(1) unsigned not null default 0, 
    `from_zip` int(10) unsigned null default null, 
    `to_zip` int(10) unsigned null default null, 
    `price` decimal(12,4) NOT NULL default '0.00', 
    `price_type` enum('fixed', 'percent') NOT NULL default 'fixed', 
    PRIMARY KEY  (`zone_price_id`), 
    KEY `IDX_CATALOG_PRODUCT_ZONE_PRICE_COUNTRY` (`country_id`), 
    KEY `IDX_CATALOG_PRODUCT_ZONE_PRICE_REGION` (`region_id`), 
    KEY `IDX_CATALOG_PRODUCT_ZONE_PRICE_ZIP` (`zip`), 
    KEY `IDX_CATALOG_PRODUCT_ZONE_PRICE_FROM_ZIP` (`from_zip`), 
    KEY `IDX_CATALOG_PRODUCT_ZONE_PRICE_TO_ZIP` (`to_zip`), 
    KEY `FK_CATALOG_PRODUCT_ZONE_PRICE_PRODUCT` (`product_id`), 
    CONSTRAINT `FK_CATALOG_PRODUCT_ZONE_PRICE_PRODUCT` FOREIGN KEY (`product_id`) 
      REFERENCES {$productTable} (`entity_id`) 
      ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
");

$installer->endSetup();
