<?php
/**
 * Innoexts
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the InnoExts Commercial License
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://innoexts.com/commercial-license-agreement
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@innoexts.com so we can send you a copy immediately.
 * 
 * @category    Innoexts
 * @package     Innoexts_ZonePricing
 * @copyright   Copyright (c) 2014 Innoexts (http://www.innoexts.com)
 * @license     http://innoexts.com/commercial-license-agreement  InnoExts Commercial License
 */

$installer                                = $this;
$connection                               = $installer->getConnection();

$productZonePriceTable = $installer->getTable('catalog/product_zone_price');

$installer->startSetup();

$connection->changeColumn($productZonePriceTable, 'zip', 'zip', 'varchar(21) null default null');
$connection->addColumn($productZonePriceTable, 'is_zip_range', 'tinyint(1) unsigned not null default 0 after `zip`');
$connection->addColumn($productZonePriceTable, 'from_zip', 'int(10) unsigned null default null after `is_zip_range`');
$connection->addKey($productZonePriceTable, 'IDX_CATALOG_PRODUCT_ZONE_PRICE_FROM_ZIP', array('from_zip'), 'index');
$connection->addColumn($productZonePriceTable, 'to_zip', 'int(10) unsigned null default null after `from_zip`');
$connection->addKey($productZonePriceTable, 'IDX_CATALOG_PRODUCT_ZONE_PRICE_TO_ZIP', array('to_zip'), 'index');

$installer->endSetup();
