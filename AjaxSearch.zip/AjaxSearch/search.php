<?php

if (php_sapi_name() == 'cli' || empty($_SERVER['REMOTE_ADDR'])) {
    //shell for testing
    $query = "archie";
    $store = 2;
} else {
    //webserver
    $query = $_GET['query'];
    $store = $_GET['store'];
}

if (!is_numeric($store)) {
    $store = 1; //default to first store
}

// Connects to your Database
$host = '';
$dbname = '';
$user = '';
$pass = '';

//get connection details
$config = simplexml_load_file('app/etc/local.xml');
foreach ($config->children() as $child) {
    foreach ($child as $child2) {
        if ($child2->getName() == 'resources') {
            foreach ($child2->children() as $child3) {
                if ($child3->getName() == 'default_setup') {
                    $host = (string)$child3->connection->host;
                    $user = (string)$child3->connection->username;
                    $pass = (string)$child3->connection->password;
                    $dbname = (string)$child3->connection->dbname;
                }
            }
        }
    }
}

mysql_connect($host, $user, $pass) or die(mysql_error());
mysql_select_db($dbname) or die(mysql_error());

$cache_enable = false;
/*comment this caching out to debug*******************/   
$cache_enable = getConfigData('cache', $store);
if ($cache_enable) {
    //see if a cached query is available
    $file = md5($store . $query);
    $file = "var/search/" . $file;
    if (file_exists($file)) {
        //server content from cache if found
        $fh = fopen($file, 'r');
        $theData = fread($fh, filesize($file));
        fclose($fh);
        echo $theData;
        exit();
    }
}
/********************/

//get content from db
$json = '';

//connect and get data store in array
$hasCategory = array();
$suggestion = array();
$description = array();
$sku = array();
$productid = array();
$tieredPricingHtml = array();
$brand = array();
$productprice = array();
$data = array();
$image = array();
$countData = array();
$prodCount = 0;
$catCount = 0;
$authCount = 0;

$catsearch = getConfigData('enablecatalog', $store);
$attributes = getConfigData('searchattr', $store);
$prodLimit = getConfigData('productstoshow', $store);
$catLimit = getConfigData('productstoshow', $store);

$sortby = getConfigData('sortby', $store);

if ($sortby == "name") $sortby = "title";

$sortorder = getConfigData('sortorder', $store);
$enabledescription = getConfigData('enabledescription', $store);
$enableimage = getConfigData('enableimage', $store);

if ($catsearch) {
    $catsearchsql = "cat_title LIKE '%" . mysql_real_escape_string($query) . "%' ";
} else {
    $catsearchsql = " 1=0 ";
}


$query = explode(' ',$query);

$c = 0;$querysql='';
foreach($query as $q) {
    if($c == 0){
        $querysql .= "  OR search_data LIKE '%" . mysql_real_escape_string($q) . "%'";
    } else {
        $querysql .= "  AND search_data LIKE '%" . mysql_real_escape_string($q) . "%'";
    }
    $c++;
}

$attributes = explode(",", $attributes);
$mySql = "SELECT * 
        FROM ajax_search_index 
        WHERE 
            store_id = $store 
            AND ( $catsearchsql 
            $querysql )
        ORDER BY $sortby $sortorder";

/*

SELECT * FROM ajax_search_index 

WHERE store_id = 1 

AND ( cat_title LIKE '%pro hardware%' OR search_data LIKE '%black%' AND search_data LIKE '%chair%' ) ORDER BY title asc

$fh = fopen("var/log/search.log", 'w');
$theData = fwrite($fh, $query);
$theData = fwrite($fh, $store);
$theData = fwrite($fh, $mySql);
fclose($fh);
*/

$result = mysql_query($mySql) or die(mysql_error());

while ($info = mysql_fetch_array($result)) {
    if ($info['type'] == 1) {
        if ($prodLimit > 0) {
            //product info
            $productid[] = $info['product_id'];
            $productprice[] = '$ '.number_format($info['price'],2);
            $tieredPriceHtml[] = $info['tier_price'];
            $suggestion[] = utf8_encode_all($info['title']);
            $sku[] = $info['sku'];
            $data[] = $info['location'];
            $hasCategory[] = false;
            $image[] = $info['image_html'];
            $prodCount++;
            $prodLimit--;
        }
    }
    if ($info['type'] == 2) {
        //category info
        if ($catLimit > 0) {
            $hasCategory[] = true;
            $suggestion[] = $info['title'];
            $data[] = $info['location'];
            $catCount++;
            $catLimit--;
        }
    }
}

$countData[] = $prodCount;
$countData[] = $catCount;
$countData[] = $authCount;

if(is_array($query)){
    $imploded_query = implode(',',$query);
    $query = str_replace(',',' ',$imploded_query);
}

$footertext = "<a href='/catalogsearch/result/?q=" . $query . "'>See All Results</a>";

$result = array('query' => $query,
    'suggestions' => $suggestion,
    'data' => $data,
    'brand' => $brand,
    'image' => $image,
    'sku' => $sku,
    'description' => $description,
    'footertext' => $footertext,
    'countdata' => $countData,
    'id' => $productid,
    'price' => $productprice,
    'tiered_price_html' => $tieredPriceHtml,
    'iscategory' => $hasCategory
);
$str = json_encode($result);

//cache restults if cache is enabled
if ($cache_enable) {
    if (!file_exists('var/search')) {
        mkdir('var/search');
    }
    $myFile = "var/search/" . md5($store . $query);
    $fh = fopen($myFile, 'w') or die("can't open file");
    fwrite($fh, $str);
    fclose($fh);
}

echo $str;

//make the url protocol agnostic so they swap you out of SSL mode
function stripProtocol($url)
{
    return str_replace("http:", "", $url);
}

function getConfigData($var, $store)
{
    $val = "";
    $mySql = "SELECT value 
                        FROM core_config_data 
                        WHERE path = 'ajax_search/general/%s' and scope_id in (0,%d) 
                        ORDER BY scope_id DESC";

    //should we search on category?
    $mySql = sprintf($mySql, $var, $store);

    $result = mysql_query($mySql) or die(mysql_error());
    while ($info = mysql_fetch_array($result)) {
        $val = $info['value'];
    }

    return $val;
}

function utf8_encode_all($dat) // -- It returns $dat encoded to UTF8 
{ 
  if (is_string($dat)) return utf8_encode($dat); 
  if (!is_array($dat)) return $dat; 
  $ret = array(); 
  foreach($dat as $i=>$d) $ret[$i] = utf8_encode_all($d); 
  return $ret; 
} 

function utf8_decode_all($dat) // -- It returns $dat decoded from UTF8 
{ 
  if (is_string($dat)) return utf8_decode($dat); 
  if (!is_array($dat)) return $dat; 
  $ret = array(); 
  foreach($dat as $i=>$d) $ret[$i] = utf8_decode_all($d); 
  return $ret; 
} 


?>