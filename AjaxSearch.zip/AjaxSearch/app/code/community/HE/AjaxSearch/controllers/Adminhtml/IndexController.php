<?php
class HE_AjaxSearch_Adminhtml_IndexController extends Mage_Adminhtml_Controller_Action
{
    public function cleancacheAction() 
    {
    	try {
	    	Mage::helper('ajaxsearch/data')->cleanCache();
	    	$this->_getSession()->addSuccess(Mage::helper('adminhtml')->__('The ajax search cache was cleaned.'));
	    } catch(Exception $e) {
		    $this->_getSession()->addException(
                $e,
                Mage::helper('adminhtml')->__('An error occurred while clearing the ajax search cache.')
            );
	    }
	    $this->_redirect('adminhtml/cache');
    }
    
    public function runindexAction()
	{   
        try {
        	Mage::getResourceModel('ajaxsearch/collection')
                ->indexSearch(1);
    		Mage::helper('ajaxsearch/data')->cleanCache();
	    	$this->_getSession()->addSuccess(Mage::helper('adminhtml')->__('The ajax search table has been generated.'));
	    } catch(Exception $e) {
		    $this->_getSession()->addException(
                $e,
                Mage::helper('adminhtml')->__('An error occurred while creating index table.')
            );
	    }
	    $this->_redirect('adminhtml/cache');
	}
	
	protected function _getSession()
    {
        return Mage::getSingleton('adminhtml/session');
    }
}
