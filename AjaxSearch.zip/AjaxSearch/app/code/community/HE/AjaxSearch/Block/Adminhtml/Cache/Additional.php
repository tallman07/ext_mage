<?php
class HE_AjaxSearch_Block_Adminhtml_Cache_Additional extends Mage_Adminhtml_Block_Cache_Additional
{   
    public function getCleanAjaxUrl()
    {
	    return $this->getUrl('ajaxsearch/adminhtml_index/cleancache');
    }
    
    public function getIndexAjaxUrl()
    {
    	// TODO: use the ajaxsearch/adminhtml_index/runindex action to retain the admin session
    	return $this->getUrl('ajaxsearch/adminhtml_index/runindex');
    }
}
