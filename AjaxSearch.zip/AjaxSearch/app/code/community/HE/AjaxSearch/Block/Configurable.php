<?php

/* @author Human-Element
 * 
 * Block generates the HTML Attributes container
 * For inserting configurable products to the cart
 * 
 */
 
 class HE_AjaxSearch__Block_Configurable extends Mage_Catalog_Block_Product_View_Type_Configurable {
 	 
 	 
 	 
 }

