<?php

$installer = $this;
/* @var $installer Mage_Core_Model_Resource_Setup */

$installer->startSetup();

$installer->run("
DROP TABLE IF EXISTS `search_index`;
DROP TABLE IF EXISTS `ajax_search_index`;
CREATE TABLE IF NOT EXISTS `ajax_search_index` (
  `search_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `image_html` varchar(1000) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `price` decimal(12,0) DEFAULT NULL,
  `tier_price` longtext,
  `iscategory` tinyint(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `cat_title` varchar(255) DEFAULT NULL,
  `search_data` longtext,
  PRIMARY KEY (`search_id`),
  FULLTEXT KEY `search_idx` (`search_data`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=0 ;
	
");

$installer->endSetup();