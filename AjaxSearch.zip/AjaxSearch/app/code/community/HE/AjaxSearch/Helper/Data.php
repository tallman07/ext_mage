<?php
class HE_AjaxSearch_Helper_Data extends Mage_Core_Helper_Abstract
{
    public function cleanCache() 
    {
	  	$this->_rrmdir(Mage::getBaseDir() . '/var/search');
    }
    

    protected function _rrmdir($dir) {

		if (is_dir($dir)) {
			$objects = scandir($dir);
			foreach ($objects as $object) {
				if ($object != "." && $object != "..") {
					if (filetype($dir."/".$object) == "dir") rrmdir($dir."/".$object); else unlink($dir."/".$object);
				}
			}
			reset($objects);
			rmdir($dir);
		}
	}

}