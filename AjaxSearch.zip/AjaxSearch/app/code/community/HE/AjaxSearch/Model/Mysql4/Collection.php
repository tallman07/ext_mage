<?php

class HE_AjaxSearch_Model_Mysql4_Collection extends Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Collection {

    public function getNewCollection($query) {
        /* @var $collection Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Collection */
        Mage::getSingleton('catalog/product_status')->addVisibleFilterToCollection($this);
        Mage::getSingleton('catalog/product_visibility')->addVisibleInSearchFilterToCollection($this);
        $productstoshow = Mage::getStoreConfig('ajax_search/general/productstoshow');
        $attributesarr = array();
        $attributes = array(); // array('name');
        $searchattr = Mage::getStoreConfig('ajax_search/general/searchattr');
        if ($searchattr != '') {
            $attributes = explode(',', $searchattr);
        }

        //push the full name attribute to the stack - have to do this because it not a sort-able attribute on shambhala
        array_push($attributes, 'name');

        $query_array = explode(' ', trim($query));

        $likeStmt = '';
        foreach ($query_array as $query_word) {
            $likeStmt .= '#attr# LIKE %' . $query_word . '% AND ';
        }

        $likeStmt = substr($likeStmt, 0, -strlen(' AND '));
        $andWhere = array();
        foreach ($attributes as $attribute) {

            $this->addAttributeToSelect($attribute, true);
            foreach ($query_array as $query_word) {
                $andWhere[] = $this->_getAttributeConditionSql(
                        $attribute, array('like' => '%' . $query_word . '%')
                );
            }
            $this->getSelect()->orWhere(implode(' AND ', $andWhere));
            $andWhere = array();
        }
        $this
                ->addUrlRewrite()
                ->setPageSize(5);

        $this->load();

        return $this;
    }

    public function getNewCategoryCollection($query, $storeId) {

        $category = Mage::getModel('catalog/category');
        $collection = $category->getCollection();
        $productstoshow = Mage::getStoreConfig('ajax_search/general/productstoshow');
        $collection->addAttributeToSelect('*')
                ->addAttributeToFilter('is_active', 1)
                ->setStoreId($storeId)
                ->setPageSize($productstoshow);

        $query_array = explode(' ', trim($query));

        foreach ($query_array as $query_word) {
            $collection->addFieldToFilter('name', array('like' => '%' . $query_word . '%'));
        }

        $andWhere = array();
        foreach ($query_array as $query_word) {
            if (get_class($collection) == 'Mage_Catalog_Model_Resource_Eav_Mysql4_Category_Flat_Collection') {
                $andWhere[] = $collection->_getConditionSql(
                        'name', array('like' => '%' . $query_word . '%')
                );
            } else {
                $andWhere[] = $collection->_getAttributeConditionSql(
                        'name', array('like' => '%' . $query_word . '%')
                );
            }
        }

        $collection->getSelect()->orWhere(implode(' AND ', $andWhere));
        $andWhere = array();

        return $collection;
    }

	public function indexSearch($store_id = null) {

		
		//Mage::log('Starting Index',0,'tmp.log');
		
		
		if ($store_id == null) {
	    	
	    	$allStores = Mage::app()->getStores();

			foreach ($allStores as $_eachStoreId => $val) {
				$_storeId = Mage::app()->getStore($_eachStoreId)->getId();
				$this->indexSearch($_storeId);
			}
			return $this;
    	}
    	
        //$store_id = Mage::app()->getStore()->getStoreId();
        $collection = Mage::getModel('ajaxsearch/search')->getCollection()->addFieldToFilter('store_id', $store_id);

        //clear all results and remove attribute fields to reindex search
        foreach ($collection as $index) {
            $index->delete();
        }
        
        $this->_indexProducts($store_id);
        $this->_indexCategories($store_id);
        return $this;
    }

    protected function _indexProducts($storeId) {

        $imageheight = Mage::getStoreConfig('ajax_search/general/imageheight');
        $imagewidth = Mage::getStoreConfig('ajax_search/general/imagewidth');
                
        /* @var $collection Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Collection */
        $attributesarr = array();
        $attributes = array(); // array('name');
        $searchattr = Mage::getStoreConfig('ajax_search/general/searchattr');
		
        $this->addAttributeToSelect('price')
             ->addAttributeToSort('name', 'ASC')
             ->addUrlRewrite()
             ->addAttributeToSelect('image')
             ->addStoreFilter($storeId)  							//TODO - add admin selection for choosing to use image, small_image or thumb
        		 ->addAttributeToFilter('status', 1) 			//enabled
             ->addAttributeToFilter('visibility', 4);	//catalog, search

        if ($searchattr != '') {
            $attributes = explode(',', $searchattr);
				}

        foreach ($attributes as $attribute) {
        	$this->addAttributeToSelect($attribute);
        }

        //load the frontend session data so that the tier price html is not blank
        if($storeId){Mage::app()->setCurrentStore($storeId);}
        Mage::app()->getTranslator()->init('frontend');
        Mage::getSingleton('core/session', array('name' => 'frontend'));
        // get layout object  
        $_layout = Mage::getSingleton('core/layout'); 
        //for each product...
        foreach ($this as $_product) {					
					$prep = $searchData = "";

            foreach ($attributes as $attribute) {
            	//$searchData .=  $prep . mysql_real_escape_string($_product[$attribute]);
		$searchData .=  $prep . $_product[$attribute];
							$prep = "|";
            }
            
            //START tiered pricing             
            //store the product's attribute set ID so that it can be retrieved in...
            //__construct() app/code/local/HE/Pentair/Block/Product/View.php
            $_SESSION['my_current_attr_set_id'] = $_product->getAttributeSetId();
            //http://www.magentocommerce.com/boards/viewthread/288627
            $_tierPriceHtml=$_layout->createBlock('catalog/product_view')->getTierPriceHtml($_product);
            //END tiered pricing
            
            $index = Mage::getModel('ajaxsearch/search');
            
            $index->setId(null)
            	->setType(1)
                ->setProductId($_product->getId())
                ->setTitle($_product->getName())
                ->setPrice($_product->getPrice())
                ->setTierPrice($_tierPriceHtml) //add tiered pricing
                ->setSku($_product->getSku())
                ->setSearchData($searchData)
                ->setLocation($_product->getProductUrl())
				->setImageHtml('<img class="ajaxsearchimage" src="'.Mage::helper('catalog/image')->init($_product, 'image')->resize($imagewidth, $imageheight).'" alt="' . $_product->getName() . '">')
                ->setIscategory(0)
                ->setUpdatedAt(now())
                ->setStoreId($storeId)
                ->save();
        }
        //cleanup session used for tiered pricing
        unset($_SESSION['my_current_attr_set_id']);
        
        return $this;
    }

    protected function _indexCategories($storeId) {
        $category = Mage::getModel('catalog/category');
        $collection = $category->getCollection();
        $collection->addAttributeToSelect('*')
                ->addAttributeToFilter('is_active', 1)
                ->setStoreId($storeId);

        foreach ($collection as $cat) {
            $category = Mage::getModel('catalog/category')->load($cat['entity_id']);
            
            //check to see if root of category is store root as well
            $catId = $category->getId();
            $catName = $category->getName();
			
			$index = Mage::getModel('ajaxsearch/search');
            $index->setId(null)
            	->setTitle($catName)
                ->setCatTitle($catName)
                ->setType(2)
                ->setIscategory(1)
            	->setLocation($category->getUrl())
                ->setUpdatedAt(now())
            	->setStoreId($storeId)
                ->save();
        }
        //die();
        return $this;
    }

}
