<?php
class HE_AjaxSearch_Model_Search extends Mage_Core_Model_Abstract
{
	public function _construct()
    {    
        parent::_construct();
    	$this->_init('ajaxsearch/search');
    }    
}