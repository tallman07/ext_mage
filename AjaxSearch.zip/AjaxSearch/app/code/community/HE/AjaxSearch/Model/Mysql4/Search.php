<?php
class HE_AjaxSearch_Model_Mysql4_Search extends Mage_Core_Model_Mysql4_Abstract
{
	public function _construct()
    {    
    	$this->_init('ajaxsearch/search', 'search_id');
    }	
}