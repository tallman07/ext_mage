<?php 
// echo $_REQUEST["prefix"].":".strftime("%c");
echo $_REQUEST["prefix"].":".date_default_timezone_set('America/New_York');
?>