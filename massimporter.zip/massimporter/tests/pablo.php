<?php
 require_once("../inc/magmi_importer.php");
 $mmi=new MagentoMassImporter();
 $mmi->import(array("filename"=>dirname(__FILE__)."/pablo.csv", "mode"=>"create"));