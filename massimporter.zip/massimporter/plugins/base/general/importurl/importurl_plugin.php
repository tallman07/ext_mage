<?php
class Magmi_ImportUrlPlugin extends Magmi_GeneralImportPlugin
{
	public function getPluginInfo()
	{
		return array("name"=>"Mass Importer Import Url UI",
					 "author"=>"onerockwell",
					 "version"=>"1.0.3",
					 "url"=>$this->pluginDocUrl("Magmi_Import_Url_UI"));
	}
	public function initialize($params)
	{
		
	}
}