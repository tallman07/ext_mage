<?php

class HE_AutoInvoice_Model_Observer extends Mage_Core_Model_Abstract
{
    /**
     * Mage::dispatchEvent($this->_eventPrefix.'_save_after', $this->_getEventData());
     * protected $_eventPrefix = 'sales_order';
     * protected $_eventObject = 'order';
     * event: sales_order_save_after
     */
    public function autoInvOrder($observer)
    {
        $order = $observer->getEvent()->getOrder();

        //if the store is in off line mode, then do no auto invoice
        if (Mage::helper('connector')->checkOffLine()) {
            if (Mage::helper('connector')->logIt(2))
                Mage::log("AutoInvoice - order : ". $order->getIncrementId() ." no invoice, system is off line mode",1,"ecometry_connect.log");
            return $this;
        }

        $orders = Mage::getModel('sales/order_invoice')->getCollection()
                        ->addAttributeToFilter('order_id', array('eq'=>$order->getId()));
        $orders->getSelect()->limit(1);  
 
        if ((int)$orders->count() !== 0) {
            return $this;
        }

        $cartId = Mage::getSingleton('checkout/session')->getEcometryCartId();
        if (Mage::helper('connector')->logIt(2))
            Mage::log("AutoInvoice  - starting order : ".$order->getIncrementId() . " cartID ".$cartId,1,"ecometry_connect.log");

        //TODO VERIFY THAT THE ECOMETRY ORDER WAS SUCCESSFUL
        if (($order->getState() == Mage_Sales_Model_Order::STATE_NEW) &&
			($order->getPayment()->getMethod() == 'ccsave')) {
 
            try {
                if(!$order->canInvoice()) {
                    $order->addStatusHistoryComment('AutoInvoice: Order cannot be invoiced.', false);
                    $order->save();
                }
 
                //START Handle Invoice
                $invoice = Mage::getModel('sales/service_order', $order)->prepareInvoice();
 
                $invoice->setRequestedCaptureCase(Mage_Sales_Model_Order_Invoice::CAPTURE_OFFLINE);
                $invoice->register();
 
                $invoice->getOrder()->setCustomerNoteNotify(false);
                $invoice->getOrder()->setIsInProcess(true);
                $order->addStatusHistoryComment('AutoInvoice: Automatically INVOICED based on EEM - cart ID '. $cartId, false);
 
                $transactionSave = Mage::getModel('core/resource_transaction')
                    ->addObject($invoice)
                    ->addObject($invoice->getOrder());
 
                $transactionSave->save();
                if (Mage::helper('connector')->logIt(2))
                    Mage::log("AutoInvoice - order : ".$order->getIncrementId() . "complete",1,"ecometry_connect.log");

                $payment = $order->getPayment();
                $payment->setCcNumberEnc($payment->encrypt('xxxx-'.$payment->getCcLast4()));
                $payment->save();
                //END Handle Invoice
 
            } catch (Exception $e) {
                if (Mage::helper('connector')->logIt(1))
                    Mage::log("AutoInvoice - order : ". $order->getIncrementId() ." Exception occurred while creating invoice. Exception message: '.$e->getMessage()",1,"ecometry_connect.log");
            }
        } else {
            if (Mage::helper('connector')->logIt(1))
                Mage::log("AutoInvoice - order : ".$order->getIncrementId()." is not in the correct state",1,"ecometry_connect.log");
        }
 
    return $this;
    }
}