<?php
echo $_REQUEST["prefix"] . ":" . strftime("%c");
?>