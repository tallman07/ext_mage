
<div class="plugin_description">
	This plugin enables magmi <b>mass updates</b> by selecting existing
	products from magento database
</div>

