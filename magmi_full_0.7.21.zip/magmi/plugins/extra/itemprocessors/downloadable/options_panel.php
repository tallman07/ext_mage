<div class="plugin_description">
	This plugin import downloadable products
	<p>
		A column name
		<code>"links"</code>
		must contain links attribute.
	</p>
</div>


