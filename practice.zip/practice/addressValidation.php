<?php 
$address = 'Wall St. 123,  ';
$address = 'M-166, Sec-12, Pratap Vihar, GZB (U.P)';
$regExp = '/^[\w\s.-\( )]+,\s*[\w\s.-]+$/';


if (preg_match($regExp, $address)) {
	echo 'Valid Address';
} else {
	echo 'Invalid Address';
}
?>