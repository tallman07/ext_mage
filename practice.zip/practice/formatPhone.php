<?php 

var_dump(preg_match('/[^0-9x,]/', '123456789x1234'));

function format_phone($phone) {
		
	$num = preg_replace("/(99)?(\d{2})(\d{1})(\d{3})(\d{3})(\d{4})([0-9x,])/i", "+$1 $2-$3-$4-$5 $6", $phone);
	
	return $num;
} 

$formattedPhone = array (
						'5678901' => '567-8901', //ok
						'2345678901' => '234-567-8901',//ok
						'5678901,,1234' => '567-8901,,1234',
						'5678901x1234' => '567-8901 x1234',//ok
						'2345678901x1234' => '234-567-8901 x1234',//ok
						'2345678901,,1234' => '234-567-8901,,1234', //ok
						'12345678901x1234' => '1-234-567-8901 x1234',//ok
						'9912345678901,1234' => '+99 1-234-567-8901 ,1234',//ok
						'9912345678901x1234' => '+99 1-234-567-8901 x1234'//ok
					);
	
	$same = false;			
	
	foreach ($formattedPhone as $key => $value) {
		$formatted = format_phone($key);
		$same = ($formatted == $value) ? true : false;
		
		if ($same)
			$txt = "<b>Yes</b>";
		else
			$txt = 'Noops';
			
		echo "$key => $value Formatted value&nbsp;&nbsp;:: " . $formatted ." Is same: " .$txt . "<br />";
	}
?>