<?php 

/*function format_phone($phone) {
	if (strlen($phone) == 7) {
        return preg_replace("/([0-9]{3})([0-9]{4})/", "$1-$2", $phone);
	} else if (strlen($phone) == 10) {
        return preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})/", "($1) $2-$3", $phone);
	} else if (strpos($phone,',') !== false) { 
		return preg_replace("/([0-9]{3})([0-9]{4})([0-9]{5})/", "($1) $2-$3", $phone);
	} else {
        return $phone;
	}
}*/

function format_phone($phone) {
	//echo "LENGH " . strlen($phone)." <br />";
	switch (strlen($phone)) {
		case 7: {
			$num = preg_replace("/(\d{3})(\d{4})/i", "$1-$2", $phone);
			break;
		}
		
		case 10: {
			$num = preg_replace("/(\d{3})(\d{3})(\d{4})/i", "$1-$2-$3", $phone);
			break;
		}
		
		case 12: {
			$num = preg_replace("/(\d{3})(\d{4})(\w|s|\'+)/i", "$1-$2 $3", $phone);
			break;
		}
		
		case 13: {
			$num = preg_replace("/(\d{3})(\d{4})([0-9x,])/i", "$1-$2$3", $phone);
			break;
		}
		
		case 15: {
			$num = preg_replace("/(\d{3})(\d{3})(\d{4})(\w|s|\'+)/i", "$1-$2-$3 $4", $phone);
			break;
		}
		
		case 16: {
			$num = preg_replace("/(\d{1})(\d{3})(\d{3})(\d{4})(\w|s|\'+)/i", "$1-$2-$3-$4 $5", $phone);
			if (stripos($phone,",") !== false) {
				$num = preg_replace("/(\d{3})(\d{3})(\d{4})([0-9x,])/i", "$1-$2-$3$4", $phone);
			}
			break;
		}
		
		case 18: {
			$num = preg_replace("/(\d{2})(\d{1})(\d{3})(\d{3})(\d{4})([0-9x,])/i", "+$1 $2-$3-$4-$5 $6", $phone);
			break;
		}
		
		default:
			$num = $phone;
	}
	
	return $num;
}


//$phone  = '5678901,,1234';
//$phone  = '2345678901';
//echo format_phone($phone);

//$string = '9912345678901x1234';

//$pattern = '/(\d{2})(\d{1})(\d{3})(\d{3})(\d{4})(\w|s|\'+)/i';

//$replacement = '+$1 $2-$3-$4-$5 x';

// echo preg_replace($pattern, $replacement, $string)


$formattedPhone = array (
						'5678901' => '567-8901', //ok
						'2345678901' => '234-567-8901',//ok
						'5678901,,1234' => '567-8901,,1234',
						'5678901x1234' => '567-8901 x1234',//ok
						'2345678901x1234' => '234-567-8901 x1234',//ok
						'2345678901,,1234' => '234-567-8901,,1234', //ok
						'12345678901x1234' => '1-234-567-8901 x1234',//ok
						'9912345678901,1234' => '+99 1-234-567-8901 ,1234',//ok
						'9912345678901x1234' => '+99 1-234-567-8901 x1234'//ok
					);
	
	$same = false;			
	
	foreach ($formattedPhone as $key => $value) {
		$formatted = format_phone($key);
		$same = ($formatted == $value) ? true : false;
		
		if ($same)
			$txt = "<b>Yes</b>";
		else
			$txt = 'Noops';
			
		echo "$key => $value Formatted value&nbsp;&nbsp;:: " . $formatted ." Is same: " .$txt . "<br />";
	}
	
	$regex = '^[(]?[2-9]{1}[0-9]{2}[) -]{0,2}' . '[0-9]{3}[- ]?' . '[0-9]{4}[ ]?' . '((x|ext)[.]?[ ]?[0-9]{1,5})?$';

?>