<?php 
	$str = '152,90,84,151,85,56,139';
    
	$arr = Array(
		Array(
            'tt_meta_fields' => Array
                (
                    'id' => 84,
                    'account_id' => 3,
                    'object_type' => 'tt_product',
                    'field_name' => 'SHORT_DESCRIPTION',
                    'active' => 1,
                    'field_type' => 'textarea'
                )

        ),
		Array(
            'tt_meta_fields' => Array
                (
                    'id' => 85,
                    'account_id' => 3,
                    'object_type' => 'tt_product',
                    'field_name' => 'LONG_DESCRIPTION',
                    'active' => 1,
                    'field_type' => 'textarea',
                )

        ),
        Array(
            'tt_meta_fields' => Array
                (
                    'id' => 56,
                    'account_id' => 3,
                    'object_type' => 'tt_product',
                    'field_name' => 'ITEM_ID',
                    'active' => 1,
                    'field_type' => 'text'
                )

        ),
    Array
        (
            'tt_meta_fields' => Array
                (
                    'id' => 90,
                    'account_id' => 3,
                    'object_type' => 'tt_product',
                    'field_name' => 'VENDOR_NO_CHAR',
                    'active' => 1,
                    'field_type' => 'text'
                )

        ),
        Array
        (
            'tt_meta_fields' => Array
                (
                    'id' => 152,
                    'account_id' => 3,
                    'object_type' => 'tt_product',
                    'field_name' => 'SHELF_DESCRIPTION',
                    'active' => 1,
                    'field_type' => 'text'
                )

        ),
		Array
        (
            'tt_meta_fields' => Array
                (
                    'id' => 139,
                    'account_id' => 3,
                    'object_type' => 'tt_product',
                    'field_name' => 'CURRENT_UPC',
                    'active' => 1,
                    'field_type' => 'text'
                )

        ),
		Array
        (
            'tt_meta_fields' => Array
                (
                    'id' => 151,
                    'account_id' => 3,
                    'object_type' => 'tt_product',
                    'field_name' => 'LINK_TO_VANITY',
                    'active' => 1,
                    'field_type' => 'text'
                )

        )
	);
	
	$mod = array();
	
	$arrs  = explode(",", $str);
	foreach ($arrs as $id) {
		foreach ($arr as $key => $val) {
			if ($id == $val['tt_meta_fields']['id'])
				$mod[] = $val['tt_meta_fields']['field_name'];
		}
	} echo '<pre>'; print_r($mod);
?>