<?php 

$string = '1-234-567-8901-x1234';
$find = '-';
$replace = ' ';
$result = preg_replace(strrev("/$find/"),strrev($replace),strrev($string),1);
//echo strrev($result); //output: this is my world, not my farm

//die;
$enteredPhone  = array (
						'1-234-567-8901',
						'1-234-567-8901 x1234',
						'1-234-567-8901, 1234',
						'1-234-567-8901,,1234',
						'+99 1-234-567-8901 x1234',
						'+99 1-234-567-8901,,1234',
						'1 (234) 567-8901',
						'(234) 567-8901',
						'1.234.567.8901',
						'1.234.567.8901 x1234',
						'1.234.567.8901,,1234',
						'1.234.567.8901, 1234',
						'1.234.567.8901,,1234',
						'234.567.8901',
						'1/234/567/8901',
						'12345678901'
				);
				
$strings = array (
				'1-234-567-8901' => '12345678901',
				'1-234-567-8901 x1234' => '12345678901x1234',
				'1-234-567-8901, 1234' => '12345678901,1234',
				'1-234-567-8901,,1234' => '12345678901,,1234',
				'+99 1-234-567-8901 x1234' => '9912345678901x1234',
				'+99 1-234-567-8901,,1234' => '9912345678901,,1234',
				'1 (234) 567-8901' => '12345678901',
				'(234) 567-8901' => '2345678901',
				'1.234.567.8901' => '12345678901',
				'1.234.567.8901 x1234' => '12345678901x1234',
				'1.234.567.8901, 1234' => '12345678901,1234',
				'1.234.567.8901,,1234' => '12345678901,,1234',
				'234.567.8901' => '2345678901',
				'1/234/567/8901' => '12345678901',
				'12345678901' => '12345678901'
			);
			
$isCorrect = false;			
foreach ($strings as $key => $value) {
	$formatted = preg_replace('/[^0-9x,]/','',$key);
	
	if ($formatted == $value) 
		$isCorrect = true;
	
	$valid = ($isCorrect) ? 'Correct' : 'Incorrect';
	
	echo 'Original String ' . $key .' Formatted string ' . $formatted . "<b> " . $valid. "</b>". "<br />";
}
ECHO "<br /><br />";
//echo '<pre>';print_r($strings);

$formattedPhone = array (
						'5678901' => '567-8901', //ok
						'2345678901' => '234-567-8901',//ok
						'5678901,,1234' => '567-8901,, 1234',
						'5678901x1234' => '567-8901 x1234',//ok
						'2345678901x1234' => '234-567-8901 x1234',//ok
						'2345678901,,1234' => '234-567-8901,,1234', //ok
						'12345678901x1234' => '1-234-567-8901 x1234',//ok
						'9912345678901,1234' => '+99 1-234-567-8901 ,1234',//ok
						'9912345678901x1234' => '+99 1-234-567-8901 x1234'//ok
					);

foreach ($formattedPhone as $key => $value) {
	$str1 = '';
	$str2 = '';
	if (stripos($key,",") !== false || stripos($key,"x") != false) {
		// Stuff for phone number having , and x
		$delm = " ";
		if (stripos($key,",,") !== false) {
			$delm = ",,";
		} else if (stripos($key,",") !== false) {
			$delm = ",";
		} else if (stripos($key,"x") !== false) {
			$delm = "x";
		}
		
		$arr  = explode($delm,$key);
		
		$str2 = $delm . end($arr);
		$str1 = implode("-",array_reverse(explode("-",getPhone(substr($arr[0],0,-4),$key))));
		$str1 .= "-" . substr($arr[0],-4);
		
		$str1 = str_lreplace($delm," ",$str1);
		echo "$key => $value and FORMATTED VALUE IS: " . $str1 ." ".$str2."<br />";
		
	} else {
		$str2 = substr($key,-4); 
		$str1 = implode("-",array_reverse(explode("-",getPhone(substr($key,0,-4),$key))));
		echo "$key => $value and FORMATTED VALUE IS: " .$str1 . "-" .$str2."<br />";
	}
}



function getPhone($phoneString,$originalPhone) {
	$str = "";
	if (strlen($phoneString) > 3) {
		$digits = substr($phoneString,-3);
		$str .= $digits. "-". getPhone(substr($phoneString,0,-3),$originalPhone);
	} else {
		if (preg_match('/^[9]{2}1?/',$phoneString) && strpos($originalPhone,"991") == '0') {
			$num = preg_replace("/(\d{2})(\d{1})/i", "+$1 $2", $phoneString);
			$str  .= $num;
		} else {
			$str  .= $phoneString;
		}	
	}
	
	return $str;
}

function str_lreplace($search, $replace, $subject) {
    $pos = strrpos($subject, $search);

    if($pos !== false) {
        $subject = substr_replace($subject, $replace, $pos, strlen($search));
    }

    return $subject;
}

?>