<?php 
$rr = 'array(1) { 
	["TtReport"]=> array(9) 
		{ ["user_id"]=> int(3) 
		  ["report_name"]=> string(13) "Test Case 123" 
		  ["tt_report_types_id"]=> int(1) 
		  ["report_notes"]=> string(5) "Admin" 
		  ["report_access"]=> int(1) 
		  ["arrange_ids_order"]=> string(0) "" 
		  ["checked_meta_fields"]=> string(0) "" ["modified"]=> string(19) "2013-12-31 05:21:23" ["created"]=> string(19) "2013-12-31 05:21:23" } }';

echo '<pre>';print_r( json_decode($rr,true));
?>