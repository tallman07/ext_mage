<?php 
$numbers = array(
"123 555 6789",
"1-(123)-555-6789",
"(123-555-6789",
"(123).555.6789",
"123 55 6789",
"555.888.6789");

foreach ($numbers as $number) {
	//echo "$number is ";

	if (preg_match("/^
	
			(1[-\s.])?	# optional '1-', '1.' or '1'
			( \( )?		# optional opening parenthesis
			\d{3}		# the area code between 3 to 6
			(?(2) \) )	# if there was opening parenthesis, close it
			[-\s.]?		# followed by '-' or '.' or space
			\d{3}		# first 3 digits
			[-\s.]?		# followed by '-' or '.' or space
			\d{4}		# last 4 digits

			$/x",$number)) {

		//echo "valid<br />";
	} else {
		//echo "invalid<br />";
	}
}

/* prints

123 555 6789 is valid
1-(123)-555-6789 is valid
(123-555-6789 is invalid
(123).555.6789 is valid
123 55 6789 is invalid

*/

$text = 'TalK7_007';
$text1 = 'TalK7_007~!@#%%^&';


	/*if (preg_match('/^[a-zA-Z0-9_-]{5,31}$/', $text))
		echo 'valid user name: <b>' .$text."</b>";
	else 
		echo 'Invalid user name chosen ' .$text;*/
$regExp = '/^(1[-\s.])?( \( )?\d{3}(?(2) \) )[-\s.]?\d{3}[-\s.]?\d{4}$/x';	
$phone  =  '(555).888.1234';	
$phone  =  '1-(123)-555-6789';	
//echo (preg_match($regExp, $phone)) ? 'CORRECT' : 'INCORRECT';

try {
	//$ee = shell_exec('git branch') ;
	$ee = shell_exec('mkdir test123') ;
	//var_dump($ee);
} catch (Exception $ex) {
	echo $ex->getMessage();
}
$date="9000.11.31"; # 0014 

if ( preg_match("/^([2-9]{1}[0-9]{3})\.(0[1-9]|1[0-2])\.(0[1-9]|[1-2][0-9]|3[0-1])$/",$date))
    {
        echo 'VALID DATE'."<br />";
    }else{
        echo 'INVALID DATE'."<br />";
    }
	
	##+91-9990976911
	##9990976911
	#(+91)-9990976911
	#(+91) 999 097 6911
	#(+91)-999-097-6911
	#(+91).999.097.6911
	#09990976911
	
	$phone = '19990976911';
	
	if( !preg_match("/^([0-1])?[-\s.]?[0-9]{3}[-\s.]?[0-9]{3}[-\s.]?[0-9]{4}$/i", $phone) ) {
		echo 'Please enter a valid phone number'."<br />";
	} else {
		echo 'valid phone number found'."<br />";
	}
	$email_address = 'tinkeshk@chetu.com';
	$emailFilter = '/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/';
	if( !preg_match($emailFilter, $email_address)) {
        echo '<br />INVALID EMAIL '."<br />";
    } else {
		echo '<br />VALID EMAIL'."<br />";
	}
	
	// Valid user_name check
	 
	#and length 5 min and max 30
	
	$valid_user_names = array(
								"Tallman_007sep2013", #valid
								"kumar_tinkesh2013", #valid
								"007.tinkesh", #valid
								"kumar.tinkesh2013", #valid
								"kumar.tinkesh9", #valid
								"tallman010_sep2013", #valid
								"tallman_010", #valid
								"viet.tallman", #valid
								"viet.tallman", #Invalid
								"testusername", #valid
								"tet_", #Invalid
								"kumar.123", #Invalid
							);
	//$userNameRegExp = '/^([a-zA-Z0-9\._-]){5,30}+$/';
	$userNameRegExp =   '/^(?=[a-z0-9]+(?:[._][a-z0-9]+)?\z)[a-z0-9._]{5,20}\z/ix';
	foreach ($valid_user_names as $user_name) {
		if (preg_match($userNameRegExp, $user_name)) {
			echo 'The user name '.$user_name. ' is: valid' . '<br />';
		} else {
			echo 'The user name '.$user_name. ' is: <b>invalid</b><br />';
		}
	}
?>