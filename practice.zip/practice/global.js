/*var Animal = function() {
    this.color = "Pink";
}

Animal.prototype.run = function() {
    console.log("Base class run");
}
Animal.prototype.sleep = function() {
    console.log("sleep in parent...");
}
Animal.prototype.eat = function() {
    console.log("EAT in parent class ");
}

$.extend(Animal.prototype, {
    run: function() {
        console.log("Extended class run");
    },
    sleep: function() {
        console.log("Sleep in child...");
    },
    eat: function() {
		this.color = 'RED in extended class';
        console.log("Eat in child");
    }
});

var Cat = function() {
    Animal.apply(this, arguments);

    this.name = name;
    console.log("My name is " + this.name +
                " and my color is " + this.color);
}
Cat.prototype = Object.create(Animal.prototype);
$.extend(Cat.prototype, {
    drinkMilk: function() {
        console.log("lplplplplplp");
    },
    fightOtherCat: function() {
        console.log("Mirrrrrrrccchhhhh");
    }
});




var o = new Animal();
o.run();
o.eat();
console.log('The coloris ' + o.color);*/



function inherit(base, methods) {
    var sub = function() {
        base.apply(this, arguments); // Call base class constructor

        // Call sub class initialize method that will act like a constructor
        this.initialize.apply(this, arguments);
    };
    sub.prototype = Object.create(base.prototype);
    $.extend(sub.prototype, methods);
    return sub;
}

var Animal = function() {
    this.color = "Pink";
}
$.extend(Animal.prototype, {
    run: function() {
        console.log("Wuuuuuuuuuuuuushhhhhh");
    },
    sleep: function() {
        console.log("ZZZzzzZZZzzzZZZzzzzzz...");
    },
    eat: function() {
        console.log("HmnmnmHmmnmnm..BURP");
    }
});

var Cat = inherit(Animal, {
    initialize: function(name) {
        this.name = name;
        console.log("My name is " + this.name +
                    " and my color is " + this.color);
    },
    drinkMilk: function() {
        consoloe.log("lplplplplplp");
    },
    fightOtherCat: function() {
        console.log("Mirrrrrrrccchhhhh");
    },
    sleep: function() {
        console.log("rrr...rrr...rrr...");
        Animal.prototype.sleep();
    }
});


var mutzi = new Cat("Mutzi");
mutzi.run();
mutzi.fightOtherCat();
mutzi.sleep();







function employee(name, jobtitle, born) {
	this.name = name;
	this.jobtitle = jobtitle;
	this.born = born;
}

var fred=new employee("Tinkesh Kumar","Software Engg.",'20-04-1987');
employee.prototype.salary = null;
fred.salary=31000;

//document.write(fred.name+ '' + '- ' + fred.jobtitle + ' getting INR:' + fred.salary);
