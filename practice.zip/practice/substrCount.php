<?php 
$str = 'tinkesh kumar malam you can not send 5:15 before 11:30 
		Manage-Update/add vendor contact-phone numbers
		Please add fields to Vendor Contact inFormation';

//echo substr_count($str, '\n');

//print_r (explode("\n", $str));

$lines_arr = preg_split('/\n/',$str);
//print_r($lines_arr);
$num_newlines = count($lines_arr); 
//echo $num_newlines."<br>";



//echo count( explode(PHP_EOL, $str) );


echo $dd = date('d-m-Y h:i:s', '1392395051');


//echo strtotime('14-02-2014');

?>