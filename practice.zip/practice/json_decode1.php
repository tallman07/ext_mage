<?php 

$str = '[{"contact_id":"319"},{"firstname":"zxz"},{"lastname":"zxz"},{"title":""},{"email":"zxzx@ass.com"},{"login":"1111"},{"password":"1111"},{"confirm-password":"1111"},{"phone1":""},{"phone2":""},{"phone3":""},{"fax":""},{"address1":""},{"address2":""},{"city":""},{"state":""},{"zip":""},{"country":""},{"companies":"388"},{"TtProductCategory":null},{"companyId":388}]';

foreach (json_decode($str,true) as $key=>$val) {
	$tt[$key] = $val;
}

echo '<pre>';print_r($tt);