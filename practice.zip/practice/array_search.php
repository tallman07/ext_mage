<?php 

$array = array(
				0 => 'IS_BASE_ITEM',
				1 => 'START_DATE',
				2 => 'VENDOR_NO_CHAR',
				3 => 'CURRENT_UPC'
			);

 $key = array_search('START_DATE', $array); // $key = 2;
 $key = array_search('CURRENT_UPC', $array);   // $key = 1;
 
 $arr1 = array(
    'a' => '42', 
    'b' => '551',
    'c' => '512',
    'd' => 'gge',
) ;


$arr2 = array(
    'd' => 'ordered',
    'b' => 'is',
    'c' => 'now',
    'a' => 'this', 
) ;

$arr2ordered = array() ;

foreach (array_keys($arr1) as $key) {
    $arr2ordered[$key] = $arr2[$key] ;
}echo '<pre>';print_r ($arr2ordered);
?>