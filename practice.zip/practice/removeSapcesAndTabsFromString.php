<?php

$string1 = '*         Working on to fix the bugs reported by QA in the existing timetrack application.

*         Working on the Walmart user not able to update a sample with Sample Return Instruction field under Sample Requested tab.';

$string2 = '*         	Working      on to fix the bugs reported by QA in the existing timetrack application .

*         Working on the Walmart user not able to update a sample with 


Sample Return Instruction field under Sample        Requested 	tab     .  ';


//$string = trim(preg_replace('/\t/g', '', $string));
//preg_replace("/\s+/", " ", $string);
echo "Before String1==: " . $string1 . "<br /><br />"; 
echo "Before String2==: " . $string2 . "<br /><br />"; 

$string2 = preg_replace("/\s+\./", ".", trim($string2));

$string1 = preg_replace("/[\r\n\t\s]+/", " ", trim($string1));
$string2 = preg_replace("/[\r\n\t\s]+/", " ", trim($string2));

echo "After String1===: " . $string1 . "<br /><br />"; 
echo "After String2===: " . $string2 . "<br><br>";

$flag = strcmp($string1, $string2);

if ($flag === 0) {
	echo '<b>Note:</b> Both String are same';
} else {
	echo '<b>Note:</b> Both string are different';
}

?>