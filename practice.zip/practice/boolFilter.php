<?php $str = '{
    "filtered" : {
        "query" : {
            "queryString" : {
                "default_field" : "message",
                "query" : "elasticsearch"
            }
        },
        "filter" : {
            "bool" : {
                "must" : {
                    "term" : { "tag" : "wow" }
                },
                "must_not" : {
                    "range" : {
                        "age" : { "from" : 10, "to" : 20 }
                    }
                },
                "should" : {
                     "term" : { "tag" : "sometag" }
                }
            }
        }
    }
}';

echo "<pre>";
print_r( json_decode($str,true) );

?>