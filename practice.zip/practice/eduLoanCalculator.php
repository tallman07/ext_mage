<?php 
if (count($_POST)) {
	//$initialAmount = number_format(198220.82252344, 2, '.', '');
	$initialAmount = @number_format($_POST['initial_amount'], 2, '.', '');
	$initial = $initialAmount;
	$rate = $_POST['intr'];
	$RD = $_POST['RD'];

	$totalDeposit = 0;
	$totalIntrest = 0;
	$months = $_POST['time'];


	for ($i = 1; $i <= $months; $i++) {
		if ($i == 1 && @$_POST['lastpaid'] == 'yes') {
			$outstanding = number_format(($initialAmount- $RD), 2, '.', '');
			$intr = 0;
		} else {
			$intr =  number_format(($initialAmount * $rate) / (100 * 12), 2, '.', '');
			$outstanding = number_format(($initialAmount + $intr) - $RD, 2, '.', '');
		}
		
		$initialAmount = number_format($outstanding, 2, '.', '');
		echo "Month $i " . "Initial amt $outstanding and 
			Intr $intr and final amt === " .$initialAmount ." <br />";
		$totalIntrest = ($totalIntrest + $intr);
		$totalDeposit += $RD;
	}

	echo "<br /><br />Total Intrest: " . "<b>" . $totalIntrest . "</b>" . "<br /><br />";
	echo 'Total money submitted: ' . "<b>" . $totalDeposit . "</b><br /><br />";

	$totalCredit = $totalDeposit - $totalIntrest;
	echo "Totla credit value: " . "<b>" . $totalCredit . "</b><br /><br />";

	$outstandingAmount = $initial - $totalCredit;
	echo "Totla outstanding value after $months months : " . "<b>" . $outstandingAmount . "</b>";

}
?>
<html>
<head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="global.js"></script>

<title = "test"></title>
</head>
<body>
	
<h2 class='chzn_title'>Loan Calculator</h2>

<div id='userForm' class="formWrapper">
	<form id='userForm' method="post">
		<div>
			<input type='hidden' id='contact_id'>
			<div class='chzn-side required'>
				<label>Initial Amount</label>		
				<input class='chzn-input' type='text' name='initial_amount' value='<?php echo @$_POST['initial_amount']?>'>
			</div>
			<div class='chzn-side required'>
				<label>Intrest Rate</label>
				<input class='chzn-input' type='text' name='intr' value='<?php echo @$_POST['intr']?>'>
			</div>
			<div class='chzn-side'>
				<label>Time</label>			
				<input class='chzn-input' type='text' name='time' value='<?php echo @$_POST['time']?>'>
			</div>
			<div class='chzn-side required'>
				<label>Deposit Amount</label>			
				<input class='chzn-input' type='text' name='RD' value='<?php echo @$_POST['RD']?>'>
			</div>
			<div class='chzn-side required'>
				<label>Last Paid</label>			
				<input class='chzn-input' type='checkbox' name='lastpaid' value='yes' <?php if (@$_POST['lastpaid'] == 'yes') : ?>checked<?php endif; ?>>
			</div>
		</div>
		<div class="form_footer">
 	<div class="form_uber">	
	<div class="form_uber">
    	<input type="submit" value="Calculate outstanding amount" />
    </div>
    </div>
</div>

	</form>
</div>

</body>