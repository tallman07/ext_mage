<?php

class HE_Tools_Block_Catalog_Product_List_Toolbar extends Amasty_Shopby_Block_Catalog_Product_List_Toolbar 

{

	public function getCanonicalPagination() {
	 	
	 	// Check to determine if we are running in HTTP or HTTPS
		if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) { 
			$url_prefix = "https://";
		} else {
			$url_prefix = "http://";
		}
		
		//  Page variables
		$totalResults = $this->getTotalNum();
	 	$isFirstPage = $this->isFirstPage();
	 	$isLastPage = 0;
	 	$lastPage = $this->getLastPageNum();
	 	
	 	//echo $totalResults."<br />";
				
		// Determine the entire request uri and strip off the query string
		$requestUri = $_SERVER['REQUEST_URI'];		
		$pathInfo = strtok($requestUri,"?");
			
		// reassemble the canonical url
		$url = $url_prefix . $_SERVER['HTTP_HOST'] . $pathInfo;
			
		// check the query string for dir, mode, and order to determine whether to retermin the the link tag
		$query_array = array();
		$queryString = $_SERVER['QUERY_STRING'];
		$viewAsArray = parse_str($queryString, $query_array);
	
		foreach($query_array as $param=>$val){
			
			//echo $val."<br />";
			//echo $lastPage."<br />";
			
			if($param == "p"){
				$currentPage = $val;
			} 
			if($val == $lastPage){
				$isLastPage = 1;
			}
		}
		
		$next = $currentPage + 1;
		$prev = $currentPage - 1;
	 	 	
	 	//echo $isLastPage."<br />"; 	
	 	 	
	 	if($isFirstPage){
	 		$canonicalPagination = "" .
	 			"<link rel='canonical' href='".$url."' type='image/x-icon' />" .
	 			"<link rel='next' href='".$url."?p=".$next."' type='image/x-icon' />";
	 	} elseif($isLastPage == 1) {
	 		$canonicalPagination = "" .
	 			"<link rel='canonical' href='".$url."' type='image/x-icon' />" .
	 			"<link rel='prev' href='".$url."?p=".$prev."' type='image/x-icon' />";
	 	} elseif($currentPage == "2") {
	 		$canonicalPagination = "" .
				"<link rel='canonical' href='".$url."' type='image/x-icon' />" .
				"<link rel='next' href='".$url."?p=".$next."' type='image/x-icon' />" .
	 			"<link rel='prev' href='".$url."' type='image/x-icon' />";
	 	} else {
	 		//echo "lastcond";
	 		$canonicalPagination = "" .
				"<link rel='canonical' href='".$url."' type='image/x-icon' />" .
				"<link rel='next' href='".$url."?p=".$next."' type='image/x-icon' />" .
	 			"<link rel='prev' href='".$url."?p=".$prev."' type='image/x-icon' />";
	 	}
	 	
	 	
	 	//Mage::getSingleton('customer/session')->setCanonicalPagination($canonicalPagination);
	 	
		return $canonicalPagination;
	 	
	}
    
}

?>
