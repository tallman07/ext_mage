<?php
/**
 * Magento Enterprise Edition
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magento Enterprise Edition License
 * that is bundled with this package in the file LICENSE_EE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.magentocommerce.com/license/enterprise-edition
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * @category    Mage
 * @package     Mage_Page
 * @copyright   Copyright (c) 2012 Magento Inc. (http://www.magentocommerce.com)
 * @license     http://www.magentocommerce.com/license/enterprise-edition
 */


/**
 * Html page block
 *
 * @category   Mage
 * @package    Mage_Page
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class HE_Tools_Block_Page_Html_Head extends Mage_Page_Block_Html_Head
{
    public function getCanonicalLinks() {
		
		// Check to determine if we are running in HTTP or HTTPS
		if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) { 
			$url_prefix = "https://";
		} else {
			$url_prefix = "http://";
		}
		
		$canonicalLinkTag = "";
		
		// Determin the entire request uri and strip off the query string
		$requestUri = $_SERVER['REQUEST_URI'];		
		$pathInfo = strtok($requestUri,"?");
		
		// reassemble the canonical url
		$url = $url_prefix . $_SERVER['HTTP_HOST'] . $pathInfo;
		
		// check the query string for dir, mode, and order to determine whether to retermin the the link tag
		$queryString = $_SERVER['QUERY_STRING'];
		$viewAsArray = array('dir','mode','order');

		if (strpos($queryString,'dir') !== false) {
			$canonicalLinkTag = "<link rel='canonical' href='".$url."' type='image/x-icon' />";
		} elseif(strpos($queryString,'mode') !== false) {
			$canonicalLinkTag = "<link rel='canonical' href='".$url."' type='image/x-icon' />";
		} elseif(strpos($queryString,'order') !== false) {
			$canonicalLinkTag = "<link rel='canonical' href='".$url."' type='image/x-icon' />";
		} else { 
			$canonicalLinkTag = "";
		}
		
		return $canonicalLinkTag;
    }
    
}
