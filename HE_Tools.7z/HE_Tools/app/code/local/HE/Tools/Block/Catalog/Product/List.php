<?php

class HE_Tools_Block_Catalog_Product_List extends Mage_Catalog_Block_Product_List 

{
 
    // Get MediaGallery Collection Object
    public function getProductModalGallery($id) {
    	$html = "";
        $_gallery = Mage::getModel('catalog/product')->load($id)->getMediaGalleryImages();
        if (!empty($_gallery)) {
        	foreach ($_gallery as $mediaObject) {
                foreach ($mediaObject as $data) {
                    if (is_array($data)) {
                        foreach($data as $item => $val) {
                            if ($item == "url") {
                                $html .= "<li class='modal-galItem' data-src='".$val."'><img src='".$val."' width='50' height='50' /></li>";
                            }
                        }
                    }
                }
            }
        }
        return $html;
    }
    
    // Check for gallery length
    // Returns true or false
    public function hasGallery($id) {
        $_hasGallery = Mage::getModel('catalog/product')->load($id)->getMediaGalleryImages();
        if (count($_hasGallery) > 1){
            return true;
        }
    }
}

?>
