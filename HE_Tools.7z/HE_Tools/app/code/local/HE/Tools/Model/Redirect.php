<?php

class HE_Tools_Model_Redirect
{
    public function redirect($observer)
    {
        $request    = $observer['controller_action']->getRequest();
        $response    = $observer['controller_action']->getResponse();

        $actionName = $request->getActionName();
        $requestUrl = $request->getHttpHost() . $request->getRequestUri();

        if ($actionName == 'noRoute') {

            $parsedUrl = parse_url($requestUrl);
            $savedParams = $parsedUrl['query'];
            //http://www.stauer.com/item/item_name/item_number[/category_id]

//PRODUCTS
            $itemPos = stripos($requestUrl, "/item/");
            if ($itemPos) {
                $start = stripos( $requestUrl, "/",$itemPos+6 ); //move pointer forward to skip item name
                $end = stripos($requestUrl, "/", $start+1 );
                if (!$end) $end = stripos($requestUrl, "?", $start+1 );
                if (!$end) $end=strlen($requestUrl);
                $itemNumber = substr($requestUrl, $start+1, $end-$start-1);
            } else {

                //http://www.stauer.com/itemd.asp?itemNo=nnnnn
                $itemNoPos = stripos($requestUrl, "itemNo");
                if ($itemNoPos) {
                    $start = stripos( $requestUrl, "=",$itemNoPos );
                    if (!$start) $start=$itemNoPos+7;
                    $end = stripos( $requestUrl, "&", $itemNoPos );
                    if (!$end) $end=strlen($requestUrl);
                    $itemNumber = substr($requestUrl, $start+1, $end-$start-1);

                    //remove itemNo from the params list
                    $savedParams=str_ireplace("itemno=".$itemNumber,"",$savedParams);
                    $savedParams=str_ireplace("&&","&",$savedParams);
                }
            }

            if (isset($itemNumber)) {
                $itemNumber = $this->_cleanSpace($itemNumber);
                $product = Mage::getModel('catalog/product')->loadByAttribute('sku', $itemNumber);
                if ($product) {
                    $url = $product->getProductUrl();
                    if (strlen($savedParams)) $url=$url."?".$savedParams;
                    //echo "<pre>!!!".var_dump($url);die;
                    $response->setRedirect($url,301)->sendHeaders();
                    $response->sendResponse();
                    exit;
                }
            }

//CATEGORIES
            //http://www.stauer.com/cat/categoryname/nn
            //http://www.stauer.com/cat/categoryname
            $catPos = stripos($requestUrl, "/cat/");
            if ($catPos) {
                $endPath = stripos( $requestUrl, "?");  //see if it ends in a ?
                if ($endPath) $requestUrl=substr($requestUrl, 0, $endPath);  //clip off any remaining params

                $start = stripos( $requestUrl, "/",$catPos+1 );  //first form, look for cat name
                $end = stripos( $requestUrl, "/", $start+1 );    //look for another slash
                if ($end) {
                    $start=$end;
                } //second form
                $end = stripos( $requestUrl, "/", $start+1 );    //look for another slash
                if (!$end) $end=strlen($requestUrl);
                $catId = substr($requestUrl, $start+1, $end-$start-1);
            } else {
                //http://www.stauer.com/category.asp?catID=nnn
                //TODO see if we need to isolate this to just category.asp, it will catch anything with a catID
                $catIdPos = stripos($requestUrl, "catID");
                if ($catIdPos) {
                    $start = stripos( $requestUrl, "=",$catIdPos );
                    if (!$start) $start=$catIdPos+6;
                    $end = stripos( $requestUrl, "&", $catIdPos );
                    if (!$end) $end=strlen($requestUrl);
                    $catId = substr($requestUrl, $start+1, $end-$start-1);
                    //remove itemNo from the params list
                    $savedParams=str_ireplace("catid=".$catId,"",$savedParams);
                    $savedParams=str_ireplace("&&","&",$savedParams);
                    $savedParams=str_ireplace("cat","null",$savedParams);
                }
            }

            if (isset($catId)) {
                // if a match is found, lookup the $catId in the redirect table
                $url=$this->lookup[$catId];
                if ($url) {
                    $sep="?";
                    if (strpos($url,"?")) $sep="&";
                    if (strlen($savedParams)) $url=$url.$sep.$savedParams;
                    $response->setRedirect($url,301)->sendHeaders();
                    $response->sendResponse();
                    exit;
                }
            }
//SEARCHES
            //http://www.stauer.com/search/categoryname/nn
            //http://www.stauer.com/search/categoryname/keyword/nn?PageNo=pp
            $catPos = stripos($requestUrl, "/search/");
            if ($catPos) {
                $endPath = stripos( $requestUrl, "?");  //see if it ends in a ?
                if ($endPath) $requestUrl=substr($requestUrl, 0, $endPath);  //clip off any remaining params

                $start = stripos( $requestUrl, "/",$catPos+1 );  //first form, look for cat name
                $end = stripos( $requestUrl, "/", $start+1 );    //look for another slash
                $catSId = substr($requestUrl, $start+1, $end-$start-1);
            } else {
                //http://www.stauer.com/search.asp?catID=nnn&cat=categoryname[&PageNo=pp]
                $catIdPos = stripos($requestUrl, "catID");
                if ($catIdPos) {
                    $start = stripos( $requestUrl, "=",$catIdPos );
                    if (!$start) $start=$catIdPos+6;
                    $end = stripos( $requestUrl, "&", $catIdPos );
                    if (!$end) $end=strlen($requestUrl);
                    $catSId = substr($requestUrl, $start+1, $end-$start-1);
                    //remove itemNo from the params list
                    $savedParams=str_ireplace("catid=".$catSId,"",$savedParams);
                    $savedParams=str_ireplace("&&","&",$savedParams);
                    $savedParams=str_ireplace("cat","null",$savedParams);
                }
            }

            if (isset($catSId)) {
                // if a match is found, lookup the $catId in the redirect table
                $url=$this->lookup[$catSId];
                if ($url) {
                    $sep="?";
                    if (strpos($url,"?")) $sep="&";
                    if (strlen($savedParams)) $url=$url.$sep.$savedParams;
                    $response->setRedirect($url,301)->sendHeaders();
                    $response->sendResponse();
                    exit;
                }
            }
        }
    }

    private $lookup=
        array(
            '1'     =>'/',
            '2'	    =>'/watches.html',
            '3'	    =>'/watches/mens-watches.html',
            '5'	    =>'/watches.html?ams_watchmovement=244',
            '6'	    =>'/watches.html?ams_watchmovement=245',
            '7'	    =>'/watches.html?ams_watchmovement=246',
            '102'	=>'/watches.html?ams_watchmovement=247',
            '139'	=>'/watches/pocket-watches.html',
            '8'	    =>'/watches/womens-watches.html',
            '12'	=>'/watches/winders-and-cases.html',
            '108'	=>'/watches/watch-bands.html',
            '13'	=>'/jewelry.html',
            '29'	=>'/jewelry/womens-jewelry.html?ams_stone=272',
            '15'	=>'/jewelry/womens-jewelry.html?ams_stone=271',
            '21'	=>'/jewelry/womens-jewelry.html?ams_stone=295',
            '134'	=>'/jewelry/womens-jewelry.html?ams_stone=310',
            '136'	=>'/jewelry/womens-jewelry.html?ams_stone=301',
            '137'	=>'/jewelry/womens-jewelry.html?ams_stone=300',
            '138'	=>'/jewelry/womens-jewelry.html?ams_stone=273',
            '17'	=>'/jewelry/womens-jewelry/rings.html',
            '18'	=>'/jewelry/womens-jewelry/earrings.html',
            '19'	=>'/jewelry/womens-jewelry/necklaces.html',
            '20'	=>'/jewelry/womens-jewelry/bracelets.html',
            '24'	=>'/jewelry/womens-jewelry.html?ams_stone=271',
            '120'	=>'/jewelry/womens-jewelry.html?ams_stone=300',
            '31'	=>'/jewelry/womens-jewelry.html?ams_stone=273',
            '33'	=>'/jewelry/womens-jewelry.html?ams_stone=314',
            '34'	=>'/jewelry/womens-jewelry.html?ams_stone=255',
            '35'	=>'/jewelry/womens-jewelry.html?ams_stone=310',
            '36'	=>'/jewelry/womens-jewelry.html?ams_stone=268',
            '37'	=>'/jewelry/womens-jewelry.html?ams_stone=305',
            '38'	=>'/jewelry/womens-jewelry.html?ams_stone=274',
            '124'	=>'/jewelry/womens-jewelry.html?ams_stone=319',
            '125'	=>'/jewelry/womens-jewelry.html?ams_stone=296',
            '107'	=>'/jewelry/womens-jewelry/cameos-and-brooches.html',
            '39'	=>'/jewelry/cases-and-care.html',
            '119'	=>'/jewelry/mens-jewelry.html',
            '40'	=>'/eyewear.html',
            '42'	=>'/eyewear/eyewear-outdoors.html',
            '43'	=>'/eyewear/sunglasses.html',
            '45'	=>'/eyewear/fit-ons-and-clip-ons.html',
            '46'	=>'/home-accessories.html',
            '105'	=>'/home-accessories/diamond-cookware.html',
            '53'	=>'/coins-and-collectibles.html',
            '54'	=>'/coins-and-collectibles/historical-treasures.html',
            '55'	=>'/coins-and-collectibles/coins.html',
            '126'	=>'/coins-and-collectibles/coin-watches-and-jewelry.html',
            '153'	=>'/coins-and-collectibles/pocket-knives.html',
            '127'	=>'/gift-ideas/patriotic-gifts.html',
            '118'	=>'/home-accessories/home-accessories-decor.html',
            '103'	=>'/gift-ideas/handbags-and-leather-goods.html',
            '67'	=>'/gift-ideas/handbags-and-leather-goods.html?cat=58',
            '104'	=>'/gift-ideas/handbags-and-leather-goods.html?cat=60',
            '115'	=>'/new-arrivals.html',
            '73'	=>'/best-sellers.html',
            '75'	=>'/gift-ideas.html',
            '76'	=>'/gift-ideas/gifts-for-her.html',
            '77'	=>'/gift-ideas/gifts-for-him.html',
            '116'	=>'/gift-ideas/personalized-items.html',

            'Watches'=>'/watches.html',
            'Mens-Watches'=>'/watches/mens-watches.html',
            'Automatic'=>'/watches.html?ams_watchmovement=244',
            'Multifunction---Chronograph'=>'/watches.html?ams_watchmovement=245',
            'Quartz'=>'/watches.html?ams_watchmovement=246',
            'Classic-Manual-Wind'=>'/watches.html?ams_watchmovement=247',
            'Pocket-Watches'=>'/watches/pocket-watches.html',
            'Womens-Watches'=>'/watches/womens-watches.html',
            'Winders-%26amp%3B-Cases'=>'/watches/winders-and-cases.html',
            'Watch-Bands'=>'/watches/watch-bands.html',
            'Jewelry'=>'/jewelry.html',
            'Diamonds'=>'/jewelry/womens-jewelry.html?ams_stone=272',
            'DiamondAura-Collection'=>'/jewelry/womens-jewelry.html?ams_stone=271',
            'Pearls'=>'/jewelry/womens-jewelry.html?ams_stone=295',
            'Tanzanite'=>'/jewelry/womens-jewelry.html?ams_stone=310',
            'Sapphires'=>'/jewelry/womens-jewelry.html?ams_stone=301',
            'Ruby'=>'/jewelry/womens-jewelry.html?ams_stone=300',
            'Emeralds'=>'/jewelry/womens-jewelry.html?ams_stone=273',
            'Rings'=>'/jewelry/womens-jewelry/rings.html',
            'Earrings'=>'/jewelry/womens-jewelry/earrings.html',
            'Necklaces'=>'/jewelry/womens-jewelry/necklaces.html',
            'Bracelets'=>'/jewelry/womens-jewelry/bracelets.html',
            'DiamondAura'=>'/jewelry/womens-jewelry.html?ams_stone=271',
            'Ruby'=>'/jewelry/womens-jewelry.html?ams_stone=300',
            'Emeralds'=>'/jewelry/womens-jewelry.html?ams_stone=273',
            'Topaz'=>'/jewelry/womens-jewelry.html?ams_stone=314',
            'Amethyst'=>'/jewelry/womens-jewelry.html?ams_stone=255',
            'Tanzanite'=>'/jewelry/womens-jewelry.html?ams_stone=310',
            'Citrine'=>'/jewelry/womens-jewelry.html?ams_stone=268',
            'Spinel'=>'/jewelry/womens-jewelry.html?ams_stone=305',
            'Garnet'=>'/jewelry/womens-jewelry.html?ams_stone=274',
            'Turquoise'=>'/jewelry/womens-jewelry.html?ams_stone=319',
            'Peridot'=>'/jewelry/womens-jewelry.html?ams_stone=296',
            'Cameos-%26amp%3B-Brooches'=>'/jewelry/womens-jewelry/cameos-and-brooches.html',
            'Cases-and-Care'=>'/jewelry/cases-and-care.html',
            'Mens-Jewelry'=>'/jewelry/mens-jewelry.html',
            'Eyewear'=>'/eyewear.html',
            'Sports'=>'/eyewear/eyewear-outdoors.html',
            'Driving'=>'/eyewear/sunglasses.html',
            'Fit-ons-%26amp%3B-Clip-Ons'=>'/eyewear/fit-ons-and-clip-ons.html',
            'Home-Accessories'=>'/home-accessories.html',
            'Diamond-Cookware'=>'/home-accessories/diamond-cookware.html',
            'Coins-%26amp%3B-Collectibles'=>'/coins-and-collectibles.html',
            'Historical-Treasures'=>'/coins-and-collectibles/historical-treasures.html',
            'Coins-%26amp%3B-Currency'=>'/coins-and-collectibles/coins.html',
            'Coin-Watches-%26amp%3B-Jewelry'=>'/coins-and-collectibles/coin-watches-and-jewelry.html',
            'Pocket-Knives'=>'/coins-and-collectibles/pocket-knives.html',
            'Patriotic-Gifts'=>'/gift-ideas/patriotic-gifts.html',
            'Fine-Art-Paintings'=>'/home-accessories/home-accessories-decor.html',
            'Handbags-%26amp%3B-Leather-Goods'=>'/gift-ideas/handbags-and-leather-goods.html',
            'Handbags'=>'/gift-ideas/handbags-and-leather-goods.html?cat=58',
            'Leather-Goods'=>'/gift-ideas/handbags-and-leather-goods.html?cat=60',
            'New-Arrivals'=>'/new-arrivals.html',
            'Best-Sellers'=>'/best-sellers.html',
            'Gift-Ideas'=>'/gift-ideas.html',
            'Gifts-for-Her'=>'/gift-ideas/gifts-for-her.html',
            'Gifts-for-Him'=>'/gift-ideas/gifts-for-him.html',
            'Personalization'=>'/gift-ideas/personalized-items.html',

            //TODO - are the keywords needed?
            '01WTNN'=>'/watches.html',
            '01WTMW'=>'/watches/mens-watches.html',
            '01WTMWAM'=>'/watches.html?ams_watchmovement=244',
            '01WTMWWT'=>'/watches.html?ams_watchmovement=245',
            '01WTMWQT'=>'/watches.html?ams_watchmovement=246',
            '01WTMWCM'=>'/watches.html?ams_watchmovement=247',
            '01WTP'=>'/watches/pocket-watches.html',
            '01WTWW'=>'/watches/womens-watches.html',
            '01WTWC'=>'/watches/winders-and-cases.html',
            '01WTWB'=>'/watches/watch-bands.html',
            '02JYNN'=>'/jewelry.html',
            '02JYSTPGDD'=>'/jewelry/womens-jewelry.html?ams_stone=272',
            '02JYDC'=>'/jewelry/womens-jewelry.html?ams_stone=271',
            '02JYPL'=>'/jewelry/womens-jewelry.html?ams_stone=295',
            '02JYSTSPTZ'=>'/jewelry/womens-jewelry.html?ams_stone=310',
            '02JYSTPGSP'=>'/jewelry/womens-jewelry.html?ams_stone=301',
            '02JYSTPGRY'=>'/jewelry/womens-jewelry.html?ams_stone=300',
            '02JYSTPGEM'=>'/jewelry/womens-jewelry.html?ams_stone=273',
            '02JYRG'=>'/jewelry/womens-jewelry/rings.html',
            '02JYEG'=>'/jewelry/womens-jewelry/earrings.html',
            '02JYNK'=>'/jewelry/womens-jewelry/necklaces.html',
            '02JYBC'=>'/jewelry/womens-jewelry/bracelets.html',
            '02JYSTLCDA'=>'/jewelry/womens-jewelry.html?ams_stone=271',
            '02JYSTPGRY'=>'/jewelry/womens-jewelry.html?ams_stone=300',
            '02JYSTPGEM'=>'/jewelry/womens-jewelry.html?ams_stone=273',
            '02JYSTSPTP'=>'/jewelry/womens-jewelry.html?ams_stone=314',
            '02JYSTSPAM'=>'/jewelry/womens-jewelry.html?ams_stone=255',
            '02JYSTSPTZ'=>'/jewelry/womens-jewelry.html?ams_stone=310',
            '02JYSTSPCT'=>'/jewelry/womens-jewelry.html?ams_stone=268',
            '02JYSTSPSN'=>'/jewelry/womens-jewelry.html?ams_stone=305',
            '02JYSTSPGN'=>'/jewelry/womens-jewelry.html?ams_stone=274',
            '02JYSTSPTQ'=>'/jewelry/womens-jewelry.html?ams_stone=319',
            '02JYSTSPPD'=>'/jewelry/womens-jewelry.html?ams_stone=296',
            '02JYBR'=>'/jewelry/womens-jewelry/cameos-and-brooches.html',
            '02JYCC'=>'/jewelry/cases-and-care.html',
            '02JYMJ'=>'/jewelry/mens-jewelry.html',
            '03EW'=>'/eyewear.html',
            '03EWSP'=>'/eyewear/eyewear-outdoors.html',
            '03EWDV'=>'/eyewear/sunglasses.html',
            '03EWFO'=>'/eyewear/fit-ons-and-clip-ons.html',
            '04HM'=>'/home-accessories.html',
            '04HMKI'=>'/home-accessories/diamond-cookware.html',
            '05CC'=>'/coins-and-collectibles.html',
            '05CCHT'=>'/coins-and-collectibles/historical-treasures.html',
            '05CCCN'=>'/coins-and-collectibles/coins.html',
            '05CCWJ'=>'/coins-and-collectibles/coin-watches-and-jewelry.html',
            '05PN'=>'/coins-and-collectibles/pocket-knives.html',
            'MILITARY'=>'/gift-ideas/patriotic-gifts.html',
            '14FA'=>'/home-accessories/home-accessories-decor.html',
            '12LL'=>'/gift-ideas/handbags-and-leather-goods.html',
            '06ALHB'=>'/gift-ideas/handbags-and-leather-goods.html?cat=58',
            '12LLLG'=>'/gift-ideas/handbags-and-leather-goods.html?cat=60',
            '07NA'=>'/new-arrivals.html',
            'STAUERBEST'=>'/best-sellers.html',
            '09GI'=>'/gift-ideas.html',
            '09GIHR'=>'/gift-ideas/gifts-for-her.html',
            '09GIHM'=>'/gift-ideas/gifts-for-him.html',
            '14SPI'=>'/gift-ideas/personalized-items.html',
        );

    //strip out any characters after a space in the item number
    protected function _cleanSpace($itemNumber) {
        $temp = explode(" ",urldecode($itemNumber));
        return $temp[0];
    }
}
