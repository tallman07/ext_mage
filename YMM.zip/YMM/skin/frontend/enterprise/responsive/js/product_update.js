var $_ = jQuery.noConflict();

//Removes the duplicate dropdown value
$_(document).ready(function() {
	var array = new Array(); 
	$_("div.custom-attributes").find("select").each(function() {
	    selectBoxId = $_(this).attr("id");
		removeDuplicateOptionFromSelectBox(selectBoxId);
	});

	if ($_('.catalog-product-view .optionsel-wrap').length > 0)  {
		optionsel.change() 
	} 

	if ($_('.catalog-product-view .optionsel2-wrap').length > 0) {
		optionsel2.change() 
	} 

}); 


function getProductDetailsBySku(sku, multiconfig, callback) {
    $_.ajax({
		type: "POST",
		url: "/ymm/index/getProductDetailsBySku",
		async: true,
		data: 'sku=' + sku + '&multiconfig=' + multiconfig,
		success: function(data) {
			var result = $_.parseJSON(data);
			callback(result);
		 },
		error: function() {
			alert('Error occured');
		}
	});
}

// Removes the Duplicate Option From The SelectBox
function removeDuplicateOptionFromSelectBox(selectBoxId) {
	var array = new Array(); 
	$_("#"+selectBoxId).children("option").each(function(x) { 
		found = false; 
		optText = array[x] = $_(this).text(); 

		for (i = 0; i< array.length-1; i++) { 
				if (optText == array[i] && optText != 'Choose an Option...') found = true; 
		} 

		if (found) 	$_(this).remove(); 
	});
}

// Escape the HTML special chars from the string
function htmlDecode(value) {
	if (value) {
		return $_('<div />').html(value).text();
	} else {
		return '';
	}
}

function callCarousel() {
	$_(document).ready(function() {
		var carousel = $_('#product-image-carousel').elastislide({
			start:0, 
			minItems:1,
			onReady:function(){
				//init imagezoom plugin
				$_('#product-image').ImageZoom();
				$_('#product-image-carousel li:eq(0)').addClass('active');
			}
		});

		$_('#product-image-carousel li').each(function(i) {
			$_(this).click(function(evt) {
				var el = $_(this);
				var pos = i;

				evt.preventDefault();
				el.siblings().removeClass("active");
				el.addClass("active");
				carousel.setCurrent( pos );

				// for imagezoom to change image 
				var demo2obj = $_('#product-image').data('imagezoom');
				demo2obj.changeImage(el.find('img').data('mainimg'),el.find('img').data('largeimg'));

				evt.preventDefault();
			});
		});
	});
}

// Order help dialog
function showOrderHelpDialog() {
	new Dialog.Box('dialogbox-ymm');
	$('dialogbox-ymm').show();

	$('dialogbox-close-button').observe('click', function() {
		$('dialogbox-ymm').hide();
	});
}

//Used on the 1st generation ymm configurable product page to update the sku
var optionsel = {
	change: function(){
		$_('.super-attribute-select').change(function(){
			// Then look through the options for the pseduo class :selected
			$_(this).find("option:selected" ).each(function() {

				var selectedMPN = $_(this).attr('data-mpn');
				var price = parseFloat($_(this).attr('price'));
				var finalprice = parseFloat($_(this).attr('finalprice'));
				var eid = parseInt($_(this).attr('data-eid'));
				var optionText = $_(this).text();
				var optionLabel = $_('.product-options dt label').text();

				if(selectedMPN != ''){
					$_('.product-ids').html('Part# '+selectedMPN);
				}

				if(price != ''){

					if (price == finalprice) {

						$_('span.price')
							.html('<span class="normalprice show-as-regular">'+'$'+finalprice.toFixed(2)+'</span>');

						$_('.old-price .price .finalprice').show();
						$_('.special-price .price .normalprice').show();
						$_('.old-price').hide();
						$_('.special-price .price-label').hide();

					} else {

						$_('span.price')
							.html('<span class="normalprice">'+'$'+price.toFixed(2)+'</span>')
							.append('<span class="finalprice">'+'$'+finalprice.toFixed(2)+'</span>');

						// varien product.js automatically swaps prices around in its own way
						// this code will use varien's functionality but we are going to toggle 
						// our new normalprice and finalprice divs on and off accordingly here 
						$_('.old-price .price .finalprice').hide();
						$_('.special-price .price .normalprice').hide();
						$_('.old-price').show();
						$_('.special-price .price-label').show();

					}

				}


				if(eid != ''){
					$_('#simpleprodid').attr('value',eid);
				}

				$_('#simpleprodoption').attr('value',optionText);
				$_('#simpleprodoptionlabel').attr('value',optionLabel);				

			});	
		});
	}
}


//Used on the regular magento configurable product page to update the sku and prices
var optionsel2 = {
	change: function(){
		$_("select[name*='super_attribute']").change(function(){
			// Then look through the options for the pseduo class :selected
			$_(this).find("option:selected" ).each(function() {

				var selectedMPN = $_(this).attr('data-mpn');
				var price = parseFloat($_(this).attr('data-price'));

				var productID = $_(this).attr('data-pid');
				var finalprice = parseFloat($_(this).attr('data-finalprice'));

				//var eid = parseInt($_(this).attr('data-eid'));
				//var optionText = $_(this).text();
				//var optionLabel = $_('.product-options dt label').text();

				if(selectedMPN != ''){
					$_('.product-ids').html('Part# '+selectedMPN);
				}

if(price != ''){

					if (price == finalprice) {

						$_('span.price')
							.html('<span class="normalprice show-as-regular">'+'$'+finalprice.toFixed(2)+'</span>');

						$_('.old-price .price .finalprice').show();
						$_('.special-price .price .normalprice').show();
						$_('.old-price').hide();
						$_('.special-price .price-label').hide();

					} else {

						$_('span.price')
							.html('<span class="normalprice">'+'$'+price.toFixed(2)+'</span>')
							.append('<span class="finalprice">'+'$'+finalprice.toFixed(2)+'</span>');

						// varien product.js automatically swaps prices around in its own way
						// this code will use varien's functionality but we are going to toggle 
						// our new normalprice and finalprice divs on and off accordingly here 
						$_('.old-price .price .finalprice').hide();
						$_('.special-price .price .normalprice').hide();
						$_('.old-price').show();
						$_('.special-price .price-label').show();

					}

				}

				$_('div.price-box span#product-price-'+productID+' span.price-label').remove();

			});	
		});
	}
}