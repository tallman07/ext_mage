var $_ = jQuery.noConflict();

// Caching block for YMM in the topmenu causes issues with FPC
// We have moved the YMM block into the header, once it loads out of cache,
// We need to move it back into its home in the top menu
$_(window).load(function(){

	if($_('.unselected').length > 0){
		// For unselected vehicles: Detach to retain the bound click events
		var ymm_html = $_('.unselected').detach();
		ymm_html.appendTo('#ymm-target-div');
		$_('.unselected').show();
	} else {
		// For selected vehicle:
		var ymm_html = $_('.top-level-ymm').detach();
		ymm_html.appendTo('#ymm-target-div');
		$_('.top-level-ymm').show();
	}
	
});


var public_function = {
		check_length: function()
		{
			if($_('#change-model-selection').length > 0){
				return true;
			}
			return false;
		},
		checkFlagUrl: function()
		{
            $_.ajax({
                    type: "POST",
                    url: "/ymm/index/ymmCheckModel",
                    data: '',
                    success: function(data) {
                        if(data == 'yes'){
                            var year = getCookie("ymm_year");
                            var make = getCookie("ymm_make");
                            var model = getCookie("ymm_model");
                            var flagUrl = "";
                            var link = "";
                            if (year !== null && make !== null && model !== null) {
                                flagUrl = year + make + model;
                            }
                            if (flagUrl.length > 0) {
                                $_('a').click(function(e) {
                                    e.preventDefault();
                                    link = $_(this).attr('href');
                                    var URL = window.location.protocol + "//" + window.location.host + "/";
                                    if (link != URL) {
                                        if (link.length > 0 && link != "#" && link != "javascript:void(0)" && link != "javascript:void(0);") {
                                            if (link.indexOf('?') > -1) {
                                                link = link + "&tokenurl=" + flagUrl;
                                            } else {
                                                link = link + "?tokenurl=" + flagUrl;
                                            }
                                        }
                                    }
                                    window.location.href = link;
                                });
                            }
                        } 
                    }
                });
		},
		update_phone:function()
		{
			//make sure there is no additional WYSIWYG Html added to the phone number
            var phoneNumberSpan = document.getElementById('phone_number_in_header');
            var phoneNumberValue = phoneNumberSpan.innerText;

            //START SECTION TO WRAP THE AREA CODE IN A <span>

            //figure out what character ends the area code
            var endAreaCode = '';
			if(typeof phoneNumberValue !== 'undefined'){
				if (phoneNumberValue.indexOf('.') != 0) //if dot
				{
					endAreaCode = '.';
				}
				else
				{
					if (phoneNumberValue.indexOf('-') != 0) //if dash
					{
						endAreaCode = '-';
					}
					else
					{
						if (phoneNumberValue.indexOf(' ') != 0) //if space
						{
							endAreaCode = ' ';
						}
					}
				}

				//if the character that ends the area code was found
				if (endAreaCode != '')
				{
					//separate the full number from the area code to add a span around the area code
					var areaCode = phoneNumberValue.substring(0, phoneNumberValue.indexOf(endAreaCode) + endAreaCode.length);
					phoneNumberValue = phoneNumberValue.substring(areaCode.length);

					phoneNumberValue = '<span class="area-code">' + areaCode + '</span>' + phoneNumberValue;
				}

				//END SECTION TO WRAP THE AREA CODE IN A <span>

				phoneNumberSpan.innerHTML = phoneNumberValue;
			}
		}

	
}
