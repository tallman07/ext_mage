<?php

/**
 * Human - Element
 *
 *
 * DISCLAIMER
 * @category    HumanElement Ymm 
 * @package     Humanelement_Ymm
 * @copyright   Copyright (c) Human Element(www.human-element.com)

 */
class Humanelement_Ymm_IndexController extends Mage_Core_Controller_Front_Action {

    /**
     *  Get drop down value base on Ajax request
     * 
     *  $return json string
     */
    public function indexAction() {
        $year = Mage::app()->getRequest()->getParam('year');
        $make = Mage::app()->getRequest()->getParam('make');
        $ymm = $this->getYmmObject();
        $result = isset($make) ? $ymm->getVehicleModel($year, $make) : $ymm->getVehicleMaker($year);   
        echo json_encode($result);

        return;
    }
	
    /**
     *  Get the product details on dropdown changes
     * 
     *  $return json string
     */
	public function getProductDetailsBySkuAction() {
        $sku = Mage::app()->getRequest()->getParam('sku');
        $multiconfig = Mage::app()->getRequest()->getParam('multiconfig');
        $id = Mage::getModel('catalog/product')->getIdBySku($sku);
        $productData = array();
		
		if ($id != '') {
			$_product = Mage::getModel('catalog/product')->load($id);
			// Get the product images
			if ($_product->getImage() != 'no_selection' && $_product->getImage()) {
				
				$pimage = '';
				$imageLabel = $_product->getImageLabel();
				$label = (empty($imageLabel)) ? $_product->getName() : $imageLabel;
				$label = Mage::helper('core')->htmlEscape($label);
				if (!$multiconfig) {
					$pimage = '<img id="product-image" src="'.Mage::helper('catalog/image')->init($_product, 'image')->resize(450).'" alt="'.$label.'" title="'.$label.'" />';
				} else {
					$pimage = '<a class="product-image" title="'.$label.'" href="'.$_product->getProductUrl().'"><img id="product-image" src="'.Mage::helper('catalog/image')->init($_product, 'image')->resize(450).'" alt="'.$label.'" title="'.$label.'" /></a>';
				}
			}
					
			$productData = $_product->getData();
							
			$formattedRegularPrice = Mage::helper('core')->currency($_product->getPrice(), true, false);
			$formattedFinalPrice = Mage::helper('core')->currency($_product->getFinalPrice(), true, false);
				
			if ($formattedRegularPrice != $formattedFinalPrice) {
				// if these values are not equal, there is probably a special price or catalog rule in effect
				// the jQuery code in ymm/product/view/type/configurable.phtml will need this for the price to display correctly 
				// when the dropdowns are changed
				$formattedPrice = Mage::helper('core')->currency($_product->getFinalPrice(), true, false);
			} else {
				// otherwise everything is normal and this is the regular condition
				$formattedPrice = Mage::helper('core')->currency($_product->getPrice(), true, false);
			}
			
			$productData['price'] = Mage::helper('core')->currency($productData['price'], true, false);
            $productData['final_price'] = $formattedPrice;
			$productData['image_availability'] = $_product->getImage();
			$productData['found'] = true;
			//Fetch the zoomdata
			if (count($_product->getMediaGalleryImages()) > 0) { 
				$zoomData = '<ul id="product-image-carousel" class="elastislide-list">';
				
				$li = 1;
				foreach ($_product->getMediaGalleryImages() as $_image) {
					if ($li == 1) {
						$zoomData .= "<li class='active' style='width: 100%; max-width: 100px; max-height: 100px;'>
									<a href='javascript:void(0)' title='".$_product->getName()."'>
										<img src='".Mage::helper('catalog/image')->init($_product, 'thumbnail', $_image->getFile())->resize(100,100)."' data-mainimg='".Mage::helper('catalog/image')->init($_product, 'image', $_image->getFile())->resize(450,450)."' data-largeimg='".Mage::helper('catalog/image')->init($_product, 'image', $_image->getFile())->resize(700,700)."'  title='".Mage::helper('core')->htmlEscape($_image->getLabel())."' />
									</a>
								</li>";
					} else {
						$zoomData .= "<li>
									<a href='javascript:void(0)' title='".$_product->getName()."'>
										<img src='".Mage::helper('catalog/image')->init($_product, 'thumbnail', $_image->getFile())->resize(100,100)."' data-mainimg='".Mage::helper('catalog/image')->init($_product, 'image', $_image->getFile())->resize(450,450)."' data-largeimg='".Mage::helper('catalog/image')->init($_product, 'image', $_image->getFile())->resize(700,700)."'  title='".Mage::helper('core')->htmlEscape($_image->getLabel())."' />
									</a>
								</li>";
					}
					$li++;
				}
				$zoomData .= '</ul>';
				$productData['zoom_data'] = $zoomData;
			}
		} else {
			$productData['found'] = false;
		}
		if (!empty($pimage)) {
			$productData['image'] = $pimage;
		}
		
		echo json_encode($productData);
		
		return;
    }

    /**
     *  Get drop down value for configurable product, base on Ajax request
     * 
     *  $return json string
     */
    public function ymmForConfigurableAction() {
        $ymm = $this->getYmmObject();
        $year = Mage::app()->getRequest()->getParam('year');
        $make = Mage::app()->getRequest()->getParam('make');
        $bossItemIdDetails = $ymm->getBossCollection(Mage::app()->getRequest()->getParam('productId'));

        $result = isset($make) ? $ymm->getModelForConfigurableProduct($bossItemIdDetails, $year, $make) : $ymm->getMakeForConfigurableProduct($bossItemIdDetails, $year);
        echo json_encode($result);

        return;
    }
    /**
     *  Get drop down value for simple product, base on Ajax request
     * 
     *  $return json string
     */
    public function ymmForSimpleProductAction() {
        $ymm = $this->getYmmObject();
        $year = Mage::app()->getRequest()->getParam('year');
        $make = Mage::app()->getRequest()->getParam('make');
        $man_label_id = Mage::app()->getRequest()->getParam('man_label_id');
        $result = isset($make) ? $ymm->getModelForSimpleProductPage($man_label_id, $year, $make) : $ymm->getMakeForSimpleProductPage($man_label_id, $year);
        echo json_encode($result);

        return;
    }
    /**
     * Check YMM model session
     * 
     * Can be used to handle ajax requests to just set the ymm if the redirect doesnt get caught
     */
    public function ymmSetFromSearchAction() {
        
        $year = Mage::app()->getRequest()->getParam('year');
        $make = Mage::app()->getRequest()->getParam('make');
        $model = Mage::app()->getRequest()->getParam('model');
        
        $session = Mage::getSingleton('core/session');
        $session->setData('vehicle_year', $year);
        $session->setData('vehicle_model', $model);
        $session->setData('vehicle_make', $make);
        
        if ($session->getData('vehicle_year') && $session->getData('vehicle_model') && $session->getData('vehicle_make')) {
            echo json_encode(array('year' => $session->getData('vehicle_year'), 'make' => $session->getData('vehicle_make'), 'model' => $session->getData('vehicle_model') ));
        } else {
            echo "no";
        }
        
    }
    

    /**
     * Perform Filteration base on drop down selection
     * 
     * @return string
     */
    public function resultAction() {
        $year = Mage::app()->getRequest()->getParam('year');
        $make = Mage::app()->getRequest()->getParam('make');
        $model = Mage::app()->getRequest()->getParam('model');
        $show = Mage::app()->getRequest()->getParam('show_all');
        if (!isset($year) && !isset($make) && !isset($model)) {
            return;
        }
        $session = Mage::getSingleton('core/session');
        $session->setData('vehicle_year', $year);
        $session->setData('vehicle_model', $model);
        $session->setData('vehicle_make', $make);

        if (isset($show)) {
            $session->setData('show_all', TRUE);
        }

        $this->getYmmObject()->getManLabelId();

        $this->loadLayout();
        $this->_initLayoutMessages('catalog/session');
        $this->_initLayoutMessages('checkout/session');
        $this->renderLayout();
    }

    /**
     * Perform Filteration base on drop down selection
     * 
     * @return string
     */
    public function resultsAction() {

        $show = Mage::app()->getRequest()->getParam('show_all');
        $layer = Mage::getSingleton('ymm/layer');
        $session = Mage::getSingleton('core/session');
        if ($session->getData('vehicle_year') && $session->getData('vehicle_model') && $session->getData('vehicle_make')) {

            if ($catId = Mage::app()->getRequest()->getParam('cat')) {
                $_category = Mage::getModel('catalog/category')->load($catId);
                $this->_redirectUrl($_category->getUrl() . '?show_all=' . $show);
            }

            if (Mage::app()->getRequest()->getParam('brand')) {
                if (strpos($_SERVER ['HTTP_REFERER'], '?')) {
                    $url = substr($_SERVER ['HTTP_REFERER'], 0, strpos($_SERVER ['HTTP_REFERER'], '?')) . '?show_all=' . $show;
                } else {
                    $url = $_SERVER ['HTTP_REFERER'] . '?show_all=' . $show;
                }
                $this->_redirectUrl($url);
            }

            $this->getYmmObject()->getManLabelId();

            $this->loadLayout();
            $this->_initLayoutMessages('catalog/session');
            $this->_initLayoutMessages('checkout/session');
            $this->renderLayout();
        }

        return;
    }

    /**
     * Get YMM model object
     * 
     * @return object
     */
    private function getYmmObject() {
        return Mage::getModel('ymm/ymm');
    }
    /**
     * Check YMM model session
     */
    public function ymmCheckModelAction() {
        $session = Mage::getSingleton('core/session');
        if ($session->getData('vehicle_year') && $session->getData('vehicle_model') && $session->getData('vehicle_make')) {
            echo "yes";
        } else {
            echo "no";
        }
    }
}
