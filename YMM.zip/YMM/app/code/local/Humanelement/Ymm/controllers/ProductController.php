<?php
/**
 * Product controller
 *
 * @category   Mage
 * @package    Mage_Catalog
 */
require_once(Mage::getModuleDir('controllers','Mage_Catalog').DS."ProductController.php");
class Humanelement_Ymm_ProductController extends Mage_Catalog_ProductController
{
    /**
     * Product view action
     */
    public function viewAction()
    {
        $year = Mage::app()->getRequest()->getParam('year');
        $make = Mage::app()->getRequest()->getParam('make');
        $model = Mage::app()->getRequest()->getParam('model');
        $show = Mage::app()->getRequest()->getParam('show_all');
        if (isset($year) && isset($make) && isset($model)) {
            $session = Mage::getSingleton('core/session');
            $session->setData('vehicle_year', $year);
            $session->setData('vehicle_model', $model);
            $session->setData('vehicle_make', $make);
            if (isset($show)) {
                $session->setData('show_all', TRUE);
            }
        }
        
        // Get initial data from request
        $categoryId = (int) $this->getRequest()->getParam('category', false);
        $productId  = (int) $this->getRequest()->getParam('id');
        $specifyOptions = $this->getRequest()->getParam('options');

        // Prepare helper and params
        $viewHelper = Mage::helper('catalog/product_view');

        $params = new Varien_Object();
        $params->setCategoryId($categoryId);
        $params->setSpecifyOptions($specifyOptions);

        // Render page
        try {
            $viewHelper->prepareAndRender($productId, $this, $params);
        } catch (Exception $e) { 
            if ($e->getCode() == $viewHelper->ERR_NO_PRODUCT_LOADED) {
                if (isset($_GET['store'])  && !$this->getResponse()->isRedirect()) {
                    $this->_redirect('');
                } elseif (!$this->getResponse()->isRedirect()) {
                    $this->_forward('noRoute');
                }
            } else {
                Mage::logException($e);
                $this->_forward('noRoute');
            }
        }
    }
}
