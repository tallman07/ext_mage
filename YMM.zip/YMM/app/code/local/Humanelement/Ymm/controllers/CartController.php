<?php
require_once 'Mage/Checkout/controllers/CartController.php';
class Humanelement_Ymm_CartController extends Mage_Checkout_CartController
{
	/**
     * Initialize product instance from request data
     *
     * @return Mage_Catalog_Model_Product || false
     */
    protected function _initSimpleProduct()
    {
        $productId = (int) $this->getRequest()->getParam('simple_product');
        if ($productId) {
            $product = Mage::getModel('catalog/product')
                ->setStoreId(Mage::app()->getStore()->getId())
                ->load($productId);
            if ($product->getId()) {
                return $product;
            }
        }
        return false;
    }
    
	
	/**
     * Add product to shopping cart action
     *
     * @return Mage_Core_Controller_Varien_Action
     * @throws Exception
     */
    public function addAction()
    {
        if (!$this->_validateFormKey()) {
            $this->_goBack();
            return;
        }
        $cart   = $this->_getCart();
        $params = $this->getRequest()->getParams();
		
        try {
            if (isset($params['qty'])) {
                $filter = new Zend_Filter_LocalizedToNormalized(
                    array('locale' => Mage::app()->getLocale()->getLocaleCode())
                );
                $params['qty'] = $filter->filter($params['qty']);
            }
			
			// Check if we are adding a regular configurable item to the cart
			if (isset($params['simple_product']) && $params['uniquesku'] != '') {
				$product = $this->_initSimpleProduct();
			} else {
				$product = $this->_initProduct();
            }
		
            $related = $this->getRequest()->getParam('related_product');

            /**
             * Check product availability
             */
            if (!$product) {
                $this->_goBack();
                return;
            }
			
			if (isset($params['product_found']) && $params['product_found'] == 'Yes' && $params['uniquesku'] != '') {	
			    $uniqueSku = $params['uniquesku'];			    
				$id = Mage::getModel('catalog/product')->getIdBySku($uniqueSku);
				
				$allIds = array();
				if ($id) {
					// Add this product to the shopping cart
					$allIds[] = $id;
				}
				
                if (!empty($allIds)) { 
                    $cart->addProductsByIds($allIds);
                } else {
					$this->_goBack();
					return;
				}
            } else {
				$cart->addProduct($product, $params);
			}
			
            if (!empty($related)) {
                $cart->addProductsByIds(explode(',', $related));
            }
			
			$cart->save();
            
            $this->_getSession()->setCartWasUpdated(true);

            /**
             * @todo remove wishlist observer processAddToCart
             */
            Mage::dispatchEvent('checkout_cart_add_product_complete',
                array('product' => $product, 'request' => $this->getRequest(), 'response' => $this->getResponse())
            );
            
            if (!$this->_getSession()->getNoCartRedirect(true)) {
                if (!$cart->getQuote()->getHasError()) {
                    $message = $this->__('%s was added to your shopping cart.', Mage::helper('core')->escapeHtml($product->getName()));
                    $this->_getSession()->addSuccess($message);
                    
                    $sessionOptions = Mage::getSingleton('checkout/session')->getCartSessionOptions();
                    
                    $sessionOptions[$product->getId()] =  array(
                    	'customadd' => true,
						'message' => $this->getRequest()->getParam('simple_product_option'),
						'label' => $this->getRequest()->getParam('simple_product_option_label'),
						'parent_id' => $this->getRequest()->getParam('product')
					);
                    $this->_getSession()->setCartSessionOptions($sessionOptions);
                }
                $this->_goBack();
            }
        } catch (Mage_Core_Exception $e) {
            if ($this->_getSession()->getUseNotice(true)) {
                $this->_getSession()->addNotice(Mage::helper('core')->escapeHtml($e->getMessage()));
            } else {
                $messages = array_unique(explode("\n", $e->getMessage()));
                foreach ($messages as $message) {
                    $this->_getSession()->addError(Mage::helper('core')->escapeHtml($message));
                }
            }

            $url = $this->_getSession()->getRedirectUrl(true);
            if ($url) {
                $this->getResponse()->setRedirect($url);
            } else {
                $this->_redirectReferer(Mage::helper('checkout/cart')->getCartUrl());
            }
        } catch (Exception $e) {
            $this->_getSession()->addException($e, $this->__('Cannot add the item to shopping cart.'));
            Mage::logException($e);
            $this->_goBack();
        }
    }

}