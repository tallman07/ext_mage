<?php

/**
 * 
 * @author HE
 * 
 * Mage_Catalog_Model_Product_Type_Abstract
 * 
 * Mage_Catalog_Model_Product_Type_Simple
 * Mage_Catalog_Model_Product_Type_Virtual
 * Mage_Catalog_Model_Product_Type_Configurable
 * Mage_Catalog_Model_Product_Type_Grouped
 *
 */

class Humanelement_Ymm_Model_Product_Type_Configurable extends Mage_Catalog_Model_Product_Type_Abstract
{

    private $conn;
    private $resource;
    const YMM_TABLE = 'ymm';
    const YMM_TABLE_MAP = 'ymm_map';
	const TOTAL_DROPDOWNS = 10;
    
	/** Make the connection to the YMM database
     * 
     * @return Array
     */
    public function __construct() {
        $this->resource = Mage::getSingleton('core/resource');
        $this->conn = $this->resource->getConnection('ymm_read');
    }
	
    /**
     * Generates the dynamic dropdowns as per the current selected Year, Make and Model
     * 
     * @param string $configurableProductSku
     *
     * @return Array
     */
    public function getYmmConfigurableDropdown($configurableProductSku) {
        $id = Mage::getModel('catalog/product')->getIdBySku($configurableProductSku);
		// Select Year, make and model
		$session = Mage::getSingleton('core/session');
        $year = $session->getData('vehicle_year');
        $make = $session->getData('vehicle_make');
        $model = $session->getData('vehicle_model');
     
        $_product = Mage::getModel('catalog/product')->load($id);
		
		$manLabelId = $_product->getManLabelId();
        $manLabelId = isset($manLabelId) ? $manLabelId : 0;
		
		$dropdownFields = '';
		for ($i = 1; $i <= self::TOTAL_DROPDOWNS; $i++) {
			$dropdownFields .= "`dropdown$i`".",";
		}
		$dropdownFields = substr($dropdownFields, 0, -1);
		
		$sqlGetYmmDropdowns = "select * from ".self::YMM_TABLE." where `man_label_id` IN ($manLabelId)";
		$groupBy = " group by $dropdownFields";
		
		$ymmSelection = '';
		if ($model) {
			$ymmSelection .= " and year='$year' and make='$make' and model='$model' ";  
        }
		
	    $sqlGetYmmDropdowns .= $ymmSelection.$groupBy;
		$result = $this->conn->fetchAll($sqlGetYmmDropdowns);
		
        $flag = 0;
        $dropdownLabels = array();
		$dropdowns = array();
		
		if (count($result)) {
			foreach ($result as $row) {
				
				for ($i = 1; $i <= self::TOTAL_DROPDOWNS; $i++) {
					if (trim($row['dropdown'.$i]) != "" && ($row['dropdown'.$i]) != NULL && !in_array('dropdown'.$i, $dropdownLabels)) {              
						$dropdownLabels[] = "`prompt_dropdown$i`";
						$dropdowns[] = "`dropdown$i`";
						$flag++;
					}
				}      
				
				if ($flag == self::TOTAL_DROPDOWNS) {
					break; 
				}
			}
			
			$strDropDown = implode(",", array_unique($dropdowns));
			
			if ($strDropDown != '') {
				$nonEmptyDropdown = '';
				foreach (array_unique($dropdowns) as $dropdown) {
					$nonEmptyDropdown .= " and ".$dropdown." != ''";
				}
				
				$sqlFetchNonEmptyDropdowns = "select `sku`, `man_label_id`, $strDropDown from ".self::YMM_TABLE." where `man_label_id` IN ($manLabelId) $nonEmptyDropdown";
				$sqlFetchNonEmptyDropdowns .= $ymmSelection;
				
				$resultFetchNonEmptyDropdowns = $this->conn->fetchAll($sqlFetchNonEmptyDropdowns);
				$ymmResult = $this->setEscapeData($resultFetchNonEmptyDropdowns);
				
// 				// add a final price field and do the magento final price calculation
// 				if (!$model) {
				
// 					// if YMM is not selected, and
// 					// if a SKU exists in the YMM database but does not exist in the Magento database
// 					// Magento will throw a fatal error on the product page (trying to call a function on a non-object)
// 					// because $result for that SKU is a boolean instead of an object
// 					// so we fix that here
					
// 					// it slows down the page load time, but it is only applicable IF YMM is not selected AND if there is a problem with a SKU
// 					// so the overall effect is negligible
					
// 					foreach($ymmResult as &$row) {
// 						$result = Mage::getModel('catalog/product')->loadByAttribute('sku', $row['sku']);
// 						if (is_object($result)) {
// 							$row['finalprice'] = $result->getFinalPrice();
// 						} else {
// 							$row['finalprice'] = '0';
// 						}
// 					}
				
// 				} else {
					
// 					foreach($ymmResult as &$row) {
// 						$row['finalprice'] = Mage::getModel('catalog/product')->loadByAttribute('sku', $row['sku'])->getFinalPrice();
// 					}
					
// 				}

				// Get the matched man_label_ids
				$matchedManLabelIds = $this->getMatchedManLabelIds($ymmResult);
				$labelsOfDropdowns = count($dropdownLabels) ? implode(array_unique($dropdownLabels), ',') : 0;
				$grouBy = " group by " . $labelsOfDropdowns;
				
				if (empty($labelsOfDropdowns)) {
					$labelsOfDropdowns = "*";
					$grouBy = '';
				}
				
				$mapResult = array();
				
				if (!empty($matchedManLabelIds)) {
					$ymmMapQuery = "select $labelsOfDropdowns from ".self::YMM_TABLE_MAP." where man_label_id in (".$matchedManLabelIds.") $grouBy ";
					$mapResult = $this->conn->fetchAll($ymmMapQuery);
				}
				return array('main' => $ymmResult, 'map' => $mapResult, 'config_product' => $_product);
			} else {
				// get the simple SKU if the dropdown is blank
				return array('config_product' => $_product, "simplesku" => $result[0]['sku']);
			}
		} else {
			return array('config_product' => $_product);
		}
    }
	
    /**
     * Get the man_label_ids for dropdown labels
	 *
     * @return String
     */
	protected function getMatchedManLabelIds($resultSet) {
		$matchedManLabelIdsArray = array();
		
		if ($resultSet) {
			foreach ($resultSet as $row) {
				$matchedManLabelIdsArray[] = $row['man_label_id'];
			}
		}
		
		if (count($matchedManLabelIdsArray)) {
			return implode(",", array_unique($matchedManLabelIdsArray));
		} else {
			return false;
		}
	} 
	
    /**
     * Encode the HTML entities of the dropdown value
	 *
     * @return Array
     */
	function setEscapeData($array) {
		
		$return_array = array();
		foreach ($array as $key => $arr) {
			$main_array = array();
			foreach ($arr as $k => $v) {
				$main_array[$k] = htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
			}
			
			$return_array[] = $main_array;
		}
		
		return $return_array;
	}
	
}