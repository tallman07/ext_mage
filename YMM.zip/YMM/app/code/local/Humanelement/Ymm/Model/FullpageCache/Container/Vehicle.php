<?php

/**
 * Placeholder container for homepage special products block
 *
 * @category    Mymodule
 * @package     Oggetto_Mymodule
 */
class Humanelement_Ymm_Model_FullpageCache_Container_Vehicle extends Enterprise_PageCache_Model_Container_Abstract {

    /**
     * Get customer identifier from cookies
     *
     * @return string
     */
    protected function _getIdentifier() {
        return $this->_getCookieValue(Enterprise_PageCache_Model_Cookie::COOKIE_CUSTOMER, '');
    }

    protected function _getCacheId() {
        return 'HUMANELEMENT_VEHICLE_' . md5($_COOKIE["frontend"] . '_' . $this->_getIdentifier());
    }

    public function applyInApp(&$content) {
        $block = $this->_placeholder->getAttribute('block');
        $template = $this->_placeholder->getAttribute('template');

        $block = new $block;
        $block->setTemplate($template);
        $block->setLayout(Mage::app()->getLayout());

        $blockContent = $block->toHtml();

        $this->_applyToContent($content, $blockContent);

        return true;
    }

    protected function _saveCache($data, $id, $tags = array(), $lifetime = null) {
        return false;
    }

}