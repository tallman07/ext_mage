<?php

/**
 * Human - Element
 *
 *
 * DISCLAIMER
 * @category    HumanElement Ymm 
 * @package     Humanelement_Ymm
 * @copyright   Copyright (c) Human Element(www.human-element.com)

 */
class Humanelement_Ymm_Model_Layer extends Mage_Catalog_Model_Layer {

    /**
     * Retrieve current layer product collection
     *
     * @return Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Collection
     */
	
    public function getProductCollection() {

        $urlString = Mage::helper('core/url')->getCurrentUrl();
        $url = Mage::getSingleton('core/url')->parseUrl($urlString);
        $path = $url->getPath();
        $categoryId = $this->getCurrentCategory()->getId();
        if (substr($path, 1, 6) != 'brands') {
            $model = Mage::getSingleton('core/session')->getData('vehicle_model');
            $layer = Mage::getSingleton('ymm/layer');
            $show = Mage::app()->getRequest()->getParam('show_all');
            $rootCategoryId = Mage::app()->getStore()->getRootCategoryId();

            if ($model && $categoryId != $rootCategoryId && $categoryId != '' && $categoryId != NULL) {
                $layer->setData('is_category', 'YES');
				
				$categories_without_ymm_filter = explode(",", Mage::getModel('core/variable')->loadByCode('categories_without_ymm_filter')->getValue('text'));
				
				if (in_array($categoryId, $categories_without_ymm_filter)) {
					// No YMM Filtering on new products and featured products
					if (isset($this->_productCollections[$categoryId])) {
						$collection = $this->_productCollections[$categoryId];
					} else {
						$collection = $this->getCurrentCategory()->getProductCollection();
						$this->prepareProductCollection($collection);
						$this->_productCollections[$categoryId] = $collection;
					}
				} else {
					if (isset($this->_productCollections[$categoryId . $model])) {
						$collection = $this->_productCollections[$categoryId . $model];
					} else {
						$collection = $this->getCurrentCategory()->getProductCollection();
						
						$ucollection = clone $collection;
						$ucollection->addAttributeToFilter(Mage::getModel('core/variable')->loadByCode('universal_product_attribute_code')->getValue('text'), Mage::getModel('core/variable')->loadByCode('universal_product_attribute_code_yes')->getValue('text'));
							 
						$universalProductIds = $ucollection->getAllIds();              

						$collection->clear()->getSelect()->reset('where');
						$this->prepareVehicleModelProductCollection($collection, $universalProductIds);                   
						if (($show == 'true')) {
							unset($collection);
							$layer->setData('filtered', 'NO');
							$collection = $this->getCurrentCategory()->getProductCollection();
							$this->prepareProductCollection($collection);
						}
						$this->_productCollections[$categoryId . $model] = $collection;
					}
				}
            } else if ($model) {				
                if (isset($this->_productCollections[$model])) {
                    $collection = $this->_productCollections[$model];
                } else {
                    $collection = Mage::getModel('catalog/product')->getCollection();
					
                    $this->prepareVehicleModelProductCollection($collection);
                    $this->_productCollections[$model] = $collection;
                }
            } else {
                if (isset($this->_productCollections[$categoryId])) {
                    $collection = $this->_productCollections[$categoryId];
                } else {
                    $collection = $this->getCurrentCategory()->getProductCollection();
                    $this->prepareProductCollection($collection);
                    $this->_productCollections[$categoryId] = $collection;
                }
            }
        } else {
            if (isset($this->_productCollections['brand'])) {
                $collection = $this->_productCollections['brand'];
            } else {
                $collection = Mage::getModel('catalog/product')->getCollection();
                $this->getProducts($collection);
                $this->_productCollections['brand'] = $collection;
            }
        }

        return $collection;
    }

    /**
     * Return products for brand category
     * @param object $collection
     * @return \Humanelement_Ymm_Model_Layer
     */
    public function getProducts($collection) {
        $adminstore = Mage_Core_Model_App::ADMIN_STORE_ID;
        $currentStore = Mage::app()->getStore()->getId();
        $layer = Mage::getSingleton('ymm/layer');
        $model = Mage::getSingleton('core/session')->getData('vehicle_model');
        Mage::app()->getStore()->setId($adminstore);
        /** @var $collection Mage_Catalog_Model_Resource_Product_Collection */
        $brandProducts = Mage::getModel('catalog/product')->getCollection();				
        if ($model && !(Mage::app()->getRequest()->getParam('show_all'))) {
            if (!$layer->getData('item_id')) {
                Mage::getModel('ymm/ymm')->getManLabelId();
            }
            $this->prepareVehicleModelProductCollectionForBrands($brandProducts);
        } 
		
        $brandProducts->addAttributeToSelect(AW_Shopbybrand_Model_Source_Attribute::ATTRIBUTE_CODE);
        $brandProducts->addFieldToFilter(AW_Shopbybrand_Model_Source_Attribute::ATTRIBUTE_CODE, array('eq' => Mage::getModel('awshopbybrand/brand')->getBrand()->getId()));
        $ids = $brandProducts->getAllIds();
	
        Mage::app()->getStore()->setId($currentStore);
        $collection
                ->addAttributeToSelect(Mage::getSingleton('catalog/config')->getProductAttributes())
                ->addMinimalPrice()
                ->addFinalPrice()
                ->addTaxPercents()
                ->addUrlRewrite();
        $collection->addAttributeToFilter('entity_id', array('in' => $ids));
		
		Mage::getSingleton('catalog/product_status')->addVisibleFilterToCollection($collection);
        Mage::getSingleton('catalog/product_visibility')->addVisibleInCatalogFilterToCollection($collection);
		
        return $this;
    }

    /**
     * Initialize product collection
     *
     * @param Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Collection $collection
     * @return \Humanelement_Ymm_Model_Layer
     */
    public function prepareProductCollection($collection) {
		$collection
                ->addAttributeToSelect(Mage::getSingleton('catalog/config')->getProductAttributes())
                ->addMinimalPrice()
                ->addFinalPrice()
                ->addTaxPercents()
                ->addUrlRewrite($this->getCurrentCategory()->getId()); 
        Mage::getSingleton('catalog/product_status')->addVisibleFilterToCollection($collection);
        Mage::getSingleton('catalog/product_visibility')->addVisibleInCatalogFilterToCollection($collection);

        return $this;
    }

    /**
     * Initialize product collection
     * 
     * @param Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Collection $collection
     * @return \Humanelement_Ymm_Model_Layer
     */
    public function prepareVehicleModelProductCollection($collection, $universalProductIds = array()) {
        $layer = Mage::getSingleton('ymm/layer');
        if (!$layer->getData('man_label_id')) {
            Mage::getModel('ymm/ymm')->getManLabelId();
        }
		
        $collection->addAttributeToSelect(Mage::getSingleton('catalog/config')
                ->getProductAttributes())
                ->addMinimalPrice()
                ->addFinalPrice()
                ->addTaxPercents()
                ->addUrlRewrite();
		
        $prepare_prod_label_find_set = "";
		$check = 1;
		
		foreach (array_unique($layer->getData('man_label_id')) as $man_label_id) {
            if ($check) {
                $prepare_prod_label_find_set .= "FIND_IN_SET('".$man_label_id."',`man_label_id`)";
				$check =0;
            } else { 
                $prepare_prod_label_find_set .= " OR FIND_IN_SET('".$man_label_id."',`man_label_id`)";
            }
        }
        
        $connection = Mage::getSingleton('core/resource')->getConnection('core_read');
        $sqlGetMatchedProducts = "select `entity_id` from catalog_product_flat_1 where (".$prepare_prod_label_find_set.") ";
        
		$resultSet = $connection->fetchAll($sqlGetMatchedProducts); 
        $new_array = array();
        foreach($resultSet as $child) {
            $new_array[] = $child['entity_id'];
        }
		
        Mage::getSingleton('catalog/product_status')->addVisibleFilterToCollection($collection);
        Mage::getSingleton('catalog/product_visibility')->addVisibleInCatalogFilterToCollection($collection);
		
		$new_array = array_unique(array_merge($universalProductIds, $new_array));
        sort($new_array);
        
		if (count($new_array) > 0) {
            $collection->addAttributeToFilter('entity_id', array($new_array));
        } else {
            $collection->addAttributeToFilter('entity_id', array(0));
        }

        return $this;
    }
	
    /**
     * Initialize product collection for ahead work brand extension
     * 
     * @param Mage_Catalog_Model_Resource_Eav_Mysql4_Product_Collection $collection
     * @return \Humanelement_Ymm_Model_Layer
     */
    public function prepareVehicleModelProductCollectionForBrands($collection) {

		$ucollection = clone $collection;
		$ucollection->addAttributeToFilter(Mage::getModel('core/variable')->loadByCode('universal_product_attribute_code')->getValue('text'), Mage::getModel('core/variable')->loadByCode('universal_product_attribute_code_yes')->getValue('text'));
		
		$universalProductIds = $ucollection->getAllIds();
		$collection->clear()->getSelect()->reset('where');
		
        $layer = Mage::getSingleton('ymm/layer');
        
		if (!$layer->getData('item_id')) {
            Mage::getModel('ymm/ymm')->getManLabelId();
        }
        
        $prepare_prod_label_find_set = ""; 
        $check = 1;
        foreach (array_unique($layer->getData('man_label_id')) as $man_label_id) {
            if ($check){
                $prepare_prod_label_find_set .= "FIND_IN_SET('".$man_label_id."', `man_label_id`)";
                $check = 0;
            } else { 
                $prepare_prod_label_find_set .= " OR FIND_IN_SET('".$man_label_id."', `man_label_id`)";
            }
        }
        
        $connection = Mage::getSingleton('core/resource')->getConnection('core_read');
        $sqlGetItemsForBrands = "select `entity_id` from catalog_product_flat_1 where (".$prepare_prod_label_find_set.") ";
        $resultSet = $connection->fetchAll($sqlGetItemsForBrands); 
        $new_array = array();
        foreach($resultSet as $child){
            $new_array[] = $child['entity_id'];
        }
		
        $new_array = array_unique(array_merge($universalProductIds, $new_array));
        sort($new_array);
        
        if (count($new_array) > 0) {
            $collection->addAttributeToFilter('entity_id', array($new_array));				  
        } else {
            $collection->addAttributeToFilter('entity_id', array(0));
        }

        return $this;
    }
	
}

?>