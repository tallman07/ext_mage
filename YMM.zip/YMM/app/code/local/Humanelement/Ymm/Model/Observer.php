<?php
class Humanelement_Ymm_Model_Observer {
	
	public function processPreDispatch(Varien_Event_Observer $observer) {
        $year = Mage::app()->getRequest()->getParam('year');
        $make = Mage::app()->getRequest()->getParam('make');
        $model = Mage::app()->getRequest()->getParam('model');
        $show = Mage::app()->getRequest()->getParam('show_all');
        if (isset($year) && isset($make) && isset($model)) {
            $session = Mage::getSingleton('core/session');
            $session->setData('vehicle_year', $year);
            $session->setData('vehicle_model', $model);
            $session->setData('vehicle_make', $make);
            if (isset($show)) {
                $session->setData('show_all', TRUE);
            }
        }
    }
	
    /**
     * Load the layout for YMM configurable and YMM multiconfigurable products
     * 
     * @param $observer
	 *
     * @return \Mage_Core_Model_Layout_Update
     */
	public function addCustomHandles($observer) {
		$update = Mage::getSingleton('core/layout')->getUpdate();
		$action = Mage::app()->getFrontController()->getAction();
		
		// Check if we are viewing the product page
		if ($action->getFullActionName() == 'catalog_product_view') {
			$_product = Mage::registry('current_product');
			$typeId = $_product->getTypeId();
			
			$bossUniversalYes = Mage::getModel('core/variable')->loadByCode('universal_product_attribute_code_yes')->getValue('text');
			$productUniversalValue = $_product->getBossUniversal();	
			if ($productUniversalValue == $bossUniversalYes) {
				// No layout, the default Magento product view will be called
				return;
			}
			// Do nothing excluding simple and configurable products
			if ($_product && ($typeId == 'simple' || $typeId == 'configurable')) {
				$boss_product_type = $_product->getYmmProductType();
				// Change the layout for YMM Configurable and YMM Multiconfigurable, if the product has the man_label_id, then update the layout handle
				if ($boss_product_type == Mage::getModel('core/variable')->loadByCode('ymm_product_attribute_type_configurable')->getValue('text') && $_product->getManLabelId() != '') {
					$update->addHandle('PRODUCT_TYPE_ymmconfigurable');
				// if the product type is multiconfig and has the associate config skus, update the handle
				} else if ($boss_product_type == Mage::getModel('core/variable')->loadByCode('ymm_product_attribute_type_multiconfigurable')->getValue('text') && $_product->getAssociateConfig() != '') {					
					$update->addHandle('PRODUCT_TYPE_ymmmulticonfigurable');
				}
			} else {
				return;
			}
		}
	}
	
	/**
     * Add the user selected attributes to the product
     * 
     * @param $observer
	 *
     * @return \Mage_Catalog_Model_Product
     */
	public function catalogProductLoadAfterAddCustomOptions(Varien_Event_Observer $observer) {
		// set the additional options on the product
		$action = Mage::app()->getFrontController()->getAction();
		$params = Mage::app()->getRequest()->getParams();
		$options = array();
		
		if ($action->getFullActionName() == 'checkout_cart_add') {			
			if (!empty($params['uniquesku']) && $params['product_found'] == 'Yes') {
				$options = $params['super_attribute'];
				
				$product = $observer->getProduct();
				// Add to the additional options array
				$additionalOptions = array();
				if ($additionalOption = $product->getCustomOption('additional_options')) {
					$additionalOptions = (array) unserialize($additionalOption->getValue());
				}
				// Add the Vehicle selection, Part number and sku for order email
				$boss_mpn = $product->getBossManufacturerPartNo();
				$options['SKU'] = $product->getSku();				
				if ($boss_mpn != '') {
					$options['Part#'] = $boss_mpn;
				}
				
				$ymmSession = Mage::getModel('ymm/ymm')->getSessionYmm();
				if (isset($ymmSession['year']) && isset($ymmSession['make']) && isset($ymmSession['model'])) {
					$options['Vehicle'] = $ymmSession['year']."-".$ymmSession['make']."-".$ymmSession['model'];
				}
				
				foreach ($options as $key => $value) {
					$additionalOptions[] = array(
						'label' => $key,
						'value' => $value,
					);
				}
				
				// Add the additional options array with the option code additional_options only for ymmconfig product
				$product->addCustomOption('additional_options', serialize($additionalOptions));
			}
		} 
	}
	
    /**
     *  Move the option from the quote item to the order item. 
	 *  From this point on the additional options will be visible in the customer order history in the frontend 
	 *	and the order emails, as well as in the admin interface order view, invoices, shipments, creditmemos and PDFs
     * 
     * @param $observer
	 *
     * @return \Mage_Sales_Model_Order
     */
	public function salesConvertQuoteItemToOrderItem(Varien_Event_Observer $observer) {
		$quoteItem = $observer->getItem();
		if ($additionalOptions = $quoteItem->getOptionByCode('additional_options')) {
			$orderItem = $observer->getOrderItem();
			$options = $orderItem->getProductOptions();
			$options['additional_options'] = unserialize($additionalOptions->getValue());
			$orderItem->setProductOptions($options);
		}
    }
	
    /**
     * Add support for reorders
     * 
     * @param $observer
	 *
     * @return \Mage_Sales_Model_Order
     */
	public function checkoutCartProductAddAfter(Varien_Event_Observer $observer) {
		$action = Mage::app()->getFrontController()->getAction();
		if ($action->getFullActionName() == 'sales_order_reorder') {
			$item = $observer->getQuoteItem();
			$buyInfo = $item->getBuyRequest();
			
			if ($options = $buyInfo->getExtraOptions()) {
				$additionalOptions = array();
				if ($additionalOption = $item->getOptionByCode('additional_options')) {
					$additionalOptions = (array) unserialize($additionalOption->getValue());
				}
				foreach ($options as $key => $value) {
					$additionalOptions[] = array(
						'label' => $key,
						'value' => $value,
					);
				}
				$item->addOption(array(
					'code' => 'additional_options',
					'value' => serialize($additionalOptions)
				));
			}
		}
	}
	
	public function hookIntoCatalogProductNewAction($observer)
    {
        $product = $observer->getEvent()->getProduct();
        //echo 'Inside hookIntoCatalogProductNewAction observer...'; exit;
        //Implement the "catalog_product_new_action" hook
        return $this;    	
    }
    
    public function hookIntoCatalogProductEditAction($observer)
    {
        $product = $observer->getEvent()->getProduct();
        //echo 'Inside hookIntoCatalogProductEditAction observer...'; exit;
        //Implement the "catalog_product_edit_action" hook
        return $this;    	
    }    
    
    public function hookIntoCatalogProductPrepareSave($observer)
    {
        $product = $observer->getEvent()->getProduct();
        $event = $observer->getEvent();
        //echo 'Inside hookIntoCatalogProductPrepareSave observer...'; exit;
        //Implement the "catalog_product_prepare_save" hook
        return $this;    	
    }

    public function hookIntoSalesOrderItemSaveAfter($observer)
    {
        //$event = $observer->getEvent();
        //echo 'Inside hookIntoSalesOrderItemSaveAfter observer...'; exit;
        //Implement the "sales_order_item_save_after" hook
        return $this;    	
    }

    public function hookIntoSalesOrderSaveBefore($observer)
    {
        //$event = $observer->getEvent();
        //echo 'Inside hookIntoSalesOrderSaveBefore observer...'; exit;
        //Implement the "sales_order_save_before" hook
        return $this;    	
    }     
    
    public function hookIntoSalesOrderSaveAfter($observer)
    {
        $product = $observer->getEvent()->getProduct();
        //echo 'Inside hookIntoSalesOrderSaveAfter observer...'; exit;
        //Implement the "sales_order_save_after" hook
        return $this;    	
    } 

    public function hookIntoCatalogProductDeleteBefore($observer)
    {
        $product = $observer->getEvent()->getProduct();
        //echo 'Inside hookIntoCatalogProductDeleteBefore observer...'; exit;
        //Implement the "catalog_product_delete_before" hook
        return $this;    	
    }    
    
    public function hookIntoCatalogruleBeforeApply($observer)
    {
        //$event = $observer->getEvent();
        //echo 'Inside hookIntoCatalogruleBeforeApply observer...'; exit;
        //Implement the "catalogrule_before_apply" hook
        return $this;    	
    }  

    public function hookIntoCatalogruleAfterApply($observer)
    {
        //$event = $observer->getEvent();
        //echo 'Inside hookIntoCatalogruleAfterApply observer...'; exit;
        //Implement the "catalogrule_after_apply" hook
        return $this;    	
    }    
    
    public function hookIntoCatalogProductSaveAfter($observer)
    {
        $product = $observer->getEvent()->getProduct();
        $event = $observer->getEvent();
        //echo 'Inside hookIntoCatalogProductSaveAfter observer...'; exit;
        //Implement the "catalog_product_save_after" hook
        return $this;    	
    }   
	
    public function hookIntoCatalogProductStatusUpdate($observer)
    {
        $product = $observer->getEvent()->getProduct();
        $event = $observer->getEvent();
        //echo 'Inside hookIntoCatalogProductStatusUpdate observer...'; exit;
        //Implement the "catalog_product_status_update" hook
        return $this;    	
    }

    public function hookIntoCatalogEntityAttributeSaveAfter($observer)
    {
        //$event = $observer->getEvent();
        
        //Implement the "catalog_entity_attribute_save_after" hook
        return $this;    	
    }
    
    public function hookIntoCatalogProductDeleteAfterDone($observer)
    {
        $product = $observer->getEvent()->getProduct();
        $event = $observer->getEvent();
        //echo 'Inside hookIntoCatalogProductDeleteAfterDone observer...'; exit;
        //Implement the "catalog_product_delete_after_done" hook
        return $this;    	
    }
    
    public function hookIntoCustomerLogin($observer)
    {
        $event = $observer->getEvent();
        //echo 'Inside hookIntoCustomerLogin observer...'; exit;
        //Implement the "customer_login" hook
        return $this;    	
    }       

    public function hookIntoCustomerLogout($observer)
    {
        $event = $observer->getEvent();
        //echo 'Inside hookIntoCustomerLogout observer...'; exit;
        //Implement the "customer_logout" hook
        return $this;    	
    }

    public function hookIntoSalesQuoteSaveAfter($observer)
    {
        $event = $observer->getEvent();
        //echo 'Inside hookIntoSalesQuoteSaveAfter observer...'; exit;
        //Implement the "sales_quote_save_after" hook
        return $this;    	
    }

    public function hookIntoCatalogProductCollectionLoadAfter($observer)
    {
        $event = $observer->getEvent();
        //echo 'Inside hookIntoCatalogProductCollectionLoadAfter observer...'; exit;
        //Implement the "catalog_product_collection_load_after" hook
        return $this;    	
    }
}
?>
