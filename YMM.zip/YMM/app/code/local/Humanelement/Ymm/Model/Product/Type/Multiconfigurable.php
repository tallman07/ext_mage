<?php

/**
 * 
 * @author HE
 * 
 * Mage_Catalog_Model_Product_Type_Abstract
 * 
 * Mage_Catalog_Model_Product_Type_Simple
 * Mage_Catalog_Model_Product_Type_Virtual
 * Mage_Catalog_Model_Product_Type_Configurable
 * Mage_Catalog_Model_Product_Type_Grouped
 *
 */

class Humanelement_Ymm_Model_Product_Type_Multiconfigurable extends Mage_Catalog_Model_Product_Type_Abstract
{
    /** Get the associated products for multiconfig product type
     * 
     * @return Array
     */
    public function getAssociatedProductIds() {
        $_product = Mage::registry('current_product');
        $configProductSkus = $_product->getAssociateConfig();
		$skus = explode(',', $configProductSkus);
		
		$_collections = Mage::getSingleton('catalog/product')
						->getCollection()
						->addAttributeToFilter('sku', array('in' => array($skus)));
        
		// Returns the associated products
        return $_collections; 
    }

}