<?php

/**
 * Human - Element
 *
 *
 * DISCLAIMER
 * @category    HumanElement Ymm 
 * @package     Humanelement_Ymm
 * @copyright   Copyright (c) Human Element(www.human-element.com)

 */
class Humanelement_Ymm_Model_Ymm {

    private $conn;
    private $resource;
	
    /**
     * Connect to the YMM database
     * 
     * @return array
     */
	public function getDbConnection() {
        $this->resource = Mage::getSingleton('core/resource');
		$websiteCode = Mage::app()->getWebsite()->getCode();
		
		Mage::log('The current website is '.$websiteCode, null, 'developer.log');
		if ($websiteCode == 'vehicle') {
			// Use another YMM connection
			$this->conn = $this->resource->getConnection('ymm_muscle_read');
		} else {
			// Use default YMM connection
			$this->conn = $this->resource->getConnection('ymm_read');
		}
    }

    /**
     * Get total year from YMM
     * 
     * @return array
     */
    public function getYears() {
        $vehicleYear = array();
        $cache = Mage::app()->getCache();
        $vehicleYear = $cache->load("vehicle_year");
        if ($vehicleYear) { 
            $vehicleYear = unserialize($vehicleYear);
        } else {
            $this->getDbConnection(); 
            $years = $this->conn->query("SELECT distinct(year) FROM ymm order by year desc");
			
            foreach ($years as $year) {
                $vehicleYear[] = $year['year'];
            }
            $cache->save(serialize($vehicleYear), 'vehicle_year');
        }

        return $vehicleYear;
    }
	
    /**
     * get year, make and mode values if session been saved
     * 
     * @return array
     */
    public function getSessionYmm() {
        $session = Mage::getSingleton('core/session');
        $year = $session->getData('vehicle_year');
        $make = $session->getData('vehicle_make');
        $model = $session->getData('vehicle_model');

        return array('year' => $year, 'make' => $make, 'model' => $model);
    }
	
    /**
     * Get Make base on year
     * 
     * @param int $year
     * @return array
     */
    public function getVehicleMaker($year) {
        $vehicleMake = array();
        $cache = Mage::app()->getCache();
        $vehicleMake = $cache->load($year);
		
        if ($vehicleMake) {
            $vehicleMake = unserialize($vehicleMake);
        } else {
            $this->getDbConnection();
            $maker = $this->conn->query("SELECT distinct(make) FROM ymm WHERE year = '$year' ORDER BY make ASC");
            foreach ($maker as $make) {
                $vehicleMake[] = $make['make'];
            }

            $cache->save(serialize($vehicleMake), $year);
        }

        return $vehicleMake;
    }

    /**
     * Get vehicle model base on year and make
     * 
     * @param int $year
     * @param string $make
     * @return array
     */
    public function getVehicleModel($year, $make) {
        $vehicleModel = array();
        
        $cache = Mage::app()->getCache();
        $vehicleModel = $cache->load($year . $make);
        if ($vehicleModel) {
            $vehicleModel = unserialize($vehicleModel);
        } else {
            $this->getDbConnection();
            $models = $this->conn->query("SELECT distinct(model) FROM ymm WHERE year = '$year' AND make = '$make' ORDER BY model ASC");
            foreach ($models as $model) {
                $vehicleModel[] = $model['model'];
            }

            $cache->save(serialize($vehicleModel), $year . $make);
        }

        return $vehicleModel;
    }
    
    /**
     * Get the result base year, make and model and store into object
     * 
     * @return null
     */
    public function getManLabelId() {
        $session = Mage::getSingleton('core/session');
        $year = $session->getData('vehicle_year');
        $make = $session->getData('vehicle_make');
        $model = $session->getData('vehicle_model');
        $layer = Mage::getSingleton('ymm/layer');
        $cache = Mage::app()->getCache();
        $man_prod_label = 0;//$cache->load($year . $make . $model);
        if ($man_prod_label) {
            $man_prod_label = unserialize($man_prod_label);
            $layer->setData('man_label_id', $man_prod_label['man_label_id']);
        } else {
            $this->getDbConnection();
            $result = $this->conn->query("SELECT distinct(`man_label_id`) FROM ymm WHERE year = '$year' AND make = '$make' AND model = '$model' ");
            foreach ($result as $row) {
                $data['man_label_id'][] = $row['man_label_id'];
            }

            $layer->setData('man_label_id', $data['man_label_id']);
            
            $cache->save(serialize($data), $year . $make . $model);
        }
		
        return;
    }
 

    /**
     * Returns year for configurable product view page
     * 
     * If the year list is present in cache then it will be returned back
     * else start fetching from database
     * @param array $prodLabelDetail
     * @return array
     */
    public function getYearForConfigurableProduct($prodLabelDetail) {
        $configurableYear = array();
        $prodLabelDetail['man_label_id'] = $prodLabelDetail['man_label_id'] == "" 
                                            ? "0" : $prodLabelDetail['man_label_id'];
        
        $this->getDbConnection();
        $years = $this->conn->query("SELECT distinct year FROM ymm WHERE `man_label_id` IN (" . $prodLabelDetail['man_label_id'] . ") order by year desc");

        foreach ($years as $ymm) {
            $configurableYear[] = $ymm['year'];
        }

        return $configurableYear;
    }

    /**
     * Returns make for configurable product view page
     * 
     * If the make list is present in cache then it will be returned back
     * else start fetching from database
     * @param array $prodLabelDetail
     * @param int $year
     * @return array
     */
    public function getMakeForConfigurableProduct($prodLabelDetail, $year) {
        $configurableMake = array();
        $this->getDbConnection();
        $prodLabelDetail['man_label_id'] = $prodLabelDetail['man_label_id'] == "" 
                                            ? "0" : $prodLabelDetail['man_label_id']; 
        $maker = $this->conn->query("SELECT distinct(make) FROM ymm WHERE man_label_id IN (" . $prodLabelDetail['man_label_id'] . ") and year='$year' ORDER BY make ASC");
        foreach ($maker as $make) {
            $configurableMake[] = $make['make'];
        }
		
        return $configurableMake;
    }

    /**
     * Returns model for configurable product view page
     * 
     * If the model list is present in cache then it will be returned back
     * else start fetching from database
     * @param array $prodLabelDetail
     * @param int $year
     * @param string $make
     * @return array
     */
    public function getModelForConfigurableProduct($prodLabelDetail, $year, $make) {
        $configurableModel = array();
        $this->getDbConnection();
        $prodLabelDetail['man_label_id'] = $prodLabelDetail['man_label_id'] == "" 
                                            ? "0" : $prodLabelDetail['man_label_id']; 
        $models = $this->conn->query("SELECT distinct(model) FROM ymm WHERE man_label_id IN (" . $prodLabelDetail['man_label_id'] . ") and year='$year' and make='$make' ORDER BY model ASC");
        foreach ($models as $model) {
            $configurableModel[] = $model['model'];
        }

        return $configurableModel;
    }

    /**
     * Returns boss part number and brand id base on configurable product id
     * 
     * @param int $configurableProductId
     * @return array
     */
    public function getBossCollection($configurableProductId) {
        $configurableProduct = Mage::getModel('catalog/product')->load($configurableProductId);
        $prod_label = $configurableProduct->getManLabelId();
        $prod_label = rtrim($prod_label, ",");
		
        return array('man_label_id' => $prod_label);
    }


    /**
     * Returns year for simple product view page
     * 
     * If the year list is present in cache then it will be returned back
     * else start fetching from database
     * @param string $man_label_id 
     * @return array
     */
    public function getYearForSimpleProductPage($man_label_id) {
        $simpleYear = array();

        if ($man_label_id == "") $man_label_id = "0";
        $this->getDbConnection();
        $years = $this->conn->query("SELECT distinct year FROM ymm WHERE man_label_id IN (" . $man_label_id . ") order by year desc");
        foreach ($years as $ymm) {
            $simpleYear[] = $ymm['year'];
        }

        return $simpleYear;
    }

    /**
     * Returns make for simple product view page
     * 
     * If the make list is present in cache then it will be returned back
     * else start fetching from database
     * @param string $man_label_id 	  
     * @param int $year
     * @return array
     */
    public function getMakeForSimpleProductPage($man_label_id, $year) {
        $simpleMake = array();
        $this->getDbConnection();
        if ($man_label_id == "") $man_label_id = "0";
        $maker = $this->conn->query("SELECT distinct(make) FROM ymm WHERE man_label_id IN (" . $man_label_id . ") and year='$year' ORDER BY make ASC");
        foreach ($maker as $make) {
            $simpleMake[] = $make['make'];
        }
		
        return $simpleMake;
    }

    /**
     * Returns model for simple product view page
     * 
     * If the model list is present in cache then it will be returned back
     * else start fetching from database
     * @param string $man_label_id 
     * @param int $year
     * @param string $make
     * @return array
     */
    public function getModelForSimpleProductPage($man_label_id, $year, $make) {
        $simpleModel = array();
        $this->getDbConnection();
        if ($man_label_id == "") $man_label_id = "0";
        $models = $this->conn->query("SELECT distinct(model) FROM ymm WHERE man_label_id IN (" .$man_label_id. ") and year='$year' and make='$make' ORDER BY model ASC");
        foreach ($models as $model) {
            $simpleModel[] = $model['model'];
        }

        return $simpleModel;
    }
	
    /**
     * Checks if the product is ymmconfig, ymmmulticonfig and is universal no
     * 
     * @param int $product_id
     * @return boolean
     */
    public function isYmmProductAddToCart($product_id, $view = false) {
        $_product = Mage::getSingleton('catalog/product')->load($product_id);
		
		$YmmProductType = $_product->getYmmProductType();
		$productBossUniversal = $_product->getBossUniversal();
		
		$ymmStandardType = Mage::getModel('core/variable')->loadByCode('ymm_product_attribute_type_standard')->getValue('text');
		$ymmConfigType =  Mage::getModel('core/variable')->loadByCode('ymm_product_attribute_type_configurable')->getValue('text');
		$ymmMultiConfigType =  Mage::getModel('core/variable')->loadByCode('ymm_product_attribute_type_multiconfigurable')->getValue('text');
		
		$universal_product_attribute_code_yes =  Mage::getModel('core/variable')->loadByCode('universal_product_attribute_code_yes')->getValue('text');
		
		if ($productBossUniversal == $universal_product_attribute_code_yes || $YmmProductType == $ymmStandardType) {
			if (!$_product->isSaleable()) {
				return false;
			} else {
				return true;
			}
		} else {
			$ymmSession = Mage::getModel('ymm/ymm')->getSessionYmm();
			if (($YmmProductType == $ymmMultiConfigType || $YmmProductType == $ymmConfigType) && isset($ymmSession['model'])) {
				// No Out Of Stock text
				if ($view)	{
					return true;
				} else {
					return null;
				}
			} else if (!$_product->isSaleable()) {
				return false;
			} else {
				return true;
			}
		}
		
		if (!$_product->isSaleable()) {
			return false;
		} else {
			return true;
		}
    }
	
    /**
     * Checks if the product can be added to cart from the view page
     * 
     * @param int $product_id
     * @return boolean
     */
    public function isYmmProductAddToCartFromViewPage($product_id) {
        $_product = Mage::getSingleton('catalog/product')->load($product_id);
		
		$YmmProductType = $_product->getYmmProductType();
		$ymmConfigType = Mage::getModel('core/variable')->loadByCode('ymm_product_attribute_type_configurable')->getValue('text');
		$product_match = $this->isSimpleProductMatchYmm($_product->getId(), $_product->getData('man_label_id'));
		
		if (!$product_match) {
			return false;
		} else {
			if ($_product->isSaleable() || ($YmmProductType == $ymmConfigType && $_product->getTypeId() == 'configurable')) {
				return true;
			}
		}
		
		return true;
    }
	
    /**
	 * check simple product match with ymm selection
	 *
	 * @param int $id
     * @param string $prod_labels 
	 * @return boolean
	 */
	public function isSimpleProductMatchYmm($id, $prod_labels) {
        $layer = Mage::getSingleton('ymm/layer');
        $model = Mage::getSingleton('core/session')->getData('vehicle_model');
        if (!$layer->getData('man_label_id')) {
            Mage::getModel('ymm/ymm')->getManLabelId();
        }
        $token = false;
        if ($model) {
            foreach (explode(',', $prod_labels) as $item_id) {
                if (in_array($item_id, array_unique($layer->getData('man_label_id')))) {
                    $token = true;
                    break;
                }
            }
        }
		
        return $token;
    }

}

?>