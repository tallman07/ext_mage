<?php

/**
 * Human - Element
 *
 *
 * DISCLAIMER
 * @category    HumanElement Ymm 
 * @package     Humanelement_Ymm
 * @copyright   Copyright (c) Human Element(www.human-element.com)

 */
class Humanelement_Ymm_Block_Product_View_Type_Configurable extends Mage_Catalog_Block_Product_View_Type_Configurable {
    
    /**
     * Returns the dropdowns for YMM Configurable product
     * 
     * @return array
     */
	public function getYmmConfigurableDropdown($productSku) {
        $ymmConfigurable = $this->getYmmConfigurableObject();
        $dropdownArray = $ymmConfigurable->getYmmConfigurableDropdown($productSku);
        
		return $dropdownArray;
    }
	
    /**
     * Get the YMM Configurable model object instance
     * 
     * @return array
     */
    public function getYmmConfigurableObject(){
        return Mage::getModel('ymm/product_type_configurable');
    }
	
	/**
     * return json string of all filtered attribute collection for configurable product
     * 
     * @return json string
     */
    public function getJsonConfig() {
        $attributes = array();
        $options = array();
        $store = $this->getCurrentStore();
        $taxHelper = Mage::helper('tax');
        $currentProduct = $this->getProduct();
        $_blockData = $this->getLayout()->getBlockSingleton('ymm/product_view');
        $childValue = $_blockData->getFilteredAssociatedProductOptionArray($currentProduct->getId());

        $preconfiguredFlag = $currentProduct->hasPreconfiguredValues();
        if ($preconfiguredFlag) {
            $preconfiguredValues = $currentProduct->getPreconfiguredValues();
            $defaultValues = array();
        }

        foreach ($this->getAllowProducts() as $product) {
            $productId = $product->getId();

            foreach ($this->getAllowAttributes() as $attribute) {
                $productAttribute = $attribute->getProductAttribute();
                $productAttributeId = $productAttribute->getId();
                $attributeValue = $product->getData($productAttribute->getAttributeCode());
                if (!isset($options[$productAttributeId])) {
                    $options[$productAttributeId] = array();
                }

                if (!isset($options[$productAttributeId][$attributeValue])) {
                    $options[$productAttributeId][$attributeValue] = array();
                }
                $options[$productAttributeId][$attributeValue][] = $productId;
            }
        }

        $this->_resPrices = array(
            $this->_preparePrice($currentProduct->getFinalPrice())
        );

        foreach ($this->getAllowAttributes() as $attribute) {
            $productAttribute = $attribute->getProductAttribute();
            $attributeId = $productAttribute->getId();
            $info = array(
                'id' => $productAttribute->getId(),
                'code' => $productAttribute->getAttributeCode(),
                'label' => $attribute->getLabel(),
                'options' => array()
            );

            $optionPrices = array();
            $prices = $attribute->getPrices();
            if (is_array($prices)) {
                foreach ($prices as $value) {
                    if (!$this->_validateAttributeValue($attributeId, $value, $options)) {
                        continue;
                    }
                    $currentProduct->setConfigurablePrice(
                            $this->_preparePrice($value['pricing_value'], $value['is_percent'])
                    );
                    $currentProduct->setParentId(true);
                    Mage::dispatchEvent(
                            'catalog_product_type_configurable_price', array('product' => $currentProduct)
                    );
                    $configurablePrice = $currentProduct->getConfigurablePrice();

                    if (isset($options[$attributeId][$value['value_index']])) {
                        $productBuffer = array();
                        foreach ($options[$attributeId][$value['value_index']] as $ids) {
                            if (in_array($ids, $childValue['associatedIds'])) {
                                $productBuffer[] = $ids;
                            }
                        }
                        $productsIndex = $productBuffer;
                    } else {
                        $productsIndex = array();
                    }
                    if (in_array($value['value_index'], $childValue['childValue'])) {
                        $info['options'][] = array(
                            'id' => $value['value_index'],
                            'label' => $value['label'],
                            'price' => $configurablePrice,
                            'oldPrice' => $this->_prepareOldPrice($value['pricing_value'], $value['is_percent']),
                            'products' => $productsIndex,
                        );
                    }
                    $optionPrices[] = $configurablePrice;
                }
            }
            /**
             * Prepare formated values for options choose
             */
            foreach ($optionPrices as $optionPrice) {
                foreach ($optionPrices as $additional) {
                    $this->_preparePrice(abs($additional - $optionPrice));
                }
            }
            if ($this->_validateAttributeInfo($info)) {
                $attributes[$attributeId] = $info;
            }

            // Add attribute default value (if set)
            if ($preconfiguredFlag) {
                $configValue = $preconfiguredValues->getData('super_attribute/' . $attributeId);
                if ($configValue) {
                    $defaultValues[$attributeId] = $configValue;
                }
            }
        }

        $taxCalculation = Mage::getSingleton('tax/calculation');
        if (!$taxCalculation->getCustomer() && Mage::registry('current_customer')) {
            $taxCalculation->setCustomer(Mage::registry('current_customer'));
        }

        $_request = $taxCalculation->getRateRequest(false, false, false);
        $_request->setProductClassId($currentProduct->getTaxClassId());
        $defaultTax = $taxCalculation->getRate($_request);

        $_request = $taxCalculation->getRateRequest();
        $_request->setProductClassId($currentProduct->getTaxClassId());
        $currentTax = $taxCalculation->getRate($_request);

        $taxConfig = array(
            'includeTax' => $taxHelper->priceIncludesTax(),
            'showIncludeTax' => $taxHelper->displayPriceIncludingTax(),
            'showBothPrices' => $taxHelper->displayBothPrices(),
            'defaultTax' => $defaultTax,
            'currentTax' => $currentTax,
            'inclTaxTitle' => Mage::helper('catalog')->__('Incl. Tax')
        );

        $config = array(
            'attributes' => $attributes,
            'template' => str_replace('%s', '#{price}', $store->getCurrentCurrency()->getOutputFormat()),
            'basePrice' => $this->_registerJsPrice($this->_convertPrice($currentProduct->getFinalPrice())),
            'oldPrice' => $this->_registerJsPrice($this->_convertPrice($currentProduct->getPrice())),
            'productId' => $currentProduct->getId(),
            'chooseText' => Mage::helper('catalog')->__('Choose an Option...'),
            'taxConfig' => $taxConfig
        );

        if ($preconfiguredFlag && !empty($defaultValues)) {
            $config['defaultValues'] = $defaultValues;
        }

        $config = array_merge($config, $this->_getAdditionalConfig());

        return Mage::helper('core')->jsonEncode($config);
    }

}
