<?php

/**
 * Human - Element
 *
 *
 * DISCLAIMER
 * @category    HumanElement Ymm 
 * @package     Humanelement_Ymm
 * @copyright   Copyright (c) Human Element(www.human-element.com)

 */
class Humanelement_Ymm_Block_Product_View extends Mage_Catalog_Block_Product_Abstract {

    /**
     * Filtered collection of all associated product for configurable product
     * 
     * @param int $productId
     * @return array
     */
    public function getFilteredAssociatedProduct($productId) {
        $layer = Mage::getSingleton('ymm/layer');
        $model = Mage::getSingleton('core/session')->getData('vehicle_model');
        if (!$layer->getData('man_label_id')) {
            Mage::getModel('ymm/ymm')->getManLabelId();
        }

        $product = Mage::getModel('catalog/product')->load($productId);
        $associatedProduct = Mage::getModel('catalog/product_type_configurable')->getUsedProductIds($product);

        $associatedFilteredProduct = Mage::getModel('catalog/product')->getCollection()
                ->addAttributeToSelect('name')
                ->addAttributeToFilter('entity_id', count($associatedProduct) ? $associatedProduct : 0);

        if ($model) {
            $associatedFilteredProduct
                ->addAttributeToFilter('man_label_id', array('in' => array_unique($layer->getData('man_label_id'))));
				//->addAttributeToFilter(Humanelement_Ymm_Model_Layer::UNIVERSAL_PRODUCT_ATTRIBUTE_CODE, array('eq' => Humanelement_Ymm_Model_Layer::UNIVERSAL_PRODUCT_ATTRIBUTE_CODE_YES));
        }

        return $associatedFilteredProduct;
    }

    /**
     * return array of filtered associated product ids and value of their attribute options
     * 
     * @param int $productId
     * @return array
     */
    public function getFilteredAssociatedProductOptionArray($productId) {
        $layer = Mage::getSingleton('ymm/layer');
        $model = Mage::getSingleton('core/session')->getData('vehicle_model');
        if (!$layer->getData('man_label_id')) {
            Mage::getModel('ymm/ymm')->getManLabelId();
        }

        $product = Mage::getModel('catalog/product')->load($productId);
        $associatedProduct = Mage::getModel('catalog/product_type_configurable')->getUsedProductIds($product);

        $associatedFilteredProduct = Mage::getModel('catalog/product')->getCollection()
                ->addAttributeToSelect('name')
                ->addAttributeToFilter('entity_id', count($associatedProduct) ? $associatedProduct : 0);

        if ($model) {
            $associatedFilteredProduct
                    ->addAttributeToFilter('man_label_id', array('in' => array_unique($layer->getData('man_label_id'))));
					//->addAttributeToFilter(Humanelement_Ymm_Model_Layer::UNIVERSAL_PRODUCT_ATTRIBUTE_CODE, array('eq' => Humanelement_Ymm_Model_Layer::UNIVERSAL_PRODUCT_ATTRIBUTE_CODE_YES));
        }

        $attributes = $product->getTypeInstance(true)->getConfigurableAttributesAsArray($product);
        $childValue = array();
        $associatedIds = array();
        foreach ($associatedFilteredProduct as $product) {
            $child = Mage::getModel('catalog/product')->setStoreId(Mage::app()->getStore()->getId())->load($product->getId());
            $associatedIds[] = $product->getId();
            foreach ($attributes as $attribute) {
                $childValue[] = $child->getData($attribute['attribute_code']);
            }
        }

        return array("childValue" => $childValue, "associatedIds" => $associatedIds);
    }

	public function getEntityId($selected_option_id,$associatedFilteredProductOptionArray)
    {
    	$foundKey = false;
    	foreach($associatedFilteredProductOptionArray['childValue'] as $v => $optionId)
		{
			if($optionId == $selected_option_id){
				$foundKey = true;
				$key = $v;
			}
		}
		
		$entity_id = '';
		if ($foundKey){
			$entity_id = $associatedFilteredProductOptionArray['associatedIds'][$key];
		}

		return $entity_id;
    }
    
    
    /** Returns the simple sku of the associated valueindex
	 *
     * @param  int $selected_option_id
	 * @param array $associatedFilteredProductOptionArray
     * 
	 */
	public function getCurrentOptionSku($selected_option_id, $associatedFilteredProductOptionArray) {
		// $selected_option_id is the option of the current option being built. We need to retrieve the corresponding 
		// product entity_id, load it into the product model and return the MPN of this entity_id

		//  1) $associatedFilteredProductOptionArray[childValue] (key=>optionId)
		//  2) $associatedFilteredProductOptionArray[associatedIds] (key=>entity_id)

		$mpn = 'Please contact customer support for the correct MPN';
		$key = 0;
		$foundKey = false;

		foreach($associatedFilteredProductOptionArray['childValue'] as $v => $optionId)
		{
			if($optionId == $selected_option_id){
				$foundKey = true;
				$key = $v;
			}
		}

		if ($foundKey){
			$entity_id = $associatedFilteredProductOptionArray['associatedIds'][$key];
			$product = Mage::getModel('catalog/product')->load($entity_id);
			$mpn = $product->getBossManufacturerPartNo();
		}

		return $mpn;
	}

	public function getSkuPrice($selected_option_id,$associatedFilteredProductOptionArray)
	{
		$price = 0;
		$key = 0;
		$foundKey = false;

		foreach($associatedFilteredProductOptionArray['childValue'] as $v => $optionId)
		{
			if($optionId == $selected_option_id){
				$foundKey = true;
				$key = $v;
			}
		}

		if($foundKey){
			$entity_id = $associatedFilteredProductOptionArray['associatedIds'][$key];
			$product = Mage::getModel('catalog/product')->load($entity_id);
			$price = $product->getPrice();
		}

		return $price;
	}
	
	public function getSkuFinalPrice($selected_option_id,$associatedFilteredProductOptionArray)
	{
		$price = 0;
		$key = 0;
		$foundKey = false;
	
		foreach($associatedFilteredProductOptionArray['childValue'] as $v => $optionId)
		{
			if($optionId == $selected_option_id){
				$foundKey = true;
				$key = $v;
			}
		}
	
		if($foundKey){
			$entity_id = $associatedFilteredProductOptionArray['associatedIds'][$key];
			$product = Mage::getModel('catalog/product')->load($entity_id);
			$finalprice = $product->getFinalPrice();
		}
	
		return $finalprice;
	}
	
	public function getOptionSku($selected_option_id,$associatedFilteredProductOptionArray)
	{
		$sku = '';
		$key = 0;
		$foundKey = false;

		foreach($associatedFilteredProductOptionArray['childValue'] as $v => $optionId)
		{
			if($optionId == $selected_option_id){
				$foundKey = true;
				$key = $v;
			}
		}

		if($foundKey){
			$entity_id = $associatedFilteredProductOptionArray['associatedIds'][$key];
			$product = Mage::getModel('catalog/product')->load($entity_id);
			$sku = $product->getSku();
		}

		return $sku;
	}

    /**
     * Returns attribute detail for configurable product
     * 
     * @param string $attribute_code
     * @return array
     */
    public function getAttributeByCode($attribute_code) {
        $attribute_details = Mage::getSingleton("eav/config")->getAttribute("catalog_product", $attribute_code);
        $attribute = $attribute_details->getData();
       
	   return $attribute;
    }

    public function getConfigurableProductAttributes($configurableProductId) {
        $configurableProduct = Mage::getModel('catalog/product')->setStoreId(Mage::app()->getStore()->getId())->load($configurableProductId);
       //echo "<pre>"; print_r(get_class_methods(get_class($configurableProduct->getTypeInstance(true)))); die;
       $product = Mage::getModel('catalog/product')->load($configurableProductId);
	   //echo "<pre>"; print_r(get_class_methods(get_class($product->getTypeInstance(true)))); //die;
	   //echo "<pre>"; print_r($product->getOptions());
	   /*$values = array();
	   
	   foreach ($product->getOptions() as $o) {
           $p = $o->getValues();
		   foreach($p as $v) {
				$values[$v->getId()]['option_type_id']= $v->getId();
				$values[$v->getId()]['title']= $v->getTitle();
				$values[$v->getId()]['price']= $v->getPrice();
				$values[$v->getId()]['price_type']= $v->getPriceType();
				$values[$v->getId()]['sku']= $v->getSku();
			  }
        } */
		
		//echo "<pre>";print_r($values);
		//die;
		
		$associatedProductIds = Mage::getModel('catalog/product_type_configurable')->getUsedProductIds($configurableProduct);
        $attributes = $configurableProduct->getTypeInstance(true)->getConfigurableAttributesAsArray($configurableProduct);
        //$attributes = $values;
		
		return $attributes;
    }

    /**
     * Used to get attribute all options for configurable product
     * 
     * @param string $attribute_code
     * @return array
     */
    public function getAttributeOptionByCode($attribute_code) {
        $attribute_details = Mage::getSingleton("eav/config")->getAttribute("catalog_product", $attribute_code);
        $options = $attribute_details->getSource()->getAllOptions();
       
	   return $options;
    }

    /**
     * Get year for configurable product detail page
     * 
     * @param int $configurableProductId
     * @return array
     */
    public function getYearForCofigurableProduct($configurableProductId) {
        $manLabelIdIdDetails = $this->getBossCollection($configurableProductId);
        $years = Mage::getModel('ymm/ymm')->getYearForConfigurableProduct($manLabelIdIdDetails);
        
		return $years;
    }

    /**
     * Get make for configurable product detail page
     * 
     * @param int $configurableProductId
     * @param int $year
     * @return array
     */
    public function getMakeForCofigurableProduct($configurableProductId, $year) {
        $manLabelIdIdDetails = $this->getBossCollection($configurableProductId);
        $make = Mage::getModel('ymm/ymm')->getMakeForConfigurableProduct($manLabelIdIdDetails, $year);
        
		return $make;
    }

    /**
     * Get model for configurable product detail page
     * 
     * @param int $configurableProductId
     * @param int $year
     * @param string $make
     * @return array
     */
    public function getModelForCofigurableProduct($configurableProductId, $year, $make) {
        $manLabelIdIdDetails = $this->getBossCollection($configurableProductId);
        $model = Mage::getModel('ymm/ymm')->getModelForConfigurableProduct($manLabelIdIdDetails, $year, $make);
        
		return $model;
    }

    /**
     * Returns boss part number and brand id base on configurable product id
     * 
     * @param int $configurableProductId
     * @return array
     */
    public function getBossCollection($configurableProductId) {
        $configurableProduct = Mage::getModel('catalog/product')->load($configurableProductId);
        $prod_label = $configurableProduct->getManLabelId();
        $prod_label = rtrim($prod_label, ",");
        
		return array('man_label_id' => $prod_label); 
    }

    /** Get the product
     * 
     * @return object
     */
    public function getProduct() {
        return Mage::registry('current_product');
    }

    /**
     * Get year for simple product detail page
     * 
     * @param int $id
     * @param string $id
     * @param string $man_label_id
     * @return array
     */
    public function getYearForSimpleProductPage($man_label_id) {
        $years = Mage::getModel('ymm/ymm')->getYearForSimpleProductPage($man_label_id);
        
		return $years;
    }

    /**
     * Get make for simple product detail page
     * 
     * @param int $year
     * @param string $man_label_id 
     * @return array
     */
    public function getMakeForSimpleProductPage($year, $man_label_id) {
        $make = Mage::getModel('ymm/ymm')->getMakeForSimpleProductPage($man_label_id, $year);
        
		return $make;
    }

    /**
     * Get model for simple product detail page
     * 
     * @param int $year
     * @param string $make
     * @param string $man_label_id
     * @return array
     */
    public function getModelForSimpleProductPage($year, $make, $man_label_id) {
        $model = Mage::getModel('ymm/ymm')->getModelForSimpleProductPage($man_label_id, $year, $make);
        
		return $model;
    }

}

?>
