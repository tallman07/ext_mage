<?php

/**
 * 
 * @author HE
 * 
 * Mage_Catalog_Model_Product_Type_Abstract
 * 
 * Mage_Catalog_Model_Product_Type_Simple
 * Mage_Catalog_Model_Product_Type_Virtual
 * Mage_Catalog_Model_Product_Type_Configurable
 * Mage_Catalog_Model_Product_Type_Grouped
 *
 */

class Humanelement_Ymm_Block_Product_View_Type_Multiconfigurable extends Mage_Catalog_Block_Product_View_Abstract
{
    /**
     * Get the associated product for YMM multoconfig product type
     * 
     * @return Object
     */
    public function getYmmConfigurableProducts() {
		return Mage::getModel('ymm/product_type_multiconfigurable')->getAssociatedProductIds();
    }
    
    /**
     * Get the dropdowns for YMM multoconfig product type
     * 
     * @return Array
     */
    public function getDropDownOfConfigurableProduct($sku) {
        return Mage::getModel('ymm/product_type_configurable')->getYmmConfigurableDropdown($sku);
    }
}