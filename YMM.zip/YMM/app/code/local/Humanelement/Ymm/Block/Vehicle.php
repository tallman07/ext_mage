<?php

/**
 * Human - Element
 *
 *
 * DISCLAIMER
 * @category    HumanElement Ymm 
 * @package     Humanelement_Ymm
 * @copyright   Copyright (c) Human Element(www.human-element.com)

 */
class Humanelement_Ymm_Block_Vehicle extends Mage_Core_Block_Template {

    /**
     * Get total years from Ymm table
     * 
     * @return array
     */
    public function getVehicleYears($productPage = null) {
        return Mage::getModel('ymm/ymm')->getYears();
    }

    /**
     * Get vehicle make base on year
     * 
     * @param int $year
     * @return array
     */

    public function getVehicleMakers($year, $productPage = null) {
        return Mage::getModel('ymm/ymm')->getVehicleMaker($year, $productPage);
    }

    /**
     * Get vehicle models base on year and make
     * 
     * @param int $year
     * @param string $make
     * @return array
     */

    public function getVehicleModels($year, $make, $productPage = null) {
        return Mage::getModel('ymm/ymm')->getVehicleModel($year, $make, $productPage);
    }
 
    /**
     * Check value of product into the collection
     * 
     * @return int
     */
    public function checkProductCollectionCount(){
        $filteredList = $this->getLayout()
                    ->getBlockSingleton('catalog/product_list')
                    ->getLoadedProductCollection();
        return $filteredList->count();
    }

}