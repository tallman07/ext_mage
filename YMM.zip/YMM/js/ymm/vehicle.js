/**
 * Human - Element
 *
 *
 * DISCLAIMER
 * @category    HumanElement JS
 * @package     Humanelement_Ymm
 * @copyright   Copyright (c) Human Element(www.human-element.com)
 
 */

/**
 * 
 * @param {type} url
 * @param {type} year
 * @param {type} makeid
 * @param {type} modelid
 * @returns {unresolved}
 */
function getMakeValue(url, year, makeid, modelid, loaderid, myCache) {
    if (year != 0 && year != null) {
        if (!$(makeid).disabled) {
            $(makeid).disabled = true;
            $(makeid).value = 0;
        }
        if (!$(modelid).disabled) {
            $(modelid).disabled = true;
            $(modelid).value = 0;
        }
        $(loaderid).show();
        if (myCache.has(year)) {
            html = myCache.get(year);
            $(makeid).disabled = false;
            $(makeid).update(html);

            $(makeid).value = 0;
            $(loaderid).hide();
        } else {
            new Ajax.Request(url, {
                method: 'get',
                parameters: 'year=' + year,
                requestHeaders: {Accept: 'application/json'},
                onSuccess: function(response) {
                    var data = JSON.parse(response.responseText);
                    if (data.length > 0) {
                        var html = "<option value='0'>Make</option>";
                        for (var i = 0; i < data.length; i++)
                        {
                            var html = html + "<option value='" + data[i] + "' >" + data[i] + "</option>";
                        }
                        $(makeid).disabled = false;
                        $(makeid).update(html);
                        var time = new Date();
                        time.setTime(time.getTime() + (1000 * 3600 * 12));                        myCache.set(year, html, time);
                        $(makeid).value = 0;
                        $(loaderid).hide();
					}
                }

            });
        }

    } else {
		$(makeid).disabled = true;
        $(makeid).value = 0;
		$(modelid).disabled = true;
        $(modelid).value = 0;
        return;
    }
}

/**
 * 
 * @param {type} url
 * @param {type} year
 * @param {type} make
 * @param {type} modelid
 * @returns {unresolved}
 */
function getModelValue(url, year, make, modelid, loaderid, myCache) {
    if (year != 0 && make !=0 && year != null && make != null) {
        $(loaderid).show();
        if (myCache.has(year + make)) {
            html = myCache.get(year + make);
            $(modelid).disabled = false;
            $(modelid).update(html);
            $(modelid).value = 0;
            $(loaderid).hide();
        } else {
            new Ajax.Request(url, {
                method: 'get',
                parameters: 'year=' + year + '&make=' + make,
                requestHeaders: {Accept: 'application/json'},
                onSuccess: function(response) {
                    var data = JSON.parse(response.responseText);
                    if (data.length > 0) {
                        var html = "<option value='0'>Model</option>";
                        for (var i = 0; i < data.length; i++)
                        {
                            var html = html + "<option value='" + data[i] + "' >" + data[i] + "</option>";
                        }
                        $(modelid).disabled = false;
                        $(modelid).update(html);
                        var time = new Date();
                        time.setTime(time.getTime() + (1000 * 3600 * 12));
                        myCache.set(year + make, html, time)
                        $(modelid).value = 0;
                        $(loaderid).hide();
                    }
                }

            });
        }

    } else {
		$(modelid).disabled = true;
        $(modelid).value = 0;
        return;
    }

}

function redirectToProductFilterPage(url, year, make, model) {
    if (year && make && model) {
        window.location.href = url;
    } else {
        return;
    }
}

function redirectToProductCategoryPage(url){
    if (url) {
        window.location.href = url;
    } else {
        return;
    }
}

function showChangeSelection(id) {

    if ($(id).getStyle('display') === 'none') {
        $(id).show();
    } else {
        $(id).hide();
    }
}