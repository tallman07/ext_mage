<?php
 
class HE_WholesaleRegistration_ForgotpasswordController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        //Get current layout state
        $update = Mage::getSingleton('core/layout')->getUpdate();
		$update->addHandle('wholesale_forgotpassword');

        $this->loadLayout();          
        $this->renderLayout();
    }
}
 
?>