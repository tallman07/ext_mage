<?php
 
class HE_WholesaleRegistration_RegisterController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        //Get current layout state
        $update = Mage::getSingleton('core/layout')->getUpdate();
        $update->addHandle('wholesale_register');
        
	$this->loadLayout();          
        $this->renderLayout();
    }

    public function sendemailAction()
    {
        //Fetch submited params
        $params = $this->getRequest()->getParams();
        
        $body = "The customer below submitted the Wholesaler Registration. Their responses are below. \n" 
        . "\n" . "Section 1: Personal Information"
        . "\n" . "First Name: " . $params['firstname'] 
        . "\n" . "Last Name: " . $params['lastname'] 
        . "\n" . "Position or Title: " . $params['title'] 
        . "\n" . "Email Address: " . $params['email'] 
        . "\n" . "Contact Phone Number: " . $params['phone'] 
        . "\n" . "Product or Brand of Interest: " . $params['interest']        
        . "\n" . "Sign up for Newsletter?: " . $params['sign-news'] 
        . "\n\n\n"
        . "Section 2: Business Information"
        . "\n" . "Legal Business Name: " . $params['businessname'] 
        . "\n" . "Tax ID: " . $params['taxid'] 
        . "\n" . "Tax Exempt?: " . $params['taxexempt']
        . "\n" . "Business Type: " . $params['businesstype']
        . "\n\n\n"
        . "\n" . "Please contact this user for the business license."
        . "\n" . "Create this user in Magento and add them to the 'Wholesale' customer group."
        . "\n" . "Once they receive their welcome email they will be able to login and view wholesale pricing."
        . "\n\n\n";

        $mail = new Zend_Mail();
        
        /* To attach certificate to email. 
         * First need to add uplaod capability to the registration form.
         * use ajax. change on file input to store in media/wholesale/tmp
         * attach a unique id to each form.
         * destroy after email send.
         * ** Not functioning, but this is the rough process **
         * 
        $at = $mail->createAttachment($params['certificate']);
        $at->type        = 'image/jpg';
        $at->disposition = Zend_Mime::DISPOSITION_INLINE;
        $at->encoding    = Zend_Mime::ENCODING_BASE64;
        $at->filename    = 'certificate.jpg';
        */
        
        $mail->setBodyText($body);
        $mail->setFrom('pbriscoe@human-element.com', 'Wholesaler Registration Application');
        $mail->addTo('pbriscoe@human-element.com', 'Wholesaler Registration Application'); 
        $mail->setSubject('Wholesaler Registration Application'); // A user friendly email subject
        try {
            $mail->send();            
        }        
        catch(Exception $ex) {
            Mage::getSingleton('core/session')->addError('Unable to send email. If this problem persists, please contact us at info@bora.com');
        }
 
        //Redirect back to index action of (this) wholesale controller
        $this->_redirect('wholesale/login/');
        Mage::getSingleton('core/session')->addSuccess('Thank you for your interest! A representative will contact you shortly.');
    }
}
 
?>