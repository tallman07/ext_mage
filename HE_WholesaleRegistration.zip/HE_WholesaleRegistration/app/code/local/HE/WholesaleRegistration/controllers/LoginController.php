<?php
 
class HE_WholesaleRegistration_LoginController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        //Get current layout state
        $update = Mage::getSingleton('core/layout')->getUpdate();
        $update->addHandle('wholesale_login');
        
		$this->loadLayout();          
        $this->renderLayout();
    }
}
 
?>