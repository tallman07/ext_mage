<?php
 
class HE_WholesaleRegistration_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
        //Get current layout state
        //echo "success";
        $update = Mage::getSingleton('core/layout')->getUpdate();
        $update->addHandle('wholesale_register');
        
		$this->loadLayout();          
        $this->renderLayout();
    }

    
}
 
?>