
var $_ = $_.noConflict();

$_(document).ready(function() {
    $_('#accordion').accordion(); // For the accordion in the sidebar        
});

var map; // (global)
var perPage = 5;
var pageIndex = 0;
var totalPages = 1;
var leftOver = 0;
var imgSrc = window.location.hostname;

function UnirgyStoreLocator(config) {
    var geocoder;
    
    function searchLocationsNear(center, params) {

        var currentPageIndex = 0;
        var searchUrl = config.searchUrl+'?lat='+center.lat()+'&lng='+center.lng()+'&'+Object.toQueryString(params);
        
        GDownloadUrl(searchUrl, function(data) {
            var xml = GXml.parse(data);
            var entries = xml.documentElement.getElementsByTagName('marker');
            map.clearOverlays();

            var sidebar = config.sidebarEl;
            sidebar.innerHTML = '<div id="accordion"></div>';
            if (entries.length == 0) {
                sidebar.innerHTML = '<p class="no-results">No results found. Please search for another location.</p>';
                map.setCenter(new GLatLng(40, -100), 4);
                return;
            }

            var sideBarContent = "";
            var bounds = new GLatLngBounds();
            for (var i = 0; i < entries.length; i++) {
                var entry = {};
                for (var j = 0, l = entries[i].attributes.length; j < l; j++) {
                    entry[entries[i].attributes[j].nodeName] = entries[i].attributes[j].nodeValue;
                };
                var point = new GLatLng(parseFloat(entry.latitude), parseFloat(entry.longitude));
                bounds.extend(point);

                var marker = createMarker(entry, point);
                map.addOverlay(marker);

                var display = "";
                if(currentPageIndex > (perPage - 1)){
                     display = "none";
                }    
                
                //alert(JSON.stringify(entry));
                
                sideBarContent += '<h3 id="accrod_h3_'+  currentPageIndex +'" style="display:' + display + ';">' + '<img src="http://'+imgSrc+'/skin/frontend/affinity/default/images/map/markers/sidebar_marker' + entry.marker_label + '.png"/>&nbsp; ' + entry.title + '</h3>';
                sideBarContent += '<div id="accrod_div_'+  currentPageIndex +'">';
                sideBarContent += '<div class="display-addy">' + entry.address_display + '</div>';
                if(entry.phone != ""){
                    sideBarContent += '<div class="display-brand">Phone: <br />' + entry.phone +'</div>';
                }
                sideBarContent += '<div class="display-brand"><strong>BRANDS: </strong><br />' + entry.notes +'</div>';
                sideBarContent += '<div class="clearer"></div>';
                sideBarContent += '<div class="entry-info">';
                sideBarContent += '<p class="entry-directions"><a target="_blank" href="http://maps.google.com/maps?q=' + entry.address + '&z=15">Get Directions</a></p>';
                sideBarContent += '<p class="entry-distance">' + parseFloat(entry.distance).toFixed(1) + ' ' + entry.units + 'les Away</p></div>';
                sideBarContent += '</div>';

                currentPageIndex++;
      
            }
            
            pageIndex = 0;
            totalPages = 1;
            if(currentPageIndex > perPage){
            	totalPages = parseInt(currentPageIndex / perPage);
            	leftOver = parseInt(currentPageIndex % perPage);
            	if(leftOver > 0){
            		totalPages++;
            	}    
            }

            document.getElementById("accordion").innerHTML = "";
            $_('#accordion').append(sideBarContent).accordion();
              
            var sideBarPagination = "<p class=\"pagination_container\">";
            	sideBarPagination += "Pages: ";
            for (var i = 0; i < totalPages; i++) {
            	sideBarPagination += "<a href=\"javascript:changeSideBarPage(" + i +");\" class=\"pagination\">" + (i + 1) + "</a>&nbsp;&nbsp;";
            }   
            	sideBarPagination += "</p>";

            document.getElementById("side_bar_pagination").innerHTML = sideBarPagination; 
            
            var zoomLevel = map.getBoundsZoomLevel(bounds);
            if (entries.length == 1){
            	zoomLevel = 15;
            }
            map.setCenter(bounds.getCenter(), zoomLevel);
        	       
        });
    }

    function escapeUserText(text) {
        if (text === undefined) {
            return null;
        }
        text = text.replace(/@/, "@@");
        text = text.replace(/\\/, "@\\");
        text = text.replace(/'/, "@'");
        text = text.replace(/\[/, "@[");
        text = text.replace(/\]/, "@]");
        return encodeURIComponent(text);
    };

    function createLabeledMarkerIcon(m) {
        var icon = new GIcon();
        icon.image = "http://"+imgSrc+"/skin/frontend/affinity/default/images/map/markers/map_marker" + m.marker_label + ".png";
        icon.shadow = "http://www.google.com/mapfiles/shadow50.png";
        icon.iconSize = new GSize(18, 32);
        icon.shadowSize = new GSize(40, 34);
        icon.iconAnchor = new GPoint(9, 34);
        icon.infoWindowAnchor = new GPoint(9, 2);
        icon.infoShadowAnchor = new GPoint(18, 25);
        return icon;
    }

    function createMarker(m, point) {
    	var letteredIcon = new GIcon(icon);
    	markerOptions = {
    			labelOffset: new GSize(-6, -32)
        };

        var icon = createLabeledMarkerIcon(m);
        var marker = new google.maps.Marker(point, icon);
        GEvent.addListener(marker, 'click', function() {
          marker.openInfoWindowHtml(config.generateMarkerHtml(m));
        });

        return marker;
    }
    
    return {
        load: function () {
            if (!GBrowserIsCompatible()) return;
            geocoder = new GClientGeocoder();
            map = new GMap2(config.mapEl);
			
            map.setCenter(new GLatLng(40, -100), 4);

            //define minimum and maximum zoom levels
            G_NORMAL_MAP.getMinimumResolution = function() { return 0; }
            G_NORMAL_MAP.getMaximumResolution = function() { return 19; }

            // sets the map to "animate" zoom (only on double click and mouse wheel scroll)
            map.enableContinuousZoom();

            // enable the ability to zoom via mouse wheel
            map.enableScrollWheelZoom();

            //this function will enable to slider zoom and the plus/minus zoom. needs to be within the scope of the map to retain min/max zoom levels
            $_(function() {
            	//store the current zoom level for reference with google maps and custom zoom slider
            	var currentZoomLevel = 10;
            	// slider target
            	var target = $_('#zoom-slider #zoom-path');

            	// create the slider
            	target.slider({
            		orientation: 	'horizontal',
            		value: 			currentZoomLevel,
            		min: 			parseInt(G_NORMAL_MAP.getMinimumResolution()),
            		max: 			parseInt(G_NORMAL_MAP.getMaximumResolution()),
            		step: 			1,
            		animate: 		true,
            		stop: function() {
            			map.setZoom(parseInt(target.slider('option','value')));
            		}
            	});

            	// update slider on zoom with double click
            	GEvent.addListener(map, 'moveend', function() { target.slider('option','value', map.getZoom()); });

            	// maximum slider value
            	var maxValue = parseInt(target.slider('option', 'max'));

            	// minimum slider value
            	var minValue = parseInt(target.slider('option', 'min'));

            	// hook increase zoom control
            	$_('#zoom-control-plus').click(function() {
            		// current slider value
            		var currentValue = parseInt(target.slider('option','value'));

            		// current slider value increased by 1
            		var newValue = currentValue+1;

            		// is new value greater than max value?
            		if(newValue <= maxValue) {
            			// increase slider value
            			target.slider('option', 'value', newValue);
            			map.setZoom(newValue);
            		} else {
            			// slider is at max value
            			target.slider('option', 'value', maxValue);
            			map.setZoom(maxValue);
            		}
            		return false;
            	});

            	// hook decrease zoom control
            	$_('#zoom-control-minus').click(function() {
            		// current slider value
            		var currentValue = parseInt(target.slider('option','value'));

            		// current slider value increased by 1
            		var newValue = currentValue-1;

            		// is new value greater than max value?
            		if(newValue >= minValue) {
            			// increase slider value
            			target.slider('option', 'value', newValue);
            			map.setZoom(newValue);
            		} else {
            			// slider is at max value
            			target.slider('option', 'value', minValue);
            			map.setZoom(minValue);
            		}
            		return false;
            	});
            });
        },
        search: function(address, params) {
            geocoder.getLatLng(address, function(latlng) {
                if (!latlng) {
                    alert('The address is not valid: '+address);
                } else {
                    searchLocationsNear(latlng, params);
                }
            });
        }
    };  
}

function changeSideBarPage(index){
	var lastPage = false;
    if((index + 1) == totalPages){
    	lastPage = true;
    }   

    var preLastPage = false;
    if((pageIndex + 1) == totalPages){
    	preLastPage = true;
    }   

    var cIndex = 0;
    for(var x = 0; x < perPage; x++){
    	cIndex = pageIndex * perPage + x;
        if(!preLastPage || x < leftOver){
         document.getElementById("accrod_h3_" + parseInt(cIndex)).style.display = "none";
         document.getElementById("accrod_div_" + parseInt(cIndex)).style.display = "none";
        }
    }

    var nIndex = 0;
    for(var x = 0; x < perPage; x++){
        nIndex  = index  * perPage + x;
        if(!lastPage || x < leftOver){
         document.getElementById("accrod_h3_" + parseInt(nIndex)).style.display = "";
         document.getElementById("accrod_div_" + parseInt(nIndex)).style.display = "";
        }
    }
 
    pageIndex = index;

    $_('#accordion').accordion("destroy");
    $_('#accordion').accordion({ active: (index * perPage)});
    
}

function toggleMapType(mapType){
	if(mapType == "1"){
		map.setMapType(G_NORMAL_MAP);
		document.getElementById("active-normalmap-a").className = "normal-control-active active";
		document.getElementById("active-satmap-a").className = "";
		document.getElementById("active-hybridmap-a").className = "";
	}else if(mapType == "2"){
		map.setMapType(G_SATELLITE_MAP);
		document.getElementById("active-normalmap-a").className = "";
		document.getElementById("active-satmap-a").className = "satellite-control-active active";
		document.getElementById("active-hybridmap-a").className = "";
	}else if(mapType == "3"){
		map.setMapType(G_HYBRID_MAP);
		document.getElementById("active-normalmap-a").className = "";
		document.getElementById("active-satmap-a").className = "";
		document.getElementById("active-hybridmap-a").className = "hybrid-control-active active";
	}
}