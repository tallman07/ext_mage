<?php
/**
 * Unirgy_StoreLocator extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category   Unirgy
 * @package    Unirgy_StoreLocator
 * @copyright  Copyright (c) 2008 Unirgy LLC
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

/**
 * @category   Unirgy
 * @package    Unirgy_StoreLocator
 * @author     Boris (Moshe) Gurevich <moshe@unirgy.com>
 */
class Unirgy_StoreLocator_Model_Location extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('ustorelocator/location');
    }

    public function fetchCoordinates()
    {
    	Mage::log("starting fetch",0,"geo.log");
        $url = "http://maps.googleapis.com/maps/api/geocode/json";
        if (!$url) {
        	Mage::log("no url to find",0,"geo.log");
            $url = "http://maps.google.com/maps/geo";
        }
        $url .= strpos($url, '?')!==false ? '&' : '?';
        $url .= 'address='.urlencode(preg_replace('#\r|\n#', ' ', $this->getAddress()))."&sensor=false";

		Mage::log("url: ".$url,0,"geo.log");
		
        $cinit = curl_init();
        curl_setopt($cinit, CURLOPT_URL, $url);
        curl_setopt($cinit, CURLOPT_HEADER,0);
        curl_setopt($cinit, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]);
        curl_setopt($cinit, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($cinit);
        
        if (!is_string($response) || empty($response)) {
        	Mage::log("no response",0,"geo.log");
            return $this;
        }
        
        $result = json_decode($response);
        
        //print_r($result);
        $status = $result->status;
        $results = $result->results;
        $lat = $results[0]->geometry->location->lat;
        $lng = $results[0]->geometry->location->lng;
        
        //echo $lat;
        //echo "<br />";
        //echo $lng;
        //die();
        
        if ($status!='OK') {
       		Mage::log("Request to API was not successful ",0,"geo.log");
            return $this;
        }
        
       	$this->setLatitude($lat)->setLongitude($lng);
        
        return $this;
    }

    protected function _beforeSave()
    {
        if (!$this->getAddress()) {
            $this->setAddress($this->getAddressDisplay());
        }

        $this->setAddress(str_replace(array("\n", "\r"), " ", $this->getAddress()));

        if (!(float)$this->getLongitude() || !(float)$this->getLatitude() || $this->getRecalculate()) {
           Mage::log("before save -- fetch",0,"geo.log");
           $this->fetchCoordinates();
        }

        parent::_beforeSave();
    }
}
