<?php 

class HE_QuickOrder_Block_View extends Mage_Core_Block_Template
{
	protected function _construct() {
		parent::_construct();
	}
	
	public function getProducts() {
		try {
			return Mage::getModel("he_quickorder/quickorder")->getProducts();
		}
		catch (Mage_Core_Exception $e) {
			Mage::logException($e);
			echo($e);
		}
	}
	
	public function getPriceHtml($product) {
		$this->setTemplate('catalog/product/price.phtml');
		$this->setProduct($product);
		return $this->toHtml();
	}
}

?>