<?php 

class HE_QuickOrder_Model_Quickorder extends Mage_Core_Model_Abstract

{
	protected $_products = null;

	protected function setProducts($products) {
		$this->_products = $products;
		return $this;
	}

	public function getProducts() {
		if ($this->_products === null) {
			$products = Mage::getModel('catalog/product')->getCollection()
                ->addStoreFilter()
                ->addAttributeToFilter('status', 1) //enabled
                ->addAttributeToFilter('visibility', array(1,2,3,4)) //all categories
                ->addAttributeToFilter('type_id', 'simple')  //<����-Changed Here
			    ->addAttributeToSelect(array('id','sku','name', 'type_id','image','price','small_image','cart_increment'))
			    ->setOrder('name','ASC');

			$this->setProducts($products);
		}
		return $this->_products;
	}

	protected function _construct() {
		$this->_init('he_quickorder/quickorder');
	}
}
 
?>