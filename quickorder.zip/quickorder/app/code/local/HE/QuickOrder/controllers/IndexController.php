<?php
 
class HE_QuickOrder_IndexController extends Mage_Core_Controller_Front_Action
{
	
	protected $_cookieCheckActions = array('add');
	
	/**
	* Retrieve shopping cart model object
	*
	* @return Mage_Checkout_Model_Cart
	*/
	protected function _getCart()
	{
		return Mage::getSingleton('checkout/cart');
	}

	/**
	* Get checkout session model instance
	*
	* @return Mage_Checkout_Model_Session
	*/
	protected function _getSession()
	{
		return Mage::getSingleton('checkout/session');
	}

	/**
	* Get current active quote instance
	*
	* @return Mage_Sales_Model_Quote
	*/
	protected function _getQuote()
	{
		return $this->_getCart()->getQuote();
	}

	/**
	* Set back redirect url to response
	*
	* @return Mage_Checkout_CartController
	*/
	protected function _goBack()
	{
		if (!Mage::getStoreConfig('checkout/cart/redirect_to_cart') && !$this->getRequest()->getParam('in_cart') && $backUrl = $this->_getRefererUrl()) {
			$this->getResponse()->setRedirect($backUrl);
		} else {
			if (($this->getRequest()->getActionName() == 'add') && !$this->getRequest()->getParam('in_cart')) {
				$this->_getSession()->setContinueShoppingUrl($this->_getRefererUrl());
			}
			$this->_redirect('checkout/cart');
		}
		return $this;
	}

	public function indexAction()
	{
		$this->products = Mage::getModel("he_quickorder/quickorder")->getProducts();
		$this->loadLayout();
		$this->renderLayout();
	}
	
	public function configureAction()
	{
		$pid = $this->getRequest()->getParam('pid');
		$product = Mage::getModel('catalog/product')->load($pid);
		
		//Get current layout state 
	    $this->loadLayout();	
	    
	    // Create block to output to ajax response
	    // block type is configurable to generate our select and attribute options	
	    $block = $this->getLayout()
	    	->createBlock('catalog/product_view_type_configurable')
	    	->setTemplate('quickorder/product/type/configurable.phtml')
			->setData('product',$product)
			->setData('pid',$pid)
			->toHtml();	
	  
		echo $block;
		
	}
	
	public function addAction()
	{
		$hasError = false;
		$cart   = $this->_getCart();
		$params = $this->getRequest()->getParams();
		
		//Mage::log('',0,"quickorder.log");
		//Mage::log('Starting to process params',0,"quickorder.log");
		
		$configurableProducts = array();
		$simpleProducts = array();
		
        // get the list of products selected to add to basket
        foreach ($params as $prod_id => $value) {
        	
        	// Find 'super' in $value to determine this is a prod_id sent with configurable options
        	$opts = 'super';
        	$qty_val = "_qty";

        	if(strpos($value,$opts)){
      		//Mage::log($prod_id.' has options.',0,"quickorder.log");

        		// $value format like:  [{"1":[{"super_attr":204,"attr_id":333}]}]
        		
        		// Get qty from separate param value, loaded by this prod_id append 'qty'
        		$qty = $this->getRequest()->getParam($prod_id.'_qty'); 
        		
        		$opts = json_decode($value);
        		// decoded json format like:  Array ([0] => stdClass Object ( [1] => Array ([0] => stdClass Object ([super_attr] => 204	[attr_id] => 333 ))))        		
        		// load std class obj back to itself to reduce layering
        		$opts = $opts[0];
        		foreach($opts as $optArr){
        			// access option array and load class obj values into standard variables
					foreach($optArr as $option => $array){
						$super = $array->super_attr;
						$attrId = $array->attr_id;
					}
	    		}
	       		//echo "Data: ". $super . " : " . $attrId . " : ".$qty;
        		// die();
        		
        		// build configurable products with id as key and $requestInfo as value array
        		$configurableProducts[$prod_id] = array(
					"super_attribute"=> array(
							$super =>$attrId
						), 
					"qty" => $qty
				);
				
        	} elseif(strpos($prod_id,$qty_val)) {
        		continue;
        	} else {
        		// Load simple products into simple array of product ids
        		$simpleProducts[] = $prod_id;
        	}
        }
        
        //generate a collection of the products that were selected by the user
        $products =  Mage::getModel("catalog/product")
            ->getCollection()
            ->addStoreFilter()
            ->addAttributeToFilter('entity_id', array(
                'in' => $simpleProducts,
                ));
        
        // Go through and add all simple products to the cart 
		foreach ($products as $product){
			
            try {
            	// grab qty from original params value of prod_id
                $productQty = $params[$product->getId()];
                $cart->addProduct($product, $productQty);
            } 
            catch (Mage_Core_Exception $e) {
                if ($this->_getSession()->getUseNotice(true)) {
                    $this->_getSession()->addNotice($e->getMessage());
                } else {
                $messages = array_unique(explode("\n", $e->getMessage()));
                    foreach ($messages as $message) {
                    //$this->_getSession()->addError($message . " productName = " . $product->getName());
                    }
                }
            }
            catch (Exception $e) {
                $this->_getSession()->addException($e, "Cannot add " . $product->getName() . " to cart.");
            }
		}
		
		// Now go through and add all configurable products to the cart
		foreach ($configurableProducts as $configurableProductId => $requestInfo){
			if(strpos($configurableProductId,"_1")) {
				$configurableProductId = str_replace("_1","",$configurableProductId);
			}
			$cProduct = Mage::getModel("catalog/product")->load($configurableProductId);
			try {
                $cart->addProduct($cProduct, $requestInfo);
            }
            
            catch (Mage_Core_Exception $e) {
                if ($this->_getSession()->getUseNotice(true)) {
					Mage::log($e->getMessage(),0,"quickorder.log");
                    //$this->_getSession()->addNotice($e->getMessage());
                } else {
                	
                $messages = array_unique(explode("\n", $e->getMessage()));
                    foreach ($messages as $message) {
                	Mage::log($message,0,"quickorder.log");
                    //$this->_getSession()->addError($message . " productName = " . $product->getName());
                    }
                }
            }
            catch (Exception $e) {
                $this->_getSession()->addException($e, "Cannot add " . $product->getName() . " to cart.");
            }
		}
	
        if ($cart->hasDataChanges()) {
            $cart->save();
          	$this->_getSession()->setCartWasUpdated(true);
        }
	
		$this->getResponse()->setRedirect('/checkout/cart');
	}
}

?>