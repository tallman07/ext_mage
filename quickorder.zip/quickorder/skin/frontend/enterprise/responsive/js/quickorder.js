/*
 *
 *  Ajax Autocomplete for Prototype, version 1.0.3
 *  (c) 2008 Tomas Kirda
 *
 *  Ajax Autocomplete for Prototype is freely distributable under the terms of an MIT-style license.
 *  For details, see the web site: http://www.devbridge.com/projects/autocomplete/
 *
 */

var Quickorder = function(el, options){
  this.el = $(el);
  this.elico = $(el+'ajaxico');
  this.id = this.el.identify();
  this.el.setAttribute('quickorder','off');
  this.suggestions = [];
  this.image = [];
  this.description = [];
  this.data = [];
  this.badQueries = [];
  this.selectedIndex = -1;
  this.currentValue = this.el.value;
  this.intervalId = 0;
  this.cachedResponse = [];
  this.instanceId = null;
  this.headertext = '';
  this.footertext = '';
  this.countdata = [];
  this.onChangeInterval = null;
  this.ignoreValueChange = false;
  this.serviceUrl = options.serviceUrl;
  this.options = {
    autoSubmit:false,
    minChars:1,
    store:1,
    enableimage: 0,
    enableloader: 0,
    maxHeight:300,
    deferRequestBy:500,
    width:0,
    searchtext:'',
    baseUrl:'',
    secureUrl:'',
    container:null,
    itemLimit:5,
    productType:'simple'
  };
  if(options){ Object.extend(this.options, options); }
  if(Quickorder.isDomLoaded){
    this.initialize();
  }else{
    Event.observe(document, 'dom:loaded', this.initialize.bind(this), false);
  }
};

Quickorder.instances = [];
Quickorder.isDomLoaded = false;

Quickorder.getInstance = function(id){
  var instances = Quickorder.instances;
  var i = instances.length;
  while(i--){ if(instances[i].id === id){ return instances[i]; }}
};

Quickorder.highlight = function(value, re){
  return value.replace(re, function(match){ return '<strong>' + match + '<\/strong>' });
};

Quickorder.prototype = {

  killerFn: null,

  initialize: function() {
    var me = this;
    this.killerFn = function(e) {
      if (!$(Event.element(e)).up('.quickorder-results')) {
        me.killSuggestions();
        me.disableKillerFn();
      }
    } .bindAsEventListener(this);

    this.container = $('search-results');
    
    Event.observe(this.el, window.opera ? 'keypress':'keydown', this.onKeyPress.bind(this));
    Event.observe(this.el, 'keyup', this.onKeyUp.bind(this));
    //Event.observe(this.el, 'blur', this.enableKillerFn.bind(this));
    Event.observe(this.el, 'click', this.fixText.bind(this));
    Event.observe(this.el, 'blur', this.fixText.bind(this));
    
  },


  fixText: function() {
    if(this.el.value == this.options.searchtext){
        this.el.value='';
    } else if(this.el.value.length == 0) {
        this.el.value = this.options.searchtext;
    } else {
        return;
    };
  },

  enableKillerFn: function() {
    Event.observe(document.body, 'click', this.killerFn);
  },

  disableKillerFn: function() {
    Event.stopObserving(document.body, 'click', this.killerFn);
  },

  killSuggestions: function() {
    this.stopKillSuggestions();
    this.intervalId = window.setInterval(function() { this.hide(); this.stopKillSuggestions(); } .bind(this), 300);
  },

  stopKillSuggestions: function() {
    window.clearInterval(this.intervalId);
  },

  onKeyPress: function(e) {
    //if (!this.enabled) { return; }
    // return will exit the function
    // and event will not fire
    switch (e.keyCode) {
      case Event.KEY_ESC:
        this.el.value = this.currentValue;
        this.hide();
        break;
      case Event.KEY_TAB:
      case Event.KEY_RETURN:
    	  e.preventDefault();
    	  return false;
      case Event.KEY_UP:
        this.moveUp();
        break;
      case Event.KEY_DOWN:
        this.moveDown();
        break;
      default:
        return;
    }
    //Event.stop(e);
  },

  onKeyUp: function(e) {
    switch (e.keyCode) {
      case Event.KEY_UP:
      case Event.KEY_DOWN:
        return;
    }
    clearInterval(this.onChangeInterval);
    if (this.currentValue !== this.el.value) {
      if (this.options.deferRequestBy > 0) {
        // Defer lookup in case when value changes very quickly:
        this.onChangeInterval = setInterval((function() {
          this.onValueChange();
        }).bind(this), this.options.deferRequestBy);
      } else {
        this.onValueChange();
      }
    }
  },

  onValueChange: function() {
    clearInterval(this.onChangeInterval);
    this.currentValue = this.el.value;
    this.selectedIndex = -1;
    if (this.ignoreValueChange) {
      this.ignoreValueChange = false;
      return;
    }
    if (this.currentValue === '' || this.currentValue.length < this.options.minChars) {
      this.hide();
    } else {
      this.getSuggestions();
    }
  },

  getSuggestions: function() {
    var cr = this.cachedResponse[this.currentValue];
    if (cr && Object.isArray(cr.suggestions)) {
      this.suggestions = cr.suggestions;
      this.image = cr.image;
      this.description = cr.description;
      this.data = cr.data;
      this.suggest();
    } else if (!this.isBadQuery(this.currentValue)) {
        this.showloader();
        var currentUrl = window.location.href;
        var isBaseUrl = (0 === currentUrl.indexOf(this.options.baseUrl));
        var isRequestBaseUrl = (0 === this.serviceUrl.indexOf(this.options.baseUrl));
        if (isBaseUrl && !isRequestBaseUrl) {
            this.serviceUrl = this.serviceUrl.replace(this.options.secureUrl, this.options.baseUrl);
        } else if (!isBaseUrl && isRequestBaseUrl) {
            this.serviceUrl = this.serviceUrl.replace(this.options.baseUrl, this.options.secureUrl);
        }
      new Ajax.Request(this.serviceUrl, {
        parameters: { query: this.currentValue, store: this.options.store, itemLimit: this.options.itemLimit, productType: this.options.productType, enableimage: this.options.enableimage, enabledescription: this.options.enabledescription, descriptionchars: this.options.descriptionchars},
        onComplete: this.processResponse.bind(this),
        method: 'get'
      });
    }
  },

  isBadQuery: function(q) {
    var i = this.badQueries.length;
    while (i--) {
      if (q.indexOf(this.badQueries[i]) === 0) { return true; }
    }
    return false;
  },

  hide: function() {
    this.enabled = false;
    this.selectedIndex = -1;
    this.container.hide();
  },

  suggest: function() {
	  
    this.hideloader();
    if (this.suggestions.length === 0) {
    	this.hide();
      return;
    }
    var content = [];
    var re = new RegExp('\\b' + this.currentValue.match(/\w+/g).join('|\\b'), 'gi');
    // \w => [\w\u0590-\u05FF] for Hebrew support

    // header
    if (this.headertext != '') {
        content.push('<p class="headerajaxsearchwindow">',this.headertext,'</p>');
    }
    this.suggestions.each(function(value, i) {
      var image = this.image[i];
      var nodisplay;
      var description = this.description[i];
      var price = this.price[i];
      var tiered_price_html=this.tiered_price_html[i];
      if(tiered_price_html==undefined){tiered_price_html='';}
      tiered_price_html=tiered_price_html.trim();
      var productId = this.productid[i];
      var sku = this.sku[i];
      if (this.countdata[0] > 0 && this.countdata[1] > 0 && i == this.countdata[0]) {
          nodisplay = true;
      }
      if (this.countdata[1] > 0 && this.countdata[2] > 0 && i == (this.countdata[0] + this.countdata[1])) {
    	  nodisplay = true;
      } else if (this.countdata[0] > 0 && this.countdata[2] > 0 && i == (this.countdata[0] + this.countdata[1])) {
    	  nodisplay = true;
      } if (productId == 0 || productId == "" || productId == null || productId == undefined ){
    	  nodisplay = true;
      }
      if (nodisplay) {
    	  // Do Nothing
      } else {
          content.push('<div class="ajaxsearchtitle small_iconProductQuickorder" title="',value,'" id="item-',productId,'"><div class="small_iconProductQuickorder">',image,'</div><div class="quick-info"><p class="title">',Quickorder.highlight(value, re),'',description,'</p><p class="sku">Item # ',sku,'</p>');

			content.push(tiered_price_html);
			
          content.push('<div class="quick-price"><p>',price,
          	'</p></div><div class="quick-qty"><p>Qty:</p><input type="text" name="',productId,
          	'" id="',productId,'" value="1"/></div><div class="add"><button type="button" class="button btn-cart" id="',
          	productId,'" onClick="addToOrderList(this.id);quickOrderItemAdded(this);">Add to List</button></div></div></div>');
      
      		//position the responsive arrow buttons
			var btnLeft = jQuery('.leftnav-responsive:first');
			var btnRight = jQuery('.rightnav-responsive:first');
	    	setLeftRightBtnsScrollPos(btnLeft, btnRight);
      }
      
    } .bind(this));

    // footer
    if (this.footertext != '') {
        content.push('<p class="headerajaxsearchwindow">',this.footertext,'</p>');
    }

    this.enabled = true;
    
    this.container.update(content.join('')).show();
  },

  processResponse: function(xhr) {
    var response;
  
    try {
      response = xhr.responseText.evalJSON();
      if (!Object.isArray(response.data)) { response.data = []; }
    } catch (err) { return; }
    this.suggestions = response.suggestions;
    this.image = response.image;
    this.description = response.description;
    this.data = response.data;
    this.productid = response.id;
    this.sku = response.sku;
    this.price = response.price;
    this.tiered_price_html = response.tiered_price_html;
    this.headertext = response.headertext;
    this.footertext = response.footertext;
    this.countdata = response.countdata;
    this.cachedResponse[response.query] = response;
    if (response.suggestions.length === 0) { this.badQueries.push(response.query);}
    if (response.query === this.currentValue) { this.suggest(); }
    
    
  },

  activate: function(index) {
    var divs = $(this.container).select('div');
    var activeItem;
    // Clear previous selection:
    if (this.selectedIndex !== -1 && divs.length > this.selectedIndex) {
      divs[this.selectedIndex].className = '';
    }
    this.selectedIndex = index;
    if (this.selectedIndex !== -1 && divs.length > this.selectedIndex) {
      activeItem = divs[this.selectedIndex]
      activeItem.className = 'selected';
    }
    return activeItem;
  },

  deactivate: function(div, index) {
    div.className = '';
    if (this.selectedIndex === index) { this.selectedIndex = -1; }
  },

  select: function(i) {
    var selectedValue = this.suggestions[i];
    if (selectedValue) {
      this.el.value = selectedValue;
      if (this.options.autoSubmit && this.el.form) {
        this.el.form.submit();
      }
      this.ignoreValueChange = true;
      this.hide();
      this.onSelect(i);
    }
  },

  moveUp: function() {

    if (this.selectedIndex === -1) { return; }
    if (this.selectedIndex === 0) {
      $(this.container).select('div')[0].className = '';
      this.selectedIndex = -1;
      this.el.value = this.currentValue;
      return;
    }
    this.adjustScroll(this.selectedIndex - 1);
  },

  moveDown: function() {
    if (this.selectedIndex === (this.suggestions.length - 1)) { return; }
    this.adjustScroll(this.selectedIndex + 1);
  },

  showloader: function() {
    if (this.options.enableloader == 1) { this.elico.setStyle({display: 'block'}); }
  },

  hideloader: function() {
    if (this.options.enableloader == 1) { this.elico.setStyle({display: 'none'}); }
  },

  adjustScroll: function(i) {
    var container = this.container;
    var activeItem = this.activate(i);
    var offsetTop = activeItem.offsetTop;
    var upperBound = container.scrollTop;
    var lowerBound = upperBound + this.options.maxHeight - 25;
    if (offsetTop < upperBound) {
      container.scrollTop = offsetTop;
    } else if (offsetTop > lowerBound) {
      container.scrollTop = offsetTop - this.options.maxHeight + 25;
    }
    this.el.value = this.suggestions[i];
  },

  onSelect: function(i) {
    (this.options.onSelect || Prototype.emptyFunction)(this.suggestions[i], this.data[i]);
  }

};

function onQuickorderSubmit(value, data){
    setLocation(data)
}

Event.observe(document, 'dom:loaded', function(){ Quickorder.isDomLoaded = true; }, false);
