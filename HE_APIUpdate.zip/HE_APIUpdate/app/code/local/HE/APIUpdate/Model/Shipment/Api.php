<?php
class HE_APIUpdate_Model_Shipment_Api extends Mage_Sales_Model_Order_Shipment_Api
{
    /**
     * Add tracking number to order
     *
     * @param string $shipmentIncrementId
     * @param string $carrier
     * @param string $title
     * @param string $trackNumber
     * @param string $email
     * @param string $includeComment
     * @return int
     */

// HE updated to include the email and includeComment fields

    public function addTrack($shipmentIncrementId, $carrier, $title, $trackNumber, $email = false, $includeComment = false, $comment="")
    {
        $shipment = Mage::getModel('sales/order_shipment')->loadByIncrementId($shipmentIncrementId);

        /* @var $shipment Mage_Sales_Model_Order_Shipment */

        if (!$shipment->getId()) {
            $this->_fault('not_exists');
        }

        $carriers = $this->_getCarriers($shipment);

        if (!isset($carriers[$carrier])) {
            $this->_fault('data_invalid', Mage::helper('sales')->__('Invalid carrier specified.'));
        }

        $track = Mage::getModel('sales/order_shipment_track')
                    ->setNumber($trackNumber)
                    ->setCarrierCode($carrier)
                    ->setTitle($title);

        $shipment->addTrack($track);
				$shipment->addComment($comment, $email && $includeComment);

				if ($email) {
        	$shipment->setEmailSent(true);
        	$shipment->sendEmail($email, ($includeComment ? $comment : ''));
        }

        try {
            $shipment->save();
            $track->save();


        } catch (Mage_Core_Exception $e) {
            $this->_fault('data_invalid', $e->getMessage());
        }

        return $track->getId();
    }
}
