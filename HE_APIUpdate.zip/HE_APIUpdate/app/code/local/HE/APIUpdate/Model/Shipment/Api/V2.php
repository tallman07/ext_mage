<?php

/**
 * Sales order shipment API V2
 *
 * @category   Mage
 * @package    Mage_Sales
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class HE_APIUpdate_Model_Shipment_Api_V2 extends Mage_Sales_Model_Order_Shipment_Api_V2
{
}
